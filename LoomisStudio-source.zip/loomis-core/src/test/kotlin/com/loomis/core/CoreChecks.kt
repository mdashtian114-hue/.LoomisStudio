package com.loomis.core

import com.loomis.core.figure.BodyObservation
import com.loomis.core.figure.FigureAnalyzer
import com.loomis.core.figure.FigureStepBuilder
import com.loomis.core.geom.Vec2
import com.loomis.core.geom.Vec3
import com.loomis.core.geom.deg
import com.loomis.core.geom.rad
import com.loomis.core.head.FaceObservation
import com.loomis.core.head.HeadFitter
import com.loomis.core.head.HeadPose
import com.loomis.core.head.HeadProportions
import com.loomis.core.head.HeadStepBuilder
import com.loomis.core.head.LoomisHeadModel
import com.loomis.core.head.ObservationSource
import com.loomis.core.lesson.Lang
import com.loomis.core.lesson.Labels
import com.loomis.core.lesson.Lessons
import com.loomis.core.model.Confidence
import com.loomis.core.model.StrokeRole
import kotlin.math.abs
import kotlin.random.Random

/** Engine checks shared by the JUnit test (CI) and the local runner. Each throws AssertionError on failure. */
object CoreChecks {
    private fun require(c: Boolean, msg: () -> String) { if (!c) throw AssertionError(msg()) }

    private fun synth(yaw: Double, pitch: Double, roll: Double, prop: HeadProportions = HeadProportions(), noise: Double = 2.0, seed: Int = 1): Pair<HeadPose, FaceObservation> {
        val rnd = Random(seed)
        val pose = HeadPose(rad(yaw), rad(pitch), rad(roll), 110.0, 400.0, 380.0)
        val m = LoomisHeadModel(prop)
        val anchors = LoomisHeadModel.Anchor.values().filter { !it.name.startsWith("EAR") }
            .filter { pose.facesViewer(m.anchorNormal(it), -0.3) }
            .associateWith { pose.project(m.anchor(it)) + Vec2(rnd.nextDouble(-noise, noise), rnd.nextDouble(-noise, noise)) }
        return pose to FaceObservation(anchors)
    }

    /** The fitter recovers rotation within 5° across front, 3/4, up and down views. */
    fun poseRecovery() {
        val cases = listOf(Triple(0.0, 0.0, 0.0), Triple(30.0, 0.0, 6.0), Triple(-40.0, 12.0, -8.0), Triple(0.0, 25.0, 0.0),
            Triple(0.0, -25.0, 0.0), Triple(48.0, -15.0, 12.0), Triple(-20.0, -20.0, 25.0))
        for ((i, c) in cases.withIndex()) {
            val (truth, obs) = synth(c.first, c.second, c.third, HeadProportions(noseThird = 1.05, chinThird = 0.94), seed = i)
            val fit = HeadFitter.fit(obs) ?: throw AssertionError("no fit for $c")
            require(abs(deg(fit.pose.yaw - truth.yaw)) < 5) { "yaw ${deg(fit.pose.yaw)} vs ${c.first}" }
            require(abs(deg(fit.pose.pitch - truth.pitch)) < 6) { "pitch ${deg(fit.pose.pitch)} vs ${c.second}" }
            require(abs(deg(fit.pose.roll - truth.roll)) < 4) { "roll ${deg(fit.pose.roll)} vs ${c.third}" }
            require(abs(fit.pose.scale / truth.scale - 1) < 0.08) { "scale ${fit.pose.scale}" }
        }
    }

    /** A clearly wrong point must lower the confidence (the app then asks the user to confirm). */
    fun outlierLowersConfidence() {
        val (_, obs) = synth(10.0, 5.0, 0.0)
        val good = HeadFitter.fit(obs)!!
        require(good.confidence == Confidence.HIGH) { "clean fit should be HIGH, was ${good.confidence} ${good.warnings}" }
        val chin = obs.anchors.getValue(LoomisHeadModel.Anchor.CHIN)
        val bad = obs.copy(anchors = obs.anchors + (LoomisHeadModel.Anchor.CHIN to chin + Vec2(140.0, -160.0)))
        val fit = HeadFitter.fit(bad)!!
        require(fit.confidence != Confidence.HIGH) { "outlier should not be HIGH (rms ${fit.rmsU})" }
        val steps = HeadStepBuilder(fit, bad).build()
        require(steps[0].requiresConfirmation) { "analysis stage must request confirmation" }
    }

    /** Manual points are never trusted until the user confirms them. */
    fun manualNeedsConfirmation() {
        val (_, obs) = synth(0.0, 0.0, 0.0)
        val manual = obs.copy(source = ObservationSource.MANUAL, userConfirmed = false)
        val fit = HeadFitter.fit(manual)!!
        require(HeadStepBuilder(fit, manual).build()[0].requiresConfirmation) { "manual points need confirmation" }
    }

    /** Guides follow the rotation: centre line sits mid-head when frontal and shifts toward the facing side when turned. */
    fun centerLineFollowsRotation() {
        for (yaw in listOf(0.0, 35.0, -35.0)) {
            val pose = HeadPose(rad(yaw), 0.0, 0.0, 100.0, 300.0, 300.0)
            val m = LoomisHeadModel()
            val noseLineCenter = pose.project(Vec3(0.0, 1.0, m.faceFrontZ(1.0)))
            val dx = noseLineCenter.x - pose.tx
            when {
                yaw == 0.0 -> require(abs(dx) < 1e-6) { "frontal centre line off-centre $dx" }
                yaw > 0 -> require(dx > 40) { "turned right, centre line should move right ($dx)" }
                else -> require(dx < -40) { "turned left, centre line should move left ($dx)" }
            }
        }
    }

    /** Loomis constants: side plane is ⅔ of the ball, thirds sit on the side plane. */
    fun loomisConstants() {
        require(abs(2 * LoomisHeadModel.SIDE_R / (2 * LoomisHeadModel.R) - 2.0 / 3.0) < 1e-9) { "side plane ratio" }
        val p = HeadProportions()
        require(p.hairY == -LoomisHeadModel.SIDE_R && p.noseY == LoomisHeadModel.SIDE_R && p.chinY == 2.0) { "thirds" }
        require(abs(p.chinY + LoomisHeadModel.R - 3.5) < 1e-9) { "head is 3.5 units" }
    }

    /** All 17 head stages and 14 figure stages exist, have lessons in both languages and real strokes. */
    fun stagesComplete() {
        val (_, obs) = synth(20.0, 8.0, 3.0)
        val steps = HeadStepBuilder(HeadFitter.fit(obs)!!, obs).build()
        require(steps.size == 17) { "head stages ${steps.size}" }
        for (s in steps) {
            val l = Lessons.get(s.lessonId) ?: throw AssertionError("missing lesson ${s.lessonId}")
            require(l.fa.title.isNotBlank() && l.en.title.isNotBlank()) { "lesson text ${s.lessonId}" }
            if (s.index > 0) require(s.strokes.isNotEmpty()) { "stage ${s.lessonId} has no strokes" }
            s.labels.forEach { require(Labels.get(it.key, Lang.FA) != it.key || it.key.startsWith("#")) { "label ${it.key}" } }
            s.metrics.forEach { require(Labels.get(it.key, Lang.EN) != it.key) { "metric ${it.key}" } }
            s.warnings.forEach { require(Labels.get(it, Lang.FA) != it) { "warning $it" } }
        }
        require(steps.last().strokes.any { it.role == StrokeRole.FINAL }) { "final drawing" }
        require(steps.flatMap { it.strokes }.count { it.role == StrokeRole.FINAL } > 8) { "too few final lines" }

        val body = BodyObservation.template(600, 1000).copy(userConfirmed = true, manual = false)
        val an = FigureAnalyzer.analyze(body)!!
        require(abs(an.heightHeads - 8.0) < 0.4) { "template should measure ~8 heads, got ${an.heightHeads}" }
        val fsteps = FigureStepBuilder(body, an).build()
        require(fsteps.size == 14) { "figure stages ${fsteps.size}" }
        for (s in fsteps) {
            require(Lessons.get(s.lessonId) != null) { "missing lesson ${s.lessonId}" }
            if (s.index > 0) require(s.strokes.isNotEmpty()) { "figure stage ${s.lessonId} empty" }
            s.labels.forEach { require(Labels.get(it.key, Lang.FA) != it.key || it.key.startsWith("#")) { "label ${it.key}" } }
            s.metrics.forEach { require(Labels.get(it.key, Lang.EN) != it.key) { "metric ${it.key}" } }
        }
        require(fsteps.last().strokes.all { it.role == StrokeRole.FINAL || it.role == StrokeRole.FINAL_LIGHT }) { "figure final roles" }
    }

    /** Moving an anchor drags its contour with it. */
    fun anchorEditMovesContour() {
        val (_, obs0) = synth(0.0, 0.0, 0.0, noise = 0.001)
        val eye = obs0.anchors.getValue(LoomisHeadModel.Anchor.EYE_L)
        val contour = (0 until 16).map { k -> eye + Vec2(20 * kotlin.math.cos(k * 0.39), 8 * kotlin.math.sin(k * 0.39)) }
        val obs = obs0.copy(contours = mapOf(com.loomis.core.head.FaceContour.EYE_L to contour))
        val moved = obs.moveAnchor(LoomisHeadModel.Anchor.EYE_L, eye + Vec2(10.0, 5.0))
        val c = moved.contours.getValue(com.loomis.core.head.FaceContour.EYE_L)
        val mean = Vec2.mean(c)
        require(mean.distanceTo(Vec2.mean(contour) + Vec2(10.0, 5.0)) < 2.0) { "contour followed: $mean" }
        require(moved.userConfirmed) { "edit marks confirmed" }
    }

    val all: List<Pair<String, () -> Unit>> = listOf(
        "poseRecovery" to ::poseRecovery, "outlierLowersConfidence" to ::outlierLowersConfidence,
        "manualNeedsConfirmation" to ::manualNeedsConfirmation, "centerLineFollowsRotation" to ::centerLineFollowsRotation,
        "loomisConstants" to ::loomisConstants, "stagesComplete" to ::stagesComplete, "anchorEditMovesContour" to ::anchorEditMovesContour,
    )
}
