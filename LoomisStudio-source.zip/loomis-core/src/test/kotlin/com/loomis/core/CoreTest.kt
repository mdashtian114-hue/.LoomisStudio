package com.loomis.core

import kotlin.test.Test

class CoreTest {
    @Test fun poseRecovery() = CoreChecks.poseRecovery()
    @Test fun outlierLowersConfidence() = CoreChecks.outlierLowersConfidence()
    @Test fun manualNeedsConfirmation() = CoreChecks.manualNeedsConfirmation()
    @Test fun centerLineFollowsRotation() = CoreChecks.centerLineFollowsRotation()
    @Test fun loomisConstants() = CoreChecks.loomisConstants()
    @Test fun stagesComplete() = CoreChecks.stagesComplete()
    @Test fun anchorEditMovesContour() = CoreChecks.anchorEditMovesContour()
}
