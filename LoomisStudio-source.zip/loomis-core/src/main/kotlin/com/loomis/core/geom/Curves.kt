package com.loomis.core.geom

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin

object Curves {

    /** Centripetal-free uniform Catmull-Rom through [pts]; returns a dense polyline. */
    fun catmullRom(pts: List<Vec2>, closed: Boolean = false, samplesPerSegment: Int = 8): List<Vec2> {
        if (pts.size < 3) return pts
        val out = ArrayList<Vec2>()
        val n = pts.size
        val segs = if (closed) n else n - 1
        fun p(i: Int): Vec2 = if (closed) pts[((i % n) + n) % n] else pts[i.coerceIn(0, n - 1)]
        for (i in 0 until segs) {
            val p0 = p(i - 1); val p1 = p(i); val p2 = p(i + 1); val p3 = p(i + 2)
            for (k in 0 until samplesPerSegment) {
                val t = k.toDouble() / samplesPerSegment
                val t2 = t * t; val t3 = t2 * t
                val x = 0.5 * ((2 * p1.x) + (-p0.x + p2.x) * t + (2 * p0.x - 5 * p1.x + 4 * p2.x - p3.x) * t2 + (-p0.x + 3 * p1.x - 3 * p2.x + p3.x) * t3)
                val y = 0.5 * ((2 * p1.y) + (-p0.y + p2.y) * t + (2 * p0.y - 5 * p1.y + 4 * p2.y - p3.y) * t2 + (-p0.y + 3 * p1.y - 3 * p2.y + p3.y) * t3)
                out.add(Vec2(x, y))
            }
        }
        if (!closed) out.add(pts.last()) else out.add(out.first())
        return out
    }

    fun circle(center: Vec2, r: Double, n: Int = 72): List<Vec2> =
        (0..n).map { i -> val a = 2 * PI * i / n; Vec2(center.x + r * cos(a), center.y + r * sin(a)) }

    /** Ellipse with semi-axes [a] (along angle [rot]) and [b]. */
    fun ellipse(center: Vec2, a: Double, b: Double, rot: Double, n: Int = 72): List<Vec2> =
        (0..n).map { i ->
            val t = 2 * PI * i / n
            val p = Vec2(a * cos(t), b * sin(t)).rotate(rot)
            center + p
        }

    fun quadBezier(p0: Vec2, c: Vec2, p1: Vec2, n: Int = 32): List<Vec2> =
        (0..n).map { i ->
            val t = i.toDouble() / n; val u = 1 - t
            Vec2(u * u * p0.x + 2 * u * t * c.x + t * t * p1.x, u * u * p0.y + 2 * u * t * c.y + t * t * p1.y)
        }

    fun cubicBezier(p0: Vec2, c0: Vec2, c1: Vec2, p1: Vec2, n: Int = 40): List<Vec2> =
        (0..n).map { i ->
            val t = i.toDouble() / n; val u = 1 - t
            val a = u * u * u; val b = 3 * u * u * t; val c = 3 * u * t * t; val d = t * t * t
            Vec2(a * p0.x + b * c0.x + c * c1.x + d * p1.x, a * p0.y + b * c0.y + c * c1.y + d * p1.y)
        }

    fun length(pts: List<Vec2>): Double {
        var s = 0.0
        for (i in 1 until pts.size) s += pts[i].distanceTo(pts[i - 1])
        return s
    }

    /** Resample a polyline to [n] points evenly spaced along its arc length. */
    fun resample(pts: List<Vec2>, n: Int): List<Vec2> {
        if (pts.size < 2 || n < 2) return pts
        val total = length(pts)
        if (total < 1e-9) return List(n) { pts.first() }
        val out = ArrayList<Vec2>(n)
        out.add(pts.first())
        var seg = 1; var acc = 0.0
        for (k in 1 until n - 1) {
            val target = total * k / (n - 1)
            while (seg < pts.size && acc + pts[seg].distanceTo(pts[seg - 1]) < target) {
                acc += pts[seg].distanceTo(pts[seg - 1]); seg++
            }
            if (seg >= pts.size) { out.add(pts.last()); continue }
            val l = pts[seg].distanceTo(pts[seg - 1])
            val t = if (l < 1e-12) 0.0 else (target - acc) / l
            out.add(pts[seg - 1].lerp(pts[seg], t))
        }
        out.add(pts.last())
        return out
    }

    /** Offset a polyline sideways by a per-sample half-width, returning left and right sides. */
    fun offsetSides(spine: List<Vec2>, halfWidth: (Double) -> Double): Pair<List<Vec2>, List<Vec2>> {
        val left = ArrayList<Vec2>(); val right = ArrayList<Vec2>()
        val n = spine.size
        for (i in 0 until n) {
            val a = spine[max(0, i - 1)]; val b = spine[minOf(n - 1, i + 1)]
            val dir = (b - a).normalized()
            val nrm = dir.perp()
            val t = if (n == 1) 0.0 else i.toDouble() / (n - 1)
            val w = halfWidth(t)
            left.add(spine[i] + nrm * w)
            right.add(spine[i] - nrm * w)
        }
        return left to right
    }

    /** Fit a quadratic Bezier through start, a middle point (at t=0.5) and end. */
    fun quadThrough(p0: Vec2, mid: Vec2, p1: Vec2, n: Int = 32): List<Vec2> {
        val c = mid * 2.0 - (p0 + p1) * 0.5
        return quadBezier(p0, c, p1, n)
    }
}
