package com.loomis.core.head

import com.loomis.core.geom.Vec2
import com.loomis.core.head.LoomisHeadModel.Anchor
import kotlin.math.exp

/** Contours extracted from the photo. L/R are image-left / image-right (not the subject's left/right). */
enum class FaceContour {
    FACE, BROW_L_TOP, BROW_L_BOTTOM, BROW_R_TOP, BROW_R_BOTTOM, EYE_L, EYE_R,
    UPPER_LIP_TOP, UPPER_LIP_BOTTOM, LOWER_LIP_TOP, LOWER_LIP_BOTTOM, NOSE_BRIDGE, NOSE_BOTTOM
}

enum class ObservationSource { AUTO, MANUAL, NONE }

/**
 * What the detector (or the user) found in the photo, in image pixels.
 * The Loomis construction is never drawn from these points directly: they are only
 * the data the 3D Loomis model is fitted to (see [HeadFitter]).
 */
data class FaceObservation(
    val anchors: Map<Anchor, Vec2>,
    val contours: Map<FaceContour, List<Vec2>> = emptyMap(),
    /** Raw detector angles in degrees (sign conventions vary by detector; used only as hints). */
    val hintYawDeg: Double? = null,
    val hintPitchDeg: Double? = null,
    val hintRollDeg: Double? = null,
    val source: ObservationSource = ObservationSource.AUTO,
    /** Set when the user has reviewed/edited the points. */
    val userConfirmed: Boolean = false,
) {
    /** Contours that follow an anchor when the user drags it. */
    private fun contoursFor(a: Anchor): List<FaceContour> = when (a) {
        Anchor.BROW_L -> listOf(FaceContour.BROW_L_TOP, FaceContour.BROW_L_BOTTOM)
        Anchor.BROW_R -> listOf(FaceContour.BROW_R_TOP, FaceContour.BROW_R_BOTTOM)
        Anchor.EYE_L -> listOf(FaceContour.EYE_L)
        Anchor.EYE_R -> listOf(FaceContour.EYE_R)
        Anchor.NOSE_TIP -> listOf(FaceContour.NOSE_BRIDGE)
        Anchor.NOSE_BASE -> listOf(FaceContour.NOSE_BOTTOM, FaceContour.NOSE_BRIDGE)
        Anchor.MOUTH_L, Anchor.MOUTH_R, Anchor.MOUTH_C ->
            listOf(FaceContour.UPPER_LIP_TOP, FaceContour.UPPER_LIP_BOTTOM, FaceContour.LOWER_LIP_TOP, FaceContour.LOWER_LIP_BOTTOM)
        Anchor.CHIN -> listOf(FaceContour.FACE)
        Anchor.EAR_L, Anchor.EAR_R -> emptyList()
    }

    /**
     * Move one anchor (manual correction). Attached contour points follow with a Gaussian falloff,
     * so the drawn eye/lip/jaw shapes stay attached to the corrected landmark.
     */
    fun moveAnchor(a: Anchor, to: Vec2): FaceObservation {
        val from = anchors[a] ?: return copy(anchors = anchors + (a to to), source = mergedSource())
        val delta = to - from
        val scale = typicalScale()
        val sigma = when (a) {
            Anchor.CHIN -> scale * 0.45
            Anchor.MOUTH_C, Anchor.MOUTH_L, Anchor.MOUTH_R -> scale * 0.35
            else -> scale * 0.30
        }
        val newContours = contours.toMutableMap()
        for (c in contoursFor(a)) {
            val pts = contours[c] ?: continue
            newContours[c] = pts.map { p ->
                val d = p.distanceTo(from)
                val w = exp(-(d * d) / (2 * sigma * sigma))
                p + delta * w
            }
        }
        return copy(anchors = anchors + (a to to), contours = newContours, source = mergedSource(), userConfirmed = true)
    }

    fun removeAnchor(a: Anchor) = copy(anchors = anchors - a, source = mergedSource(), userConfirmed = true)

    private fun mergedSource() = if (source == ObservationSource.NONE) ObservationSource.MANUAL else source

    /** Rough face size in pixels (eye-to-chin distance or inter-eye distance). */
    fun typicalScale(): Double {
        val el = anchors[Anchor.EYE_L]; val er = anchors[Anchor.EYE_R]; val ch = anchors[Anchor.CHIN]
        if (el != null && er != null && ch != null) return ((el + er) * 0.5).distanceTo(ch)
        if (el != null && er != null) return el.distanceTo(er) * 1.8
        val all = anchors.values.toList()
        if (all.size >= 2) {
            var m = 0.0
            for (i in all.indices) for (j in i + 1 until all.size) m = maxOf(m, all[i].distanceTo(all[j]))
            return m * 0.7
        }
        return 100.0
    }

    companion object {
        val EMPTY = FaceObservation(emptyMap(), source = ObservationSource.NONE)
    }
}
