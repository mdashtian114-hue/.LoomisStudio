package com.loomis.core.imaging

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt

/**
 * Platform-independent pixel operations on ARGB int arrays (Android's Bitmap.getPixels layout).
 * Used to prepare photos for detection (low light / low contrast) and for the optional edge-trace layer.
 */
object ImageOps {

    fun luminance(argb: Int): Int {
        val r = (argb shr 16) and 0xFF; val g = (argb shr 8) and 0xFF; val b = argb and 0xFF
        return (r * 299 + g * 587 + b * 114) / 1000
    }

    /** Brightness (−1..1), contrast (0..3, 1 = unchanged) applied per channel. */
    fun adjust(src: IntArray, brightness: Double, contrast: Double): IntArray {
        val lut = IntArray(256) { v -> (((v - 128) * contrast + 128) + brightness * 255).roundToInt().coerceIn(0, 255) }
        return IntArray(src.size) { i ->
            val c = src[i]
            (c and 0xFF000000.toInt()) or (lut[(c shr 16) and 0xFF] shl 16) or (lut[(c shr 8) and 0xFF] shl 8) or lut[c and 0xFF]
        }
    }

    /**
     * Auto-levels for detection input: stretches the 1st–99th percentile of luminance to the full range
     * and lifts dark images with a gamma. Returns the input unchanged when it's already well exposed.
     */
    fun autoLevels(src: IntArray): IntArray {
        val hist = IntArray(256)
        for (c in src) hist[luminance(c)]++
        val n = src.size.coerceAtLeast(1)
        var lo = 0; var acc = 0
        while (lo < 255 && acc + hist[lo] < n / 100) { acc += hist[lo]; lo++ }
        var hi = 255; acc = 0
        while (hi > 0 && acc + hist[hi] < n / 100) { acc += hist[hi]; hi-- }
        var sum = 0L
        for (v in 0..255) sum += v.toLong() * hist[v]
        val mean = sum.toDouble() / n
        if (hi - lo > 200 && mean in 80.0..180.0) return src
        val range = max(1, hi - lo)
        val gamma = if (mean < 80) 0.7 else 1.0
        val lut = IntArray(256) { v ->
            val t = ((v - lo).toDouble() / range).coerceIn(0.0, 1.0)
            (Math.pow(t, gamma) * 255).roundToInt().coerceIn(0, 255)
        }
        return IntArray(src.size) { i ->
            val c = src[i]
            (c and 0xFF000000.toInt()) or (lut[(c shr 16) and 0xFF] shl 16) or (lut[(c shr 8) and 0xFF] shl 8) or lut[c and 0xFF]
        }
    }

    /**
     * Sobel edge magnitude with non-maximum suppression and a threshold (0..1 of max).
     * Returns ARGB with edges as opaque [color] and transparent elsewhere — a tracing aid, not part of the method.
     */
    fun edges(src: IntArray, w: Int, h: Int, threshold: Double, color: Int): IntArray {
        val lum = IntArray(w * h) { luminance(src[it]) }
        // light blur to suppress noise
        val bl = IntArray(w * h)
        for (y in 0 until h) for (x in 0 until w) {
            var s = 0; var c = 0
            for (dy in -1..1) for (dx in -1..1) {
                val xx = x + dx; val yy = y + dy
                if (xx in 0 until w && yy in 0 until h) { s += lum[yy * w + xx]; c++ }
            }
            bl[y * w + x] = s / c
        }
        val mag = FloatArray(w * h); val dirs = ByteArray(w * h)
        var mx = 1f
        for (y in 1 until h - 1) for (x in 1 until w - 1) {
            fun p(dx: Int, dy: Int) = bl[(y + dy) * w + x + dx]
            val gx = -p(-1, -1) - 2 * p(-1, 0) - p(-1, 1) + p(1, -1) + 2 * p(1, 0) + p(1, 1)
            val gy = -p(-1, -1) - 2 * p(0, -1) - p(1, -1) + p(-1, 1) + 2 * p(0, 1) + p(1, 1)
            val m = sqrt((gx * gx + gy * gy).toFloat())
            mag[y * w + x] = m; if (m > mx) mx = m
            val ax = abs(gx); val ay = abs(gy)
            dirs[y * w + x] = when { ay * 5 < ax * 2 -> 0; ax * 5 < ay * 2 -> 2; (gx > 0) == (gy > 0) -> 1; else -> 3 }.toByte()
        }
        val thr = (threshold.coerceIn(0.01, 1.0) * mx).toFloat()
        val out = IntArray(w * h)
        for (y in 1 until h - 1) for (x in 1 until w - 1) {
            val i = y * w + x
            val m = mag[i]
            if (m < thr) continue
            val (a, b) = when (dirs[i].toInt()) {
                0 -> mag[i - 1] to mag[i + 1]
                2 -> mag[i - w] to mag[i + w]
                1 -> mag[i - w - 1] to mag[i + w + 1]
                else -> mag[i - w + 1] to mag[i + w - 1]
            }
            if (m >= a && m >= b) out[i] = color
        }
        return out
    }

    /** Downscale factor so the longer side is at most [maxSide]. */
    fun fitScale(w: Int, h: Int, maxSide: Int): Double = min(1.0, maxSide.toDouble() / max(w, h))
}
