package com.loomis.core.solve

import kotlin.math.abs
import kotlin.math.max

/**
 * Small dense Levenberg–Marquardt solver with a numeric Jacobian.
 * Adequate for the < 12 parameter / < 60 residual problems used by the pose fitters.
 */
object LevenbergMarquardt {

    data class Result(val params: DoubleArray, val cost: Double, val iterations: Int)

    fun minimize(
        initial: DoubleArray,
        residuals: (DoubleArray) -> DoubleArray,
        maxIter: Int = 80,
        steps: DoubleArray = DoubleArray(initial.size) { 1e-4 },
        lower: DoubleArray? = null,
        upper: DoubleArray? = null,
    ): Result {
        val n = initial.size
        var x = initial.copyOf()
        clampInto(x, lower, upper)
        var r = residuals(x)
        var cost = sumSq(r)
        var lambda = 1e-3
        var it = 0
        while (it < maxIter) {
            it++
            val m = r.size
            // Numeric Jacobian (forward differences).
            val jac = Array(m) { DoubleArray(n) }
            for (j in 0 until n) {
                val h = steps[j] * max(1.0, abs(x[j]))
                val xp = x.copyOf(); xp[j] += h
                val rp = residuals(xp)
                for (i in 0 until m) jac[i][j] = (rp[i] - r[i]) / h
            }
            // Normal equations JᵀJ and Jᵀr.
            val jtj = Array(n) { DoubleArray(n) }
            val jtr = DoubleArray(n)
            for (i in 0 until m) {
                val row = jac[i]
                for (a in 0 until n) {
                    jtr[a] += row[a] * r[i]
                    for (b in a until n) jtj[a][b] += row[a] * row[b]
                }
            }
            for (a in 0 until n) for (b in 0 until a) jtj[a][b] = jtj[b][a]

            var improved = false
            var tries = 0
            while (!improved && tries < 10) {
                tries++
                val aug = Array(n) { a -> DoubleArray(n) { b -> jtj[a][b] + if (a == b) lambda * max(jtj[a][a], 1e-9) else 0.0 } }
                val delta = solve(aug, DoubleArray(n) { k -> -jtr[k] }) ?: break
                val xn = DoubleArray(n) { k -> x[k] + delta[k] }
                clampInto(xn, lower, upper)
                val rn = residuals(xn)
                val cn = sumSq(rn)
                if (cn < cost) {
                    val rel = (cost - cn) / max(cost, 1e-12)
                    x = xn; r = rn; cost = cn
                    lambda = max(lambda / 3.0, 1e-9)
                    improved = true
                    if (rel < 1e-10) return Result(x, cost, it)
                } else {
                    lambda *= 4.0
                }
            }
            if (!improved) break
        }
        return Result(x, cost, it)
    }

    private fun clampInto(x: DoubleArray, lo: DoubleArray?, hi: DoubleArray?) {
        if (lo != null) for (i in x.indices) if (x[i] < lo[i]) x[i] = lo[i]
        if (hi != null) for (i in x.indices) if (x[i] > hi[i]) x[i] = hi[i]
    }

    fun sumSq(r: DoubleArray): Double { var s = 0.0; for (v in r) s += v * v; return s }

    /** Gaussian elimination with partial pivoting. Returns null when singular. */
    fun solve(a: Array<DoubleArray>, b: DoubleArray): DoubleArray? {
        val n = b.size
        val m = Array(n) { i -> a[i].copyOf(n + 1).also { it[n] = b[i] } }
        for (col in 0 until n) {
            var piv = col
            for (r in col + 1 until n) if (abs(m[r][col]) > abs(m[piv][col])) piv = r
            if (abs(m[piv][col]) < 1e-14) return null
            val tmp = m[col]; m[col] = m[piv]; m[piv] = tmp
            for (r in col + 1 until n) {
                val f = m[r][col] / m[col][col]
                if (f == 0.0) continue
                for (c in col..n) m[r][c] -= f * m[col][c]
            }
        }
        val x = DoubleArray(n)
        for (i in n - 1 downTo 0) {
            var s = m[i][n]
            for (j in i + 1 until n) s -= m[i][j] * x[j]
            x[i] = s / m[i][i]
        }
        return x
    }
}
