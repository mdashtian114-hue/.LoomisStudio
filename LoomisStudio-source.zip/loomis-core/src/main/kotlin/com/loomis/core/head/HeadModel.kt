package com.loomis.core.head

import com.loomis.core.geom.Mat3
import com.loomis.core.geom.Vec2
import com.loomis.core.geom.Vec3
import com.loomis.core.model.StrokeRole
import com.loomis.core.model.Stroke
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Subject-specific proportions, all in Loomis units `u` (one third of the face).
 * Loomis' ideal is 1 : 1 : 1; the fitter measures the middle and lower thirds from the photo.
 */
data class HeadProportions(
    val hairThird: Double = 1.0,
    val noseThird: Double = 1.0,
    val chinThird: Double = 1.0,
    /** Eye line below the brow line (ideal ≈ 0.3u, see docs/LOOMIS_SPEC.md §3). */
    val eyeLine: Double = 0.30,
    /** Lip line as a fraction of nose→chin (ideal 1/3). */
    val mouthFraction: Double = 1.0 / 3.0,
) {
    val noseY get() = noseThird
    val chinY get() = noseThird + chinThird
    val mouthY get() = noseThird + chinThird * mouthFraction
    val hairY get() = -hairThird

    companion object { val IDEAL = HeadProportions() }
}

/** Head pose: rotation (radians) + weak-perspective scale (pixels per u) + projected ball centre. */
data class HeadPose(
    val yaw: Double = 0.0,
    val pitch: Double = 0.0,
    val roll: Double = 0.0,
    val scale: Double = 100.0,
    val tx: Double = 0.0,
    val ty: Double = 0.0,
) {
    val rotation: Mat3 by lazy { Mat3.headRotation(yaw, pitch, roll) }
    fun project(p: Vec3): Vec2 { val r = rotation * p; return Vec2(tx + scale * r.x, ty + scale * r.y) }
    /** True when a surface with local normal [n] faces the viewer. */
    fun facesViewer(n: Vec3, eps: Double = 0.0): Boolean = (rotation * n).z > eps
    val center get() = Vec2(tx, ty)
}

/** A 3D polyline with per-point surface normals, used for visibility-aware projection. */
class Path3(val points: List<Vec3>, val normals: List<Vec3>) {
    init { require(points.size == normals.size) }
    companion object {
        /** Catmull-Rom through control points (positions and normals interpolated alike). */
        fun smooth(ctrl: List<Vec3>, ctrlNormals: List<Vec3>, samplesPerSeg: Int = 12): Path3 {
            if (ctrl.size < 3) return Path3(ctrl, ctrlNormals)
            val pts = ArrayList<Vec3>(); val nrm = ArrayList<Vec3>()
            val n = ctrl.size
            fun c(i: Int) = ctrl[i.coerceIn(0, n - 1)]
            fun nn(i: Int) = ctrlNormals[i.coerceIn(0, n - 1)]
            for (i in 0 until n - 1) {
                for (k in 0 until samplesPerSeg) {
                    val t = k.toDouble() / samplesPerSeg
                    pts.add(cr(c(i - 1), c(i), c(i + 1), c(i + 2), t))
                    nrm.add(nn(i).lerp(nn(i + 1), t).normalized())
                }
            }
            pts.add(ctrl.last()); nrm.add(ctrlNormals.last())
            return Path3(pts, nrm)
        }

        private fun cr(p0: Vec3, p1: Vec3, p2: Vec3, p3: Vec3, t: Double): Vec3 {
            val t2 = t * t; val t3 = t2 * t
            fun f(a: Double, b: Double, c: Double, d: Double) =
                0.5 * ((2 * b) + (-a + c) * t + (2 * a - 5 * b + 4 * c - d) * t2 + (-a + 3 * b - 3 * c + d) * t3)
            return Vec3(f(p0.x, p1.x, p2.x, p3.x), f(p0.y, p1.y, p2.y, p3.y), f(p0.z, p1.z, p2.z, p3.z))
        }
    }
}

/**
 * Splits a projected 3D path into visible / hidden runs and returns strokes.
 * Visible runs get [visibleRole]; hidden runs get [StrokeRole.HIDDEN] (or are dropped).
 */
fun Path3.toStrokes(
    pose: HeadPose,
    step: Int,
    visibleRole: StrokeRole = StrokeRole.STRUCTURE,
    keepHidden: Boolean = true,
    rotation: Mat3 = pose.rotation,
    projector: (Vec3) -> Vec2 = { pose.project(it) },
): List<Stroke> {
    val out = ArrayList<Stroke>()
    var run = ArrayList<Vec2>()
    var runVisible: Boolean? = null
    for (i in points.indices) {
        val vis = (rotation * normals[i]).z > -1e-6
        val p = projector(points[i])
        if (runVisible == null) runVisible = vis
        if (vis != runVisible) {
            // close current run, sharing the boundary point so lines stay continuous
            run.add(p)
            emit(out, run, runVisible, visibleRole, keepHidden, step)
            run = arrayListOf(p)
            runVisible = vis
        } else run.add(p)
    }
    if (runVisible != null) emit(out, run, runVisible, visibleRole, keepHidden, step)
    return out
}

private fun emit(out: MutableList<Stroke>, run: List<Vec2>, visible: Boolean, role: StrokeRole, keepHidden: Boolean, step: Int) {
    if (run.size < 2) return
    if (visible) out.add(Stroke(run.toList(), role, stepIndex = step))
    else if (keepHidden) out.add(Stroke(run.toList(), StrokeRole.HIDDEN, stepIndex = step))
}

/**
 * The Loomis head as a 3D construction in units of u.
 * Origin = centre of the cranial ball, x = viewer's right, y = down, z = toward the viewer.
 * See docs/LOOMIS_SPEC.md for every constant.
 */
class LoomisHeadModel(val prop: HeadProportions = HeadProportions.IDEAL) {
    companion object {
        /** Ball radius: the side plane (radius 1u) is ⅔ of the ball's diameter. */
        const val R = 1.5
        const val SIDE_R = 1.0
        val D = sqrt(R * R - SIDE_R * SIDE_R) // ≈ 1.118u, distance of each side cut from centre
        /** Five eye widths across the head at the eye line. */
        val EYE_W = 2 * D / 5.0
        const val CHIN_HALF_W = 0.45
        /** Front of the face: Loomis drops the face line straight down from the front of the ball. */
        const val FACE_FRONT_Z = R
        const val CHIN_FRONT_Z = 1.40
    }

    // ---------------------------------------------------------------- anchors (feature points)
    enum class Anchor { BROW_L, BROW_R, EYE_L, EYE_R, NOSE_TIP, NOSE_BASE, MOUTH_L, MOUTH_R, MOUTH_C, CHIN, EAR_L, EAR_R }

    /** 3D position of a feature anchor. L/R = image left/right at zero yaw (x<0 is image-left). */
    fun anchor(a: Anchor): Vec3 = when (a) {
        Anchor.BROW_L -> Vec3(-0.45, -0.10, 1.36)
        Anchor.BROW_R -> Vec3(0.45, -0.10, 1.36)
        Anchor.EYE_L -> Vec3(-EYE_W, prop.eyeLine, 1.18)
        Anchor.EYE_R -> Vec3(EYE_W, prop.eyeLine, 1.18)
        Anchor.NOSE_TIP -> Vec3(0.0, prop.noseY - 0.15, 1.86)
        Anchor.NOSE_BASE -> Vec3(0.0, prop.noseY, 1.58)
        Anchor.MOUTH_L -> Vec3(-0.42, prop.mouthY, 1.30)
        Anchor.MOUTH_R -> Vec3(0.42, prop.mouthY, 1.30)
        Anchor.MOUTH_C -> Vec3(0.0, prop.mouthY, 1.60)
        Anchor.CHIN -> Vec3(0.0, prop.chinY, 1.36)
        Anchor.EAR_L -> Vec3(-D - 0.05, (0.0 + prop.noseY) / 2, -0.32)
        Anchor.EAR_R -> Vec3(D + 0.05, (0.0 + prop.noseY) / 2, -0.32)
    }

    /** Approximate outward normal at an anchor (used for visibility). */
    fun anchorNormal(a: Anchor): Vec3 = when (a) {
        Anchor.EAR_L -> Vec3(-1.0, 0.0, 0.0)
        Anchor.EAR_R -> Vec3(1.0, 0.0, 0.0)
        Anchor.EYE_L, Anchor.BROW_L, Anchor.MOUTH_L -> Vec3(-0.45, 0.0, 1.0).normalized()
        Anchor.EYE_R, Anchor.BROW_R, Anchor.MOUTH_R -> Vec3(0.45, 0.0, 1.0).normalized()
        else -> Vec3(0.0, 0.0, 1.0)
    }

    // ---------------------------------------------------------------- face cross-section
    /** Half width of the face mass at height y (between the side planes / jaw). */
    fun faceHalfWidth(y: Double): Double = when {
        y <= prop.noseY -> D
        else -> {
            val t = ((y - prop.noseY) / prop.chinThird).coerceIn(0.0, 1.0)
            D + (CHIN_HALF_W - D) * (t * t * 0.55 + t * 0.45)
        }
    }

    /** Depth of the front of the face at height y. */
    fun faceFrontZ(y: Double): Double = when {
        y <= prop.noseY -> FACE_FRONT_Z
        else -> {
            val t = ((y - prop.noseY) / prop.chinThird).coerceIn(0.0, 1.0)
            FACE_FRONT_Z + (CHIN_FRONT_Z - FACE_FRONT_Z) * t
        }
    }

    /** Horizontal section across the face at height y, from angle t0 to t1 (−π/2 = image-left side). */
    fun faceSection(y: Double, t0: Double = -PI / 2, t1: Double = PI / 2, n: Int = 40): Path3 {
        val w = faceHalfWidth(y); val zf = faceFrontZ(y)
        val pts = ArrayList<Vec3>(); val nrm = ArrayList<Vec3>()
        for (i in 0..n) {
            val t = t0 + (t1 - t0) * i / n
            pts.add(Vec3(w * sin(t), y, zf * cos(t)))
            nrm.add(Vec3(sin(t) / w, 0.0, cos(t) / zf).normalized())
        }
        return Path3(pts, nrm)
    }

    fun facePoint(x: Double, y: Double): Vec3 {
        val w = faceHalfWidth(y); val zf = faceFrontZ(y)
        val r = (x / w).coerceIn(-1.0, 1.0)
        return Vec3(x, y, zf * sqrt(max(0.0, 1 - r * r)))
    }

    fun faceNormal(x: Double, y: Double): Vec3 {
        val w = faceHalfWidth(y); val zf = faceFrontZ(y)
        val p = facePoint(x, y)
        return Vec3(p.x / (w * w), 0.0, p.z / (zf * zf)).normalized()
    }

    // ---------------------------------------------------------------- ball & planes
    /** Horizontal circle on the ball at height y, clipped to the side cuts (front arc or full ring). */
    fun ballRing(y: Double, frontOnly: Boolean, n: Int = 90): List<Path3> {
        val rho = sqrt(max(0.0, R * R - y * y))
        val paths = ArrayList<Path3>()
        var pts = ArrayList<Vec3>(); var nrm = ArrayList<Vec3>()
        val start = if (frontOnly) -PI / 2 else -PI
        val end = if (frontOnly) PI / 2 else PI
        for (i in 0..n) {
            val a = start + (end - start) * i / n
            val p = Vec3(rho * sin(a), y, rho * cos(a))
            if (abs(p.x) <= D + 1e-9) { pts.add(p); nrm.add(p.normalized()) }
            else if (pts.size > 1) { paths.add(Path3(pts, nrm)); pts = ArrayList(); nrm = ArrayList() }
            else { pts = ArrayList(); nrm = ArrayList() }
        }
        if (pts.size > 1) paths.add(Path3(pts, nrm))
        return paths
    }

    /** The centre meridian of the ball (x = 0) from the brow at the front, over the crown, to the base of the skull. */
    fun centerMeridian(n: Int = 90): Path3 {
        val pts = ArrayList<Vec3>(); val nrm = ArrayList<Vec3>()
        // angle measured from +z toward -y (up): a=0 front/brow, a=π/2 crown, a=π back, a=3π/2 bottom
        for (i in 0..n) {
            val a = (PI * 1.5) * i / n
            val p = Vec3(0.0, -R * sin(a), R * cos(a))
            pts.add(p); nrm.add(p.normalized())
        }
        return Path3(pts, nrm)
    }

    /** Centre line down the front of the face, brow → chin. */
    fun faceCenterLine(n: Int = 30): Path3 {
        val pts = ArrayList<Vec3>(); val nrm = ArrayList<Vec3>()
        for (i in 0..n) {
            val y = prop.chinY * i / n
            pts.add(Vec3(0.0, y, faceFrontZ(y))); nrm.add(Vec3(0.0, 0.15, 1.0).normalized())
        }
        return Path3(pts, nrm)
    }

    /** Outline of the side plane (circle of radius 1u at x = ±D). side = −1 (image-left) or +1. */
    fun sidePlane(side: Int, n: Int = 72): Path3 {
        val x = side * D
        val pts = (0..n).map { i -> val a = 2 * PI * i / n; Vec3(x, SIDE_R * sin(a), SIDE_R * cos(a)) }
        return Path3(pts, List(pts.size) { Vec3(side.toDouble(), 0.0, 0.0) })
    }

    /** The two diameters quartering the side plane: vertical (ear line) and horizontal (brow line). */
    fun sideCross(side: Int): List<Path3> {
        val x = side * D
        val n = Vec3(side.toDouble(), 0.0, 0.0)
        val v = (0..10).map { Vec3(x, -SIDE_R + 2 * SIDE_R * it / 10.0, 0.0) }
        val h = (0..10).map { Vec3(x, 0.0, -SIDE_R + 2 * SIDE_R * it / 10.0) }
        return listOf(Path3(v, List(v.size) { n }), Path3(h, List(h.size) { n }))
    }

    /** Jaw: from the bottom of the side plane, through the angle of the jaw, to the chin. */
    fun jaw(side: Int): Path3 {
        val s = side.toDouble()
        val ctrl = listOf(
            Vec3(s * D, SIDE_R, 0.0),
            Vec3(s * D * 0.93, prop.noseY + 0.55 * prop.chinThird, 0.12),
            Vec3(s * CHIN_HALF_W, prop.chinY - 0.04, 1.12),
            Vec3(0.0, prop.chinY, CHIN_FRONT_Z),
        )
        val nrm = listOf(Vec3(s, 0.0, 0.0), Vec3(s, 0.35, 0.15).normalized(), Vec3(s * 0.55, 0.45, 0.8).normalized(), Vec3(0.0, 0.4, 1.0).normalized())
        return Path3.smooth(ctrl, nrm)
    }

    /** Edge of the front plane of the face: outer brow corner → cheekbone → chin corner. */
    fun frontPlaneEdge(side: Int): Path3 {
        val s = side.toDouble()
        val bx = 0.74
        val ctrl = listOf(
            Vec3(s * bx, 0.0, sqrt(R * R - bx * bx)),
            Vec3(s * 0.80, prop.noseY * 0.72, 1.18),
            Vec3(s * CHIN_HALF_W, prop.chinY - 0.04, 1.12),
        )
        val n = Vec3(s * 0.55, 0.0, 1.0).normalized()
        return Path3.smooth(ctrl, List(3) { n })
    }

    /** Cheekbone line: from the front edge of the side plane toward the area under the eye. */
    fun cheekbone(side: Int): Path3 {
        val s = side.toDouble()
        val y = prop.eyeLine + 0.32
        val zSide = sqrt(max(0.0, 1 - y * y))
        val ctrl = listOf(Vec3(s * D, y, zSide), Vec3(s * 0.95, y + 0.02, 1.05), Vec3(s * 0.62, y + 0.08, 1.30))
        return Path3.smooth(ctrl, List(3) { Vec3(s * 0.8, 0.0, 0.6).normalized() })
    }

    /** Short vertical tick on the face surface at x, centred on height y. */
    fun tick(x: Double, y: Double, half: Double = 0.07): Path3 {
        val pts = listOf(facePoint(x, y - half), facePoint(x, y + half))
        val n = faceNormal(x, y)
        return Path3(pts, listOf(n, n))
    }

    /** Eye socket: oval recess under the brow. */
    fun eyeSocket(side: Int, n: Int = 40): Path3 {
        val cx = side * EYE_W
        val c = Vec3(cx, prop.eyeLine - 0.02, 1.22)
        val nrm = Vec3(side * 0.35, 0.0, 1.0).normalized()
        val pts = (0..n).map { i -> val a = 2 * PI * i / n; Vec3(c.x + 0.33 * cos(a), c.y + 0.24 * sin(a), c.z + 0.04 * sin(a)) }
        return Path3(pts, List(pts.size) { nrm })
    }

    /** Ideal eyebrow arc sitting on the brow ridge. */
    fun idealBrow(side: Int): Path3 {
        val s = side.toDouble()
        val xs = listOf(0.18, 0.45, 0.78)
        val ys = listOf(-0.04, -0.13, -0.06)
        val ctrl = xs.indices.map { i -> val x = s * xs[i]; val y = ys[i]; Vec3(x, y, sqrt(max(0.0, R * R - x * x - y * y)) - 0.02) }
        return Path3.smooth(ctrl, ctrl.map { it.normalized() })
    }

    /** Ideal almond-shaped eye opening (used when no detected eye contour). */
    fun idealEye(side: Int, n: Int = 32): Path3 {
        val cx = side * EYE_W
        val hw = EYE_W / 2
        val pts = ArrayList<Vec3>()
        for (i in 0..n) {
            val t = 2 * PI * i / n
            val x = cx + hw * cos(t)
            val up = sin(t) < 0
            val h = if (up) 0.11 else 0.075
            val y = prop.eyeLine + h * sin(t)
            pts.add(Vec3(x, y, 1.18 + 0.05 * (1 - abs(cos(t)))))
        }
        val nn = Vec3(side * 0.4, 0.0, 1.0).normalized()
        return Path3(pts, List(pts.size) { nn })
    }

    /** Eyeball centre and radius (u). */
    fun eyeball(side: Int): Pair<Vec3, Double> = Vec3(side * EYE_W, prop.eyeLine, 1.06) to 0.21

    /** Nose as a Loomis wedge: list of edges (root, tip, wings). */
    fun noseWedge(): List<Path3> {
        val root = Vec3(0.0, 0.12, 1.44)
        val tip = anchor(Anchor.NOSE_TIP)
        val base = anchor(Anchor.NOSE_BASE)
        val wl = Vec3(-0.22, prop.noseY - 0.03, 1.48)
        val wr = Vec3(0.22, prop.noseY - 0.03, 1.48)
        val front = Vec3(0.0, 0.0, 1.0)
        val nl = Vec3(-1.0, 0.0, 0.6).normalized(); val nr = Vec3(1.0, 0.0, 0.6).normalized()
        val under = Vec3(0.0, 1.0, 0.4).normalized()
        fun seg(a: Vec3, b: Vec3, n: Vec3) = Path3(listOf(a, b), listOf(n, n))
        return listOf(
            seg(root, tip, front),
            seg(root, wl, nl), seg(root, wr, nr),
            seg(tip, wl, nl), seg(tip, wr, nr),
            Path3(listOf(wl, base, wr), listOf(under, under, under)),
        )
    }

    /** Muzzle (dental arch) the mouth wraps around: horizontal arc at height y. */
    fun muzzleArc(y: Double, halfWidth: Double = 0.5, n: Int = 30): Path3 {
        val cz = 0.62; val r = 0.98
        val pts = (0..n).map { i ->
            val x = -halfWidth + 2 * halfWidth * i / n
            Vec3(x, y, cz + sqrt(max(0.0, r * r - x * x)))
        }
        return Path3(pts, pts.map { Vec3(it.x, 0.0, it.z - cz).normalized() })
    }

    /** Side lines of the muzzle from the nose wings down toward the chin corners. */
    fun muzzleSide(side: Int): Path3 {
        val s = side.toDouble()
        val ctrl = listOf(Vec3(s * 0.26, prop.noseY - 0.05, 1.42), Vec3(s * 0.52, prop.mouthY, 1.24), Vec3(s * 0.40, prop.chinY - 0.2, 1.22))
        return Path3.smooth(ctrl, List(3) { Vec3(s * 0.6, 0.0, 1.0).normalized() })
    }

    /** Loomis ear: on the side plane, behind the vertical centre line, between brow and nose lines, tilted back. */
    fun ear(side: Int): Path3 {
        val x = side * (D + 0.04)
        val top = 0.0; val bottom = prop.noseY
        val h = bottom - top
        // (z, y) outline, z negative = behind the ear line; opening faces forward
        val raw = listOf(
            -0.10 to top + 0.08 * h, -0.30 to top - 0.02 * h, -0.52 to top + 0.10 * h, -0.60 to top + 0.40 * h,
            -0.52 to top + 0.70 * h, -0.38 to top + 0.92 * h, -0.24 to top + 1.0 * h, -0.14 to top + 0.90 * h, -0.12 to top + 0.72 * h,
        )
        // tilt back ~12° about the ear centre
        val cz = -0.33; val cy = top + 0.5 * h; val a = 0.21
        val ctrl = raw.map { (z, y) ->
            val dz = z - cz; val dy = y - cy
            Vec3(x, cy + dz * sin(a) + dy * cos(a), cz + dz * cos(a) - dy * sin(a))
        }
        return Path3.smooth(ctrl, List(ctrl.size) { Vec3(side.toDouble(), 0.0, 0.0) }, 8)
    }

    /** Inner fold of the ear (helix / antihelix suggestion). */
    fun earInner(side: Int): Path3 {
        val x = side * (D + 0.05)
        val h = prop.noseY
        val ctrl = listOf(Vec3(x, 0.22 * h, -0.22), Vec3(x, 0.18 * h, -0.42), Vec3(x, 0.45 * h, -0.47), Vec3(x, 0.72 * h, -0.33))
        return Path3.smooth(ctrl, List(4) { Vec3(side.toDouble(), 0.0, 0.0) }, 8)
    }

    /** Hair mass: Loomis adds thickness over the skull; drawn as a ring slightly larger than the ball. */
    fun hairMassRadius() = R + 0.22
}
