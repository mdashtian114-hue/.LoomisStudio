package com.loomis.core.model

import com.loomis.core.geom.Vec2

/** The layer a generated element belongs to. Matches the editor's layer panel. */
enum class LayerId { PHOTO, STRUCTURE, FINAL, POINTS, USER }

/**
 * Visual role of a stroke. The renderer maps roles to colour/dash/weight;
 * [HIDDEN] is construction that lies on the far side of a volume (drawn dashed and faint).
 */
enum class StrokeRole {
    /** Main construction of the current Loomis stage (ball, side plane, boxes...). */
    STRUCTURE,
    /** Same construction where it passes behind the form. */
    HIDDEN,
    /** Measuring guides: thirds, head units, plumb lines, ticks. */
    MEASURE,
    /** Ideal Loomis position of a feature, used to compare with the subject. */
    IDEAL,
    /** Clean final line drawing. */
    FINAL,
    /** Lighter final line (secondary contour such as lower lip edge). */
    FINAL_LIGHT,
}

data class Stroke(
    val points: List<Vec2>,
    val role: StrokeRole,
    val closed: Boolean = false,
    /** Stage that created the stroke. */
    val stepIndex: Int = 0,
) {
    val layer: LayerId get() = if (role == StrokeRole.FINAL || role == StrokeRole.FINAL_LIGHT) LayerId.FINAL else LayerId.STRUCTURE
}

/** A text label positioned on the canvas; the key is resolved through [com.loomis.core.lesson.Labels]. */
data class Label(val key: String, val at: Vec2, val stepIndex: Int = 0)

/** A guide point (landmark) displayed on the points layer. Editable when [editableId] is not null. */
data class GuidePoint(val at: Vec2, val editableId: String? = null, val stepIndex: Int = 0, val lowConfidence: Boolean = false)

/** Measured value shown in a stage (e.g. "lower third / middle third = 1.08"). */
data class Metric(val key: String, val value: Double, val ideal: Double?, val unit: String = "", val warn: Boolean = false)

data class StepPlan(
    val index: Int,
    val lessonId: String,
    val strokes: List<Stroke>,
    val labels: List<Label> = emptyList(),
    val points: List<GuidePoint> = emptyList(),
    val metrics: List<Metric> = emptyList(),
    /** If true the user must confirm (or correct) before "next" is enabled. */
    val requiresConfirmation: Boolean = false,
    /** Messages (keys) explaining why confirmation is needed. */
    val warnings: List<String> = emptyList(),
    /** The final stage hides construction by default. */
    val hidesStructureByDefault: Boolean = false,
)

enum class DrawingMode { HEAD, FIGURE }

enum class Confidence { HIGH, MEDIUM, LOW }
