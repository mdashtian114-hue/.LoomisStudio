package com.loomis.core.head

import com.loomis.core.geom.Mat3
import com.loomis.core.geom.Vec2
import com.loomis.core.geom.Vec3
import com.loomis.core.model.Stroke
import com.loomis.core.model.StrokeRole
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * The neck as a slightly forward-leaning cylinder. Its top sits under the skull
 * (back of the neck level with the nose line / base of the skull, front of the neck about halfway
 * between the face front and the ear line); its lower end is the pit of the neck.
 * The neck turns only partly with the head, so it is built in a "body" rotation that is a
 * fraction of the head rotation, unless a detected pit of the neck pins its lower end.
 */
class NeckBuilder(private val pose: HeadPose, private val prop: HeadProportions, pitOverride: Vec2?) {
    private val bodyRot: Mat3 = Mat3.headRotation(pose.yaw * 0.35, pose.pitch * 0.25, pose.roll * 0.45)
    private val rx = 0.74
    private val rz = 0.92
    private val top3 = Vec3(0.0, prop.noseY + 0.25, -0.26)
    private val dir = Vec3(0.0, 1.0, -0.12).normalized()
    private val length = 1.75

    private val topC: Vec2 = pose.project(top3)
    private val offset: Vec2
    init {
        val natural = b2(dir * length)
        offset = if (pitOverride != null) {
            // Move the lower ring so its front point lands on the detected pit of the neck.
            pitOverride - (topC + b2(Vec3(0.0, 0.0, rz)))
        } else natural
    }

    private fun b2(v: Vec3): Vec2 { val r = bodyRot * v; return Vec2(r.x * pose.scale, r.y * pose.scale) }
    private fun ring(t: Double) = Vec3(rx * cos(t), 0.0, rz * sin(t))
    private fun ringNormal(t: Double) = Vec3(cos(t) / rx, 0.0, sin(t) / rz).normalized()
    private fun topAt(t: Double) = topC + b2(ring(t))
    private fun botAt(t: Double) = topC + offset + b2(ring(t))

    val pit: Vec2 get() = botAt(PI / 2)

    /** Angles where the cylinder's side turns away from the viewer (its silhouette generators). */
    private fun silhouetteAngles(): List<Double> {
        val out = ArrayList<Double>()
        val n = 360
        for (k in 1..n) {
            val t = 2 * PI * k / n
            // silhouette where the normal is perpendicular to the view direction: rotated normal z = 0
            val z0 = (bodyRot * ringNormal(2 * PI * (k - 1) / n)).z
            val z1 = (bodyRot * ringNormal(t)).z
            if ((z0 <= 0 && z1 > 0) || (z0 > 0 && z1 <= 0)) out.add(t)
        }
        if (out.size < 2) return listOf(0.0, PI)
        return out.take(2)
    }

    fun structure(step: Int): List<Stroke> {
        val s = ArrayList<Stroke>()
        // Lower ring (base of the neck) — visible half solid, back half hidden.
        var run = ArrayList<Vec2>(); var vis: Boolean? = null
        for (k in 0..72) {
            val t = 2 * PI * k / 72
            val v = (bodyRot * ringNormal(t)).z >= 0
            val q = botAt(t)
            if (vis == null) vis = v
            if (v != vis) {
                run.add(q); s.add(Stroke(run, if (vis) StrokeRole.STRUCTURE else StrokeRole.HIDDEN, stepIndex = step))
                run = arrayListOf(q); vis = v
            } else run.add(q)
        }
        if (run.size > 1 && vis != null) s.add(Stroke(run, if (vis) StrokeRole.STRUCTURE else StrokeRole.HIDDEN, stepIndex = step))
        for (t in silhouetteAngles()) s.add(Stroke(listOf(topAt(t), botAt(t)), StrokeRole.STRUCTURE, stepIndex = step))
        // Front of the neck from under the chin to the pit; back of the neck from the base of the skull.
        val underChin = pose.project(Vec3(0.0, prop.chinY - 0.1, 0.72))
        s.add(Stroke(listOf(underChin, pit), StrokeRole.MEASURE, stepIndex = step))
        val baseSkull = pose.project(Vec3(0.0, prop.noseY, -1.2))
        s.add(Stroke(listOf(baseSkull, botAt(-PI / 2)), StrokeRole.MEASURE, stepIndex = step))
        // Sternomastoids: behind the ear (mastoid) → pit of the neck.
        for (side in listOf(-1, 1)) {
            val mastoid3 = Vec3(side * LoomisHeadModel.D * 0.92, prop.noseY - 0.05, -0.42)
            val vis2 = pose.facesViewer(Vec3(side.toDouble(), 0.0, 0.3), -0.2)
            val a = pose.project(mastoid3)
            val mid = a.lerp(pit, 0.5) + (pit - a).perp().normalized() * (pose.scale * 0.06 * side)
            s.add(Stroke(listOf(a, mid, pit), if (vis2) StrokeRole.STRUCTURE else StrokeRole.HIDDEN, stepIndex = step))
        }
        return s
    }

    fun finalLines(step: Int, nearSide: Int): List<Stroke> {
        val s = ArrayList<Stroke>()
        for (t in silhouetteAngles()) {
            // The neck line starts under the jaw / behind the ear rather than inside the skull.
            s.add(Stroke(listOf(topAt(t).lerp(botAt(t), 0.28), botAt(t)), StrokeRole.FINAL, stepIndex = step))
        }
        val mastoid = pose.project(Vec3(nearSide * LoomisHeadModel.D * 0.92, prop.noseY - 0.05, -0.42))
        s.add(Stroke(listOf(mastoid.lerp(pit, 0.35), pit.lerp(mastoid, 0.12)), StrokeRole.FINAL_LIGHT, stepIndex = step))
        return s
    }
}
