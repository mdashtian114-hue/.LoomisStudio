package com.loomis.core.head

import com.loomis.core.geom.Vec2
import com.loomis.core.geom.rad
import com.loomis.core.head.LoomisHeadModel.Anchor
import com.loomis.core.model.Confidence
import com.loomis.core.solve.LevenbergMarquardt
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.sqrt

data class HeadFit(
    val pose: HeadPose,
    val prop: HeadProportions,
    /** RMS reprojection error in units of u (dimensionless, independent of image size). */
    val rmsU: Double,
    val confidence: Confidence,
    /** Warning keys (see Labels) that explain why the user should confirm/correct. */
    val warnings: List<String>,
    /** Per-anchor residual in u, for highlighting badly fitting points. */
    val anchorErrorU: Map<Anchor, Double>,
    val anchorsUsed: Int,
) {
    val needsConfirmation get() = confidence != Confidence.HIGH
}

/**
 * Fits the 3D Loomis head to observed 2D landmarks (weak perspective).
 * Unknowns: yaw, pitch, roll, scale, translation, and the subject's middle & lower facial thirds.
 * The upper third (hairline) cannot be measured reliably and keeps Loomis' ideal value unless the user edits it.
 */
object HeadFitter {

    private val WEIGHTS = mapOf(
        Anchor.EYE_L to 1.0, Anchor.EYE_R to 1.0, Anchor.BROW_L to 0.7, Anchor.BROW_R to 0.7,
        Anchor.NOSE_TIP to 0.9, Anchor.NOSE_BASE to 1.0, Anchor.MOUTH_L to 0.8, Anchor.MOUTH_R to 0.8,
        Anchor.MOUTH_C to 0.9, Anchor.CHIN to 0.8, Anchor.EAR_L to 0.6, Anchor.EAR_R to 0.6,
    )

    /** Minimum anchors for a meaningful fit (8 unknowns, 2 equations per point + priors). */
    const val MIN_ANCHORS = 4

    fun fit(obs: FaceObservation, base: HeadProportions = HeadProportions.IDEAL): HeadFit? {
        val used = obs.anchors.filterKeys { it in WEIGHTS }
        if (used.size < MIN_ANCHORS) return null
        val keys = used.keys.toList()
        val target = keys.map { used.getValue(it) }
        val sc0 = estimateScale(used)

        fun model(p: DoubleArray) = LoomisHeadModel(base.copy(noseThird = p[6], chinThird = p[7]))
        fun residuals(p: DoubleArray): DoubleArray {
            val pose = HeadPose(p[0], p[1], p[2], p[3], p[4], p[5])
            val m = model(p)
            val r = DoubleArray(keys.size * 2 + 2)
            for (i in keys.indices) {
                val w = WEIGHTS.getValue(keys[i])
                val pr = pose.project(m.anchor(keys[i]))
                r[2 * i] = w * (pr.x - target[i].x) / sc0
                r[2 * i + 1] = w * (pr.y - target[i].y) / sc0
            }
            // Loomis' equal thirds act as a weak prior: the photo must "pull" to deviate.
            r[keys.size * 2] = 0.35 * (p[6] - 1.0)
            r[keys.size * 2 + 1] = 0.35 * (p[7] - 1.0)
            return r
        }

        val rollInit = estimateRoll(used)
        val lower = doubleArrayOf(-1.45, -1.05, -PI, sc0 * 0.2, -1e7, -1e7, 0.75, 0.75)
        val upper = doubleArrayOf(1.45, 1.05, PI, sc0 * 5.0, 1e7, 1e7, 1.30, 1.35)

        val yawSeeds = buildList {
            addAll(listOf(0.0, 0.45, -0.45, 0.9, -0.9))
            obs.hintYawDeg?.let { add(rad(it)); add(-rad(it)) }
        }
        val pitchSeeds = buildList {
            addAll(listOf(0.0, 0.3, -0.3))
            obs.hintPitchDeg?.let { add(rad(it)); add(-rad(it)) }
        }

        var best: LevenbergMarquardt.Result? = null
        for (y0 in yawSeeds) for (p0 in pitchSeeds) {
            val init = initialGuess(used, y0, p0, rollInit, sc0)
            val res = LevenbergMarquardt.minimize(init, ::residuals, maxIter = 60, lower = lower, upper = upper)
            if (best == null || res.cost < best.cost) best = res
        }
        val p = best!!.params
        val pose = HeadPose(p[0], p[1], normalizeAngle(p[2]), p[3], p[4], p[5])
        val prop = base.copy(noseThird = p[6], chinThird = p[7])
        val m = LoomisHeadModel(prop)

        // Error in u (scale-independent).
        val errs = HashMap<Anchor, Double>()
        var sq = 0.0
        for (k in keys) {
            val e = pose.project(m.anchor(k)).distanceTo(used.getValue(k)) / pose.scale
            errs[k] = e; sq += e * e
        }
        val rms = sqrt(sq / keys.size)

        val warnings = ArrayList<String>()
        if (obs.source == ObservationSource.MANUAL && !obs.userConfirmed) warnings.add("warn_manual_points")
        if (keys.size < 8) warnings.add("warn_few_points")
        if (abs(pose.yaw) > rad(55.0)) warnings.add("warn_profile_angle")
        if (abs(pose.pitch) > rad(35.0)) warnings.add("warn_extreme_pitch")
        if (rms > 0.12) warnings.add("warn_high_error")
        if (p[6] <= lower[6] + 1e-3 || p[6] >= upper[6] - 1e-3 || p[7] <= lower[7] + 1e-3 || p[7] >= upper[7] - 1e-3)
            warnings.add("warn_proportion_limit")

        val confidence = when {
            rms > 0.12 || keys.size < 6 -> Confidence.LOW
            warnings.any { it != "warn_manual_points" } -> Confidence.MEDIUM
            obs.source == ObservationSource.MANUAL && !obs.userConfirmed -> Confidence.MEDIUM
            rms <= 0.07 -> Confidence.HIGH
            else -> Confidence.MEDIUM
        }
        return HeadFit(pose, prop, rms, confidence, warnings, errs, keys.size)
    }

    /** Re-evaluate quality for a pose the user set by hand (sliders), keeping it exactly. */
    fun evaluate(obs: FaceObservation, pose: HeadPose, prop: HeadProportions): HeadFit {
        val m = LoomisHeadModel(prop)
        val used = obs.anchors.filterKeys { it in WEIGHTS }
        val errs = HashMap<Anchor, Double>()
        var sq = 0.0
        for ((k, v) in used) { val e = pose.project(m.anchor(k)).distanceTo(v) / pose.scale; errs[k] = e; sq += e * e }
        val rms = if (used.isEmpty()) 0.0 else sqrt(sq / used.size)
        val warnings = ArrayList<String>()
        if (used.isNotEmpty() && rms > 0.15) warnings.add("warn_high_error")
        return HeadFit(pose, prop, rms, if (warnings.isEmpty()) Confidence.HIGH else Confidence.MEDIUM, warnings, errs, used.size)
    }

    /** A sensible starting pose when nothing was detected (centred, frontal) for manual alignment. */
    fun defaultPose(imageW: Int, imageH: Int): HeadPose {
        val headPx = minOf(imageW.toDouble(), imageH * 0.8) * 0.55
        val s = headPx / 3.5
        return HeadPose(0.0, 0.0, 0.0, s, imageW / 2.0, imageH * 0.42)
    }

    private fun initialGuess(a: Map<Anchor, Vec2>, yaw: Double, pitch: Double, roll: Double, sc0: Double): DoubleArray {
        val m = LoomisHeadModel()
        val pose0 = HeadPose(yaw, pitch, roll, sc0, 0.0, 0.0)
        // Align centroids of model and observation for the translation.
        var ox = 0.0; var oy = 0.0; var mx = 0.0; var my = 0.0
        for ((k, v) in a) { val pr = pose0.project(m.anchor(k)); ox += v.x; oy += v.y; mx += pr.x; my += pr.y }
        val n = a.size
        return doubleArrayOf(yaw, pitch, roll, sc0, (ox - mx) / n, (oy - my) / n, 1.0, 1.0)
    }

    /** Pixels per u from robust distances. */
    fun estimateScale(a: Map<Anchor, Vec2>): Double {
        val el = a[Anchor.EYE_L]; val er = a[Anchor.EYE_R]
        val bl = a[Anchor.BROW_L]; val br = a[Anchor.BROW_R]
        val nb = a[Anchor.NOSE_BASE]; val ch = a[Anchor.CHIN]
        val brow = when { bl != null && br != null -> (bl + br) * 0.5; bl != null -> bl; br != null -> br; else -> null }
        if (brow != null && ch != null) return brow.distanceTo(ch) / 2.1
        if (brow != null && nb != null) return brow.distanceTo(nb) / 1.1
        if (el != null && er != null) return el.distanceTo(er) / (2 * LoomisHeadModel.EYE_W)
        val pts = a.values.toList()
        var mx = 0.0
        for (i in pts.indices) for (j in i + 1 until pts.size) mx = maxOf(mx, pts[i].distanceTo(pts[j]))
        return maxOf(mx / 2.0, 1.0)
    }

    fun estimateRoll(a: Map<Anchor, Vec2>): Double {
        val l = a[Anchor.EYE_L] ?: a[Anchor.BROW_L] ?: a[Anchor.MOUTH_L]
        val r = a[Anchor.EYE_R] ?: a[Anchor.BROW_R] ?: a[Anchor.MOUTH_R]
        if (l != null && r != null) return atan2(r.y - l.y, r.x - l.x)
        val nb = a[Anchor.NOSE_BASE]; val ch = a[Anchor.CHIN]
        if (nb != null && ch != null) return atan2(-(ch.x - nb.x), ch.y - nb.y)
        return 0.0
    }

    private fun normalizeAngle(a: Double): Double {
        var x = a
        while (x > PI) x -= 2 * PI
        while (x < -PI) x += 2 * PI
        return x
    }
}
