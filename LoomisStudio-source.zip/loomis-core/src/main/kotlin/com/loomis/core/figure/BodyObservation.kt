package com.loomis.core.figure

import com.loomis.core.geom.Vec2

/** The 33 body landmarks (BlazePose / ML Kit order). L/R are the SUBJECT's left/right. */
enum class Joint(val index: Int) {
    NOSE(0), L_EYE_INNER(1), L_EYE(2), L_EYE_OUTER(3), R_EYE_INNER(4), R_EYE(5), R_EYE_OUTER(6),
    L_EAR(7), R_EAR(8), MOUTH_L(9), MOUTH_R(10),
    L_SHOULDER(11), R_SHOULDER(12), L_ELBOW(13), R_ELBOW(14), L_WRIST(15), R_WRIST(16),
    L_PINKY(17), R_PINKY(18), L_INDEX(19), R_INDEX(20), L_THUMB(21), R_THUMB(22),
    L_HIP(23), R_HIP(24), L_KNEE(25), R_KNEE(26), L_ANKLE(27), R_ANKLE(28),
    L_HEEL(29), R_HEEL(30), L_FOOT(31), R_FOOT(32);

    companion object {
        fun byIndex(i: Int) = values().firstOrNull { it.index == i }
        /** Joints the user can edit in the figure analysis stage. */
        val EDITABLE = listOf(NOSE, L_EYE, R_EYE, L_EAR, R_EAR, MOUTH_L, MOUTH_R, L_SHOULDER, R_SHOULDER, L_ELBOW, R_ELBOW,
            L_WRIST, R_WRIST, L_INDEX, R_INDEX, L_HIP, R_HIP, L_KNEE, R_KNEE, L_ANKLE, R_ANKLE, L_HEEL, R_HEEL, L_FOOT, R_FOOT)
    }
}

data class JointObs(val at: Vec2, val likelihood: Double = 1.0, /** relative depth, smaller = closer (detector units ≈ pixels) */ val z: Double = 0.0)

enum class Canon { MALE, FEMALE }

data class BodyObservation(
    val joints: Map<Joint, JointObs>,
    val userConfirmed: Boolean = false,
    val manual: Boolean = false,
    val imageWidth: Int = 0,
    val imageHeight: Int = 0,
) {
    operator fun get(j: Joint): Vec2? = joints[j]?.takeIf { it.likelihood >= MIN_LIKELIHOOD || userConfirmed }?.at
    fun raw(j: Joint): JointObs? = joints[j]

    fun moveJoint(j: Joint, to: Vec2): BodyObservation {
        val old = joints[j]
        return copy(joints = joints + (j to JointObs(to, 1.0, old?.z ?: 0.0)), userConfirmed = true)
    }

    fun lowConfidence(): List<Joint> = joints.filter { it.value.likelihood < 0.6 }.keys.toList()

    companion object {
        const val MIN_LIKELIHOOD = 0.35
        val EMPTY = BodyObservation(emptyMap())

        /** A neutral standing template (8 heads) used when nothing is detected, for manual placement. */
        fun template(w: Int, h: Int): BodyObservation {
            val H = h * 0.85 / 8.0
            val cx = w / 2.0; val top = h * 0.07
            fun at(x: Double, y: Double) = JointObs(Vec2(cx + x * H, top + y * H), 1.0)
            val m = mapOf(
                Joint.NOSE to at(0.0, 0.68), Joint.L_EYE to at(0.13, 0.51), Joint.R_EYE to at(-0.13, 0.51),
                Joint.L_EAR to at(0.33, 0.6), Joint.R_EAR to at(-0.33, 0.6), Joint.MOUTH_L to at(0.12, 0.805), Joint.MOUTH_R to at(-0.12, 0.805),
                Joint.L_SHOULDER to at(0.95, 1.45), Joint.R_SHOULDER to at(-0.95, 1.45),
                Joint.L_ELBOW to at(1.15, 2.9), Joint.R_ELBOW to at(-1.15, 2.9),
                Joint.L_WRIST to at(1.2, 4.05), Joint.R_WRIST to at(-1.2, 4.05),
                Joint.L_INDEX to at(1.22, 4.7), Joint.R_INDEX to at(-1.22, 4.7),
                Joint.L_HIP to at(0.5, 3.85), Joint.R_HIP to at(-0.5, 3.85),
                Joint.L_KNEE to at(0.5, 5.85), Joint.R_KNEE to at(-0.5, 5.85),
                Joint.L_ANKLE to at(0.45, 7.65), Joint.R_ANKLE to at(-0.45, 7.65),
                Joint.L_HEEL to at(0.45, 7.85), Joint.R_HEEL to at(-0.45, 7.85),
                Joint.L_FOOT to at(0.6, 7.95), Joint.R_FOOT to at(-0.6, 7.95),
            )
            return BodyObservation(m, userConfirmed = false, manual = true, imageWidth = w, imageHeight = h)
        }
    }
}
