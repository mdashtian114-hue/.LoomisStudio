package com.loomis.core.head

import com.loomis.core.geom.Curves
import com.loomis.core.geom.Vec2
import com.loomis.core.geom.Vec3
import com.loomis.core.geom.deg
import com.loomis.core.head.LoomisHeadModel.Anchor
import com.loomis.core.model.Confidence
import com.loomis.core.model.GuidePoint
import com.loomis.core.model.Label
import com.loomis.core.model.Metric
import com.loomis.core.model.StepPlan
import com.loomis.core.model.Stroke
import com.loomis.core.model.StrokeRole
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Builds the ordered Loomis head stages from a fitted pose.
 * Every stroke is a projection of the 3D Loomis construction (so it follows the real rotation),
 * except the FINAL feature lines, which trace the subject's detected features when available.
 */
class HeadStepBuilder(
    private val fit: HeadFit,
    private val obs: FaceObservation,
    /** Optional pit of the neck from body detection, in image pixels. */
    private val neckPit: Vec2? = null,
) {
    private val pose = fit.pose
    private val prop = fit.prop
    private val m = LoomisHeadModel(prop)
    private val ideal = LoomisHeadModel(prop.copy(noseThird = 1.0, chinThird = 1.0, eyeLine = HeadProportions.IDEAL.eyeLine, mouthFraction = HeadProportions.IDEAL.mouthFraction))

    /** +1 when the image-right side of the head faces the viewer (head turned toward image-left). */
    private val nearSide: Int = if ((pose.rotation * Vec3(1.0, 0.0, 0.0)).z >= 0) 1 else -1

    private fun p(v: Vec3) = pose.project(v)
    private fun P(path: Path3, step: Int, role: StrokeRole = StrokeRole.STRUCTURE, keepHidden: Boolean = true) =
        path.toStrokes(pose, step, role, keepHidden)

    private fun sideVisible(side: Int) = pose.facesViewer(Vec3(side.toDouble(), 0.0, 0.0), 0.02)

    fun build(): List<StepPlan> = listOf(
        analysis(0), envelope(1), ball(2), sidePlane(3), centerLine(4), browLine(5), thirds(6),
        jawChin(7), frontPlane(8), eyePlacement(9), eyes(10), nose(11), mouth(12), ears(13), neck(14),
        proportions(15), finalDrawing(16),
    )

    // ------------------------------------------------------------------------------------------
    private fun analysis(i: Int): StepPlan {
        val pts = obs.anchors.map { (a, v) ->
            GuidePoint(v, a.name, i, lowConfidence = (fit.anchorErrorU[a] ?: 0.0) > 0.15)
        }
        val strokes = ArrayList<Stroke>()
        val el = obs.anchors[Anchor.EYE_L]; val er = obs.anchors[Anchor.EYE_R]
        if (el != null && er != null) {
            val d = (er - el)
            strokes.add(Stroke(listOf(el - d * 0.35, er + d * 0.35), StrokeRole.MEASURE, stepIndex = i))
        }
        // Facing direction: from the projected ball centre toward the projected front of the face.
        val c = p(Vec3(0.0, 0.0, 0.0)); val f = p(Vec3(0.0, 0.0, LoomisHeadModel.R + 0.9))
        strokes.add(Stroke(listOf(c, f), StrokeRole.MEASURE, stepIndex = i))
        strokes.addAll(arrowHead(c, f, pose.scale * 0.18, i))
        val metrics = listOf(
            Metric("m_yaw", deg(pose.yaw), null, "°"),
            Metric("m_pitch", deg(pose.pitch), null, "°"),
            Metric("m_roll", deg(pose.roll), null, "°"),
            Metric("m_fit_error", fit.rmsU, 0.0, "u", warn = fit.rmsU > 0.12),
            Metric("m_points_used", fit.anchorsUsed.toDouble(), null),
        )
        return StepPlan(
            i, "head_analysis", strokes, labels = listOf(Label("lbl_facing", f, i)), points = pts, metrics = metrics,
            requiresConfirmation = fit.confidence != Confidence.HIGH && !obs.userConfirmed,
            warnings = fit.warnings,
        )
    }

    private fun envelope(i: Int): StepPlan {
        val crown = p(Vec3(0.0, -LoomisHeadModel.R, 0.0))
        val chin = p(m.anchor(Anchor.CHIN))
        val back = p(Vec3(0.0, 0.0, -LoomisHeadModel.R))
        val front = p(Vec3(0.0, 0.0, LoomisHeadModel.R + 0.35))
        val wl = p(Vec3(-LoomisHeadModel.D, 0.0, 0.0)); val wr = p(Vec3(LoomisHeadModel.D, 0.0, 0.0))
        val s = listOf(
            Stroke(listOf(crown, chin), StrokeRole.MEASURE, stepIndex = i),
            Stroke(listOf(wl, wr), StrokeRole.MEASURE, stepIndex = i),
            Stroke(listOf(back, front), StrokeRole.MEASURE, stepIndex = i),
        ) + tickAt(crown, chin, i) + tickAt(chin, crown, i)
        val mid = (crown + chin) * 0.5
        return StepPlan(i, "head_envelope", s,
            labels = listOf(Label("lbl_head_axis", mid, i), Label("lbl_crown", crown, i), Label("lbl_chin", chin, i)),
            metrics = listOf(Metric("m_head_height_u", prop.chinY + LoomisHeadModel.R, 3.5, "u")))
    }

    private fun ball(i: Int): StepPlan {
        val c = pose.center
        val circle = Stroke(Curves.circle(c, LoomisHeadModel.R * pose.scale, 120), StrokeRole.STRUCTURE, closed = true, stepIndex = i)
        return StepPlan(i, "head_ball", listOf(circle), labels = listOf(Label("lbl_ball", c + Vec2(0.0, -LoomisHeadModel.R * pose.scale * 0.75), i)))
    }

    private fun sidePlane(i: Int): StepPlan {
        val s = ArrayList<Stroke>()
        val labels = ArrayList<Label>()
        for (side in listOf(-1, 1)) {
            val vis = sideVisible(side)
            s += P(m.sidePlane(side), i, keepHidden = true).map { if (!vis) it.copy(role = StrokeRole.HIDDEN) else it }
            m.sideCross(side).forEach { cr -> s += P(cr, i).map { if (!vis) it.copy(role = StrokeRole.HIDDEN) else it } }
            if (vis) labels += Label("lbl_side_plane", p(Vec3(side * LoomisHeadModel.D, -0.55, 0.0)), i)
        }
        return StepPlan(i, "head_side_plane", s, labels)
    }

    private fun centerLine(i: Int): StepPlan {
        val s = P(m.centerMeridian(), i) + P(m.faceCenterLine(), i)
        return StepPlan(i, "head_center_line", s, listOf(Label("lbl_center_line", p(Vec3(0.0, -1.1, 1.0)), i)))
    }

    private fun browLine(i: Int): StepPlan {
        val s = ArrayList<Stroke>()
        m.ballRing(0.0, frontOnly = false).forEach { s += P(it, i) }
        return StepPlan(i, "head_brow_line", s, listOf(Label("lbl_brow_line", p(Vec3(-0.9, 0.0, 1.2)), i)))
    }

    private fun thirds(i: Int): StepPlan {
        val s = ArrayList<Stroke>()
        m.ballRing(prop.hairY, frontOnly = true).forEach { s += P(it, i) }
        s += P(m.faceSection(prop.noseY), i)
        s += P(m.faceSection(prop.chinY, -1.0, 1.0), i)
        // Unit ticks along the face centre line: hairline, brow, nose, chin.
        val ys = listOf(prop.hairY, 0.0, prop.noseY, prop.chinY)
        for (y in ys) {
            val z = if (y < 0) kotlin.math.sqrt(LoomisHeadModel.R * LoomisHeadModel.R - y * y) else m.faceFrontZ(y)
            val a = p(Vec3(-0.12, y, z)); val b = p(Vec3(0.12, y, z))
            s += Stroke(listOf(a, b), StrokeRole.MEASURE, stepIndex = i)
        }
        // Equal-thirds measuring bar beside the face (in the head's own vertical direction).
        val off = Vec3(-nearSide * LoomisHeadModel.D * 1.25, 0.0, 0.9)
        val bar = ys.map { y -> p(Vec3(off.x, y, off.z)) }
        s += Stroke(bar, StrokeRole.MEASURE, stepIndex = i)
        bar.forEach { q -> s += tickAcross(q, bar.first(), bar.last(), pose.scale * 0.1, i) }
        val labels = listOf(
            Label("lbl_hairline", p(Vec3(0.55, prop.hairY, 1.0)), i),
            Label("lbl_nose_line", p(m.facePoint(0.6, prop.noseY)), i),
            Label("lbl_chin_line", p(m.facePoint(0.3, prop.chinY)), i),
        )
        val metrics = listOf(
            Metric("m_middle_third", prop.noseThird, 1.0, "u", warn = abs(prop.noseThird - 1) > 0.12),
            Metric("m_lower_third", prop.chinThird, 1.0, "u", warn = abs(prop.chinThird - 1) > 0.12),
        )
        return StepPlan(i, "head_thirds", s, labels, metrics = metrics)
    }

    private fun jawChin(i: Int): StepPlan {
        val s = ArrayList<Stroke>()
        for (side in listOf(-1, 1)) s += P(m.jaw(side), i)
        return StepPlan(i, "head_jaw", s, listOf(Label("lbl_jaw", p(m.jaw(nearSide).points[m.jaw(nearSide).points.size / 3]), i)))
    }

    private fun frontPlane(i: Int): StepPlan {
        val s = ArrayList<Stroke>()
        for (side in listOf(-1, 1)) { s += P(m.frontPlaneEdge(side), i); s += P(m.cheekbone(side), i, keepHidden = false) }
        return StepPlan(i, "head_front_plane", s, listOf(Label("lbl_front_plane", p(m.facePoint(0.0, prop.noseY * 0.55)) + Vec2(0.0, 0.0), i)))
    }

    private fun eyePlacement(i: Int): StepPlan {
        val s = ArrayList<Stroke>()
        s += P(m.faceSection(prop.eyeLine), i)
        for (x in listOf(-LoomisHeadModel.D, -3 * LoomisHeadModel.EYE_W / 2, -LoomisHeadModel.EYE_W / 2, LoomisHeadModel.EYE_W / 2, 3 * LoomisHeadModel.EYE_W / 2, LoomisHeadModel.D)) {
            if (abs(x) >= LoomisHeadModel.D - 1e-6) continue
            s += P(m.tick(x, prop.eyeLine), i, StrokeRole.MEASURE, keepHidden = false)
        }
        for (side in listOf(-1, 1)) {
            s += P(m.eyeSocket(side), i, keepHidden = false)
            s += P(m.idealBrow(side), i, StrokeRole.IDEAL, keepHidden = false)
        }
        val metrics = ArrayList<Metric>()
        val el = obs.contours[FaceContour.EYE_L]; val er = obs.contours[FaceContour.EYE_R]
        if (el != null && er != null && el.size > 3 && er.size > 3) {
            val wl = width(el); val wr = width(er)
            val gap = innerGap(el, er)
            if (wl > 0 && wr > 0) metrics += Metric("m_eye_gap_ratio", gap / ((wl + wr) / 2), 1.0, "", warn = abs(gap / ((wl + wr) / 2) - 1) > 0.3)
        }
        return StepPlan(i, "head_eye_placement", s, listOf(Label("lbl_eye_line", p(m.facePoint(-0.95, prop.eyeLine)), i)), metrics = metrics)
    }

    private fun eyes(i: Int): StepPlan {
        val s = ArrayList<Stroke>()
        for (side in listOf(-1, 1)) {
            val (c, r) = m.eyeball(side)
            if (pose.facesViewer(m.faceNormal(c.x, c.y), -0.1)) {
                s += Stroke(Curves.circle(p(c), r * pose.scale, 40), StrokeRole.STRUCTURE, closed = true, stepIndex = i)
            }
        }
        s += finalEyes(i)
        s += finalBrows(i)
        return StepPlan(i, "head_eyes", s)
    }

    private fun nose(i: Int): StepPlan {
        val s = ArrayList<Stroke>()
        m.noseWedge().forEach { s += P(it, i, keepHidden = false) }
        s += finalNose(i)
        return StepPlan(i, "head_nose", s, listOf(Label("lbl_nose", p(m.anchor(Anchor.NOSE_TIP)) + Vec2(pose.scale * 0.35, 0.0), i)))
    }

    private fun mouth(i: Int): StepPlan {
        val s = ArrayList<Stroke>()
        s += P(m.muzzleArc(prop.mouthY), i, keepHidden = false)
        s += P(m.muzzleArc(prop.noseY + 0.05, 0.42), i, keepHidden = false)
        for (side in listOf(-1, 1)) s += P(m.muzzleSide(side), i, keepHidden = false)
        s += finalMouth(i)
        return StepPlan(i, "head_mouth", s, listOf(Label("lbl_mouth_line", p(m.anchor(Anchor.MOUTH_R)) + Vec2(pose.scale * 0.3, 0.0), i)))
    }

    private fun ears(i: Int): StepPlan {
        val s = ArrayList<Stroke>()
        val labels = ArrayList<Label>()
        if (abs(deg(pose.yaw)) < 12) {
            // Near-frontal: the ears are seen edge-on beside the side planes, between brow and nose lines.
            for (side in listOf(-1, 1)) s += frontalEar(side, i)
        } else {
            for (side in listOf(-1, 1)) {
                if (!sideVisible(side)) continue
                s += P(m.ear(side), i, keepHidden = false)
                s += P(m.ear(side), i, StrokeRole.FINAL, keepHidden = false)
                s += P(m.earInner(side), i, StrokeRole.FINAL_LIGHT, keepHidden = false)
                labels += Label("lbl_ear", p(Vec3(side * LoomisHeadModel.D, prop.noseY + 0.15, -0.6)), i)
            }
        }
        return StepPlan(i, "head_ears", s, labels)
    }

    private fun neck(i: Int): StepPlan {
        val s = ArrayList<Stroke>()
        val nk = NeckBuilder(pose, prop, neckPit)
        s += nk.structure(i)
        s += nk.finalLines(i, nearSide)
        return StepPlan(i, "head_neck", s, listOf(Label("lbl_pit_of_neck", nk.pit, i)))
    }

    private fun proportions(i: Int): StepPlan {
        val s = ArrayList<Stroke>()
        // Ideal (equal thirds, ideal eye and mouth lines) vs measured lines.
        s += P(ideal.faceSection(1.0), i, StrokeRole.IDEAL, keepHidden = false)
        s += P(ideal.faceSection(2.0, -1.0, 1.0), i, StrokeRole.IDEAL, keepHidden = false)
        s += P(ideal.faceSection(ideal.prop.eyeLine, -1.2, 1.2), i, StrokeRole.IDEAL, keepHidden = false)
        s += P(ideal.muzzleArc(ideal.prop.mouthY), i, StrokeRole.IDEAL, keepHidden = false)
        s += P(m.faceSection(prop.noseY), i, StrokeRole.MEASURE, keepHidden = false)
        s += P(m.faceSection(prop.chinY, -1.0, 1.0), i, StrokeRole.MEASURE, keepHidden = false)
        val metrics = ArrayList<Metric>()
        metrics += Metric("m_middle_third", prop.noseThird, 1.0, "u", warn = abs(prop.noseThird - 1) > 0.12)
        metrics += Metric("m_lower_third", prop.chinThird, 1.0, "u", warn = abs(prop.chinThird - 1) > 0.12)
        // Measured eye and mouth lines from the photo, expressed in u along the head's vertical axis.
        measuredY(Anchor.EYE_L, Anchor.EYE_R)?.let { metrics += Metric("m_eye_line", it, HeadProportions.IDEAL.eyeLine, "u", warn = abs(it - HeadProportions.IDEAL.eyeLine) > 0.15) }
        measuredY(Anchor.MOUTH_L, Anchor.MOUTH_R)?.let {
            val frac = (it - prop.noseY) / prop.chinThird
            metrics += Metric("m_mouth_fraction", frac, 1.0 / 3.0, "", warn = abs(frac - 1.0 / 3.0) > 0.12)
        }
        val ml = obs.anchors[Anchor.MOUTH_L]; val mr = obs.anchors[Anchor.MOUTH_R]
        val el = obs.anchors[Anchor.EYE_L]; val er = obs.anchors[Anchor.EYE_R]
        if (ml != null && mr != null && el != null && er != null && abs(deg(pose.yaw)) < 25) {
            val r = ml.distanceTo(mr) / el.distanceTo(er)
            metrics += Metric("m_mouth_to_pupils", r, 0.94, "", warn = abs(r - 0.94) > 0.25)
        }
        val warnings = metrics.filter { it.warn }.map { "note_" + it.key }
        return StepPlan(i, "head_proportions", s, metrics = metrics, warnings = warnings)
    }

    private fun finalDrawing(i: Int): StepPlan {
        val s = ArrayList<Stroke>()
        s += finalFaceOutline(i)
        s += finalCranium(i)
        return StepPlan(i, "head_final", s, hidesStructureByDefault = true)
    }

    // ------------------------------------------------------------------ final feature lines
    private fun finalEyes(i: Int): List<Stroke> {
        val out = ArrayList<Stroke>()
        for ((side, key) in listOf(-1 to FaceContour.EYE_L, 1 to FaceContour.EYE_R)) {
            val c = obs.contours[key]
            if (c != null && c.size >= 6) {
                val closedPts = Curves.catmullRom(c, closed = true, samplesPerSegment = 6)
                out += Stroke(closedPts, StrokeRole.FINAL, closed = true, stepIndex = i)
                val center = Vec2.mean(c)
                val w = width(c)
                val iris = Curves.circle(center, w * 0.21, 48)
                out += clipInside(iris, c).map { Stroke(it, StrokeRole.FINAL, stepIndex = i) }
                // Upper lid crease: the upper half of the eye offset upward.
                val upper = upperHalf(c)
                if (upper.size >= 3) {
                    val lift = w * 0.14
                    val up = headUpDir()
                    out += Stroke(Curves.catmullRom(upper.map { it + up * lift }), StrokeRole.FINAL_LIGHT, stepIndex = i)
                }
            } else {
                val path = m.idealEye(side)
                if (pose.facesViewer(m.faceNormal(side * LoomisHeadModel.EYE_W, prop.eyeLine), -0.05)) {
                    out += Stroke(path.points.map { p(it) }, StrokeRole.FINAL, closed = true, stepIndex = i)
                    val (bc, _) = m.eyeball(side)
                    out += clipInside(Curves.circle(p(bc.copy(z = 1.2)), LoomisHeadModel.EYE_W * 0.42 * pose.scale, 40), path.points.map { p(it) })
                        .map { Stroke(it, StrokeRole.FINAL, stepIndex = i) }
                }
            }
        }
        return out
    }

    private fun finalBrows(i: Int): List<Stroke> {
        val out = ArrayList<Stroke>()
        for ((side, keys) in listOf(-1 to (FaceContour.BROW_L_TOP to FaceContour.BROW_L_BOTTOM), 1 to (FaceContour.BROW_R_TOP to FaceContour.BROW_R_BOTTOM))) {
            val top = obs.contours[keys.first]; val bot = obs.contours[keys.second]
            if (top != null && bot != null && top.size >= 3 && bot.size >= 3) {
                // ML Kit lists both edges in the same direction; join into one closed shape.
                val loop = top + orient(bot, top.last()).reversed()
                out += Stroke(Curves.catmullRom(loop, closed = true, samplesPerSegment = 5), StrokeRole.FINAL_LIGHT, closed = true, stepIndex = i)
            } else {
                out += P(m.idealBrow(side), i, StrokeRole.FINAL_LIGHT, keepHidden = false)
            }
        }
        return out
    }

    private fun finalNose(i: Int): List<Stroke> {
        val out = ArrayList<Stroke>()
        val bottom = obs.contours[FaceContour.NOSE_BOTTOM]
        val bridge = obs.contours[FaceContour.NOSE_BRIDGE]
        val tip = obs.anchors[Anchor.NOSE_TIP] ?: p(m.anchor(Anchor.NOSE_TIP))
        val base = obs.anchors[Anchor.NOSE_BASE] ?: p(m.anchor(Anchor.NOSE_BASE))
        val up = headUpDir(); val right = Vec2(-up.y, up.x) * -1.0
        val sc = pose.scale
        val wingL: Vec2; val wingR: Vec2
        if (bottom != null && bottom.size >= 3) {
            val sorted = bottom.sortedBy { (it - base).dot(right) }
            wingL = sorted.first(); wingR = sorted.last()
        } else {
            wingL = p(Vec3(-0.22, prop.noseY - 0.03, 1.48)); wingR = p(Vec3(0.22, prop.noseY - 0.03, 1.48))
        }
        // Underside of the nose: wing → nostril → columella (base) → nostril → wing.
        val nl = wingL.lerp(base, 0.55) + up * (sc * 0.03)
        val nr = wingR.lerp(base, 0.55) + up * (sc * 0.03)
        out += Stroke(Curves.catmullRom(listOf(wingL, nl, base, nr, wingR)), StrokeRole.FINAL, stepIndex = i)
        // Alae (wings): small arcs above each wing.
        for ((w, sgn) in listOf(wingL to -1.0, wingR to 1.0)) {
            val a = w + up * (sc * 0.16) + right * (sgn * -0.02 * sc)
            val mid = w + up * (sc * 0.10) + right * (sgn * sc * 0.06)
            out += Stroke(Curves.quadThrough(w, mid, a, 16), StrokeRole.FINAL, stepIndex = i)
        }
        // Bridge: one light line on the side turned away from the viewer (where the shadow side is).
        val root = if (bridge != null && bridge.isNotEmpty()) bridge.first() else p(Vec3(0.0, 0.12, 1.44))
        val away = if (pose.yaw >= 0) -1.0 else 1.0
        val off = right * (away * sc * 0.09)
        out += Stroke(Curves.quadThrough(root + off, (root + tip) * 0.5 + off * 1.1, tip + off * 0.8, 20), StrokeRole.FINAL_LIGHT, stepIndex = i)
        return out
    }

    private fun finalMouth(i: Int): List<Stroke> {
        val out = ArrayList<Stroke>()
        val ut = obs.contours[FaceContour.UPPER_LIP_TOP]; val ub = obs.contours[FaceContour.UPPER_LIP_BOTTOM]
        val lt = obs.contours[FaceContour.LOWER_LIP_TOP]; val lb = obs.contours[FaceContour.LOWER_LIP_BOTTOM]
        if (ut != null && ub != null && lb != null && ut.size >= 3 && ub.size >= 3 && lb.size >= 3) {
            out += Stroke(Curves.catmullRom(ut), StrokeRole.FINAL, stepIndex = i)
            val line = if (lt != null && lt.size == ub.size) ub.indices.map { (ub[it] + orient(lt, ub.first())[it]) * 0.5 } else ub
            // The lip line runs corner to corner.
            val corners = listOf(ut.first(), ut.last()).sortedBy { it.distanceTo(line.first()) }
            out += Stroke(Curves.catmullRom(listOf(corners[0]) + line + listOf(corners[1])), StrokeRole.FINAL, stepIndex = i)
            // Lower lip: only the middle part of its lower edge (Loomis: suggest, don't outline).
            val lbo = orient(lb, ut.first())
            val k0 = lbo.size / 5; val k1 = lbo.size - 1 - lbo.size / 5
            if (k1 > k0 + 1) out += Stroke(Curves.catmullRom(lbo.subList(k0, k1 + 1)), StrokeRole.FINAL_LIGHT, stepIndex = i)
        } else {
            val ml = p(m.anchor(Anchor.MOUTH_L)); val mr = p(m.anchor(Anchor.MOUTH_R)); val mc = p(m.anchor(Anchor.MOUTH_C))
            out += Stroke(Curves.quadThrough(ml, mc, mr), StrokeRole.FINAL, stepIndex = i)
            val up = headUpDir() * (pose.scale * 0.1)
            out += Stroke(Curves.catmullRom(listOf(ml, ml.lerp(mc, 0.55) + up * 1.1, mc + up * 0.7, mr.lerp(mc, 0.55) + up * 1.1, mr)), StrokeRole.FINAL, stepIndex = i)
            out += Stroke(Curves.quadThrough(ml.lerp(mc, 0.4) - up * 1.4, mc - up * 1.9, mr.lerp(mc, 0.4) - up * 1.4), StrokeRole.FINAL_LIGHT, stepIndex = i)
        }
        return out
    }

    private fun finalFaceOutline(i: Int): List<Stroke> {
        val face = obs.contours[FaceContour.FACE]
        if (abs(deg(pose.yaw)) > 55) return profileSilhouette(i) + P(m.jaw(nearSide), i, StrokeRole.FINAL, keepHidden = false)
        if (face != null && face.size >= 12) {
            // Keep the part of the contour below the brow line (forehead edge is usually under hair).
            val up = headUpDir()
            val brow = p(Vec3(0.0, 0.0, LoomisHeadModel.R))
            val keep = face.map { q -> (q - brow).dot(up * -1.0) / pose.scale > 0.15 }
            val run = longestCircularRun(face, keep)
            if (run.size >= 4) return listOf(Stroke(Curves.catmullRom(run, samplesPerSegment = 6), StrokeRole.FINAL, stepIndex = i))
        }
        // No contour: use the Loomis jaw and the side-plane silhouette.
        val out = ArrayList<Stroke>()
        for (side in listOf(-1, 1)) out += P(m.jaw(side), i, StrokeRole.FINAL, keepHidden = false)
        return out
    }

    /** Profile line on the centre plane: forehead → nose → lips → chin → under the chin. */
    private fun profileSilhouette(i: Int): List<Stroke> {
        val kN = prop.noseY; val my = prop.mouthY; val cy = prop.chinY
        val ctrl = listOf(
            Vec3(0.0, prop.hairY, 1.12), Vec3(0.0, -0.5, 1.42), Vec3(0.0, -0.02, 1.52), Vec3(0.0, 0.16, 1.42),
            Vec3(0.0, kN - 0.15, 1.86), Vec3(0.0, kN - 0.03, 1.70), Vec3(0.0, kN, 1.56), Vec3(0.0, my - 0.12, 1.62),
            Vec3(0.0, my, 1.54), Vec3(0.0, my + 0.13, 1.60), Vec3(0.0, my + 0.32, 1.44), Vec3(0.0, cy - 0.12, 1.48),
            Vec3(0.0, cy, 1.30), Vec3(0.0, cy - 0.04, 0.85),
        )
        val pts = Curves.catmullRom(ctrl.map { p(it) }, samplesPerSegment = 6)
        return listOf(Stroke(pts, StrokeRole.FINAL, stepIndex = i))
    }

    private fun finalCranium(i: Int): List<Stroke> {
        // Hair mass: ring around the ball, over the top half (relative to the head's own axis).
        val c = pose.center
        val r = m.hairMassRadius() * pose.scale
        val up = headUpDir()
        val a0 = kotlin.math.atan2(up.y, up.x)
        val pts = (0..60).map { k ->
            val a = a0 - PI * 0.62 + (PI * 1.24) * k / 60
            Vec2(c.x + r * kotlin.math.cos(a), c.y + r * kotlin.math.sin(a))
        }
        return listOf(Stroke(pts, StrokeRole.FINAL_LIGHT, stepIndex = i))
    }

    private fun frontalEar(side: Int, i: Int): List<Stroke> {
        // Seen from the front the ear is a narrow C beside the side plane between brow and nose lines.
        val top = p(Vec3(side * (LoomisHeadModel.D + 0.04), 0.02, -0.25))
        val bot = p(Vec3(side * (LoomisHeadModel.D + 0.02), prop.noseY, -0.2))
        val out = (pose.rotation * Vec3(side.toDouble(), 0.0, 0.0)).let { Vec2(it.x, it.y).normalized() }
        val bulge = pose.scale * 0.22
        val mid = (top + bot) * 0.5 + out * bulge
        val pts = Curves.cubicBezier(top, top + out * bulge * 1.1, bot + out * bulge * 0.7, bot, 24)
        return listOf(
            Stroke(pts, StrokeRole.STRUCTURE, stepIndex = i),
            Stroke(pts, StrokeRole.FINAL, stepIndex = i),
            Stroke(listOf(mid - out * bulge * 0.35, mid), StrokeRole.FINAL_LIGHT, stepIndex = i),
        )
    }

    // ------------------------------------------------------------------ helpers
    /** Image-space direction of the head's "up" axis. */
    private fun headUpDir(): Vec2 { val v = pose.rotation * Vec3(0.0, -1.0, 0.0); return Vec2(v.x, v.y).normalized() }

    private fun measuredY(a: Anchor, b: Anchor): Double? {
        val pa = obs.anchors[a] ?: return null; val pb = obs.anchors[b] ?: return null
        val mid = (pa + pb) * 0.5
        val brow = p(Vec3(0.0, 0.0, m.faceFrontZ(0.0)))
        val down = headUpDir() * -1.0
        // Projected length of the head's y axis per u (accounts for pitch foreshortening).
        val unit = (p(Vec3(0.0, 1.0, LoomisHeadModel.R)) - p(Vec3(0.0, 0.0, LoomisHeadModel.R))).length()
        if (unit < 1e-6) return null
        return (mid - brow).dot(down) / unit
    }

    private fun width(c: List<Vec2>): Double {
        var mx = 0.0
        for (a in c) for (b in c) mx = max(mx, a.distanceTo(b))
        return mx
    }

    private fun innerGap(l: List<Vec2>, r: List<Vec2>): Double {
        var mn = Double.MAX_VALUE
        for (a in l) for (b in r) mn = min(mn, a.distanceTo(b))
        return mn
    }

    private fun upperHalf(c: List<Vec2>): List<Vec2> {
        val up = headUpDir()
        val center = Vec2.mean(c)
        val ordered = c.sortedBy { (it - center).dot(Vec2(-up.y, up.x)) }
        return ordered.filter { (it - center).dot(up) > 0 }
    }

    private fun orient(pts: List<Vec2>, start: Vec2): List<Vec2> =
        if (pts.first().distanceTo(start) <= pts.last().distanceTo(start)) pts else pts.reversed()

    private fun longestCircularRun(pts: List<Vec2>, keep: List<Boolean>): List<Vec2> {
        val n = pts.size
        if (keep.all { it }) return pts
        var best = emptyList<Vec2>()
        for (start in 0 until n) {
            if (!keep[start] || keep[(start - 1 + n) % n]) continue
            val run = ArrayList<Vec2>()
            var k = start
            while (keep[k % n] && run.size < n) { run.add(pts[k % n]); k++ }
            if (run.size > best.size) best = run
        }
        return best
    }

    private fun arrowHead(from: Vec2, to: Vec2, size: Double, i: Int): List<Stroke> {
        val d = (to - from).normalized()
        val a = to - d.rotate(0.45) * size; val b = to - d.rotate(-0.45) * size
        return listOf(Stroke(listOf(a, to, b), StrokeRole.MEASURE, stepIndex = i))
    }

    private fun tickAt(at: Vec2, other: Vec2, i: Int): List<Stroke> {
        val d = (other - at).normalized().perp() * (pose.scale * 0.25)
        return listOf(Stroke(listOf(at - d, at + d), StrokeRole.MEASURE, stepIndex = i))
    }

    private fun tickAcross(at: Vec2, a: Vec2, b: Vec2, half: Double, i: Int): List<Stroke> {
        val d = (b - a).normalized().perp() * half
        return listOf(Stroke(listOf(at - d, at + d), StrokeRole.MEASURE, stepIndex = i))
    }

    companion object {
        /** Keep only the parts of a closed polyline that lie inside polygon [poly]. */
        fun clipInside(line: List<Vec2>, poly: List<Vec2>): List<List<Vec2>> {
            val out = ArrayList<List<Vec2>>()
            var cur = ArrayList<Vec2>()
            for (q in line) {
                if (inside(q, poly)) cur.add(q)
                else { if (cur.size >= 2) out.add(cur); cur = ArrayList() }
            }
            if (cur.size >= 2) out.add(cur)
            return out
        }

        fun inside(q: Vec2, poly: List<Vec2>): Boolean {
            var c = false
            var j = poly.size - 1
            for (i in poly.indices) {
                val a = poly[i]; val b = poly[j]
                if ((a.y > q.y) != (b.y > q.y) && q.x < (b.x - a.x) * (q.y - a.y) / (b.y - a.y) + a.x) c = !c
                j = i
            }
            return c
        }
    }
}
