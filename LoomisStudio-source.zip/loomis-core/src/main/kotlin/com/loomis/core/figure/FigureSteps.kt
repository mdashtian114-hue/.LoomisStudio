package com.loomis.core.figure

import com.loomis.core.figure.FigureAnalyzer.Canon8
import com.loomis.core.geom.Curves
import com.loomis.core.geom.Vec2
import com.loomis.core.geom.deg
import com.loomis.core.head.HeadStepBuilder
import com.loomis.core.model.Confidence
import com.loomis.core.model.GuidePoint
import com.loomis.core.model.Label
import com.loomis.core.model.Metric
import com.loomis.core.model.StepPlan
import com.loomis.core.model.Stroke
import com.loomis.core.model.StrokeRole
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Builds Loomis figure stages from the detected joints:
 * gesture → line of action → balance → head units → head → rib cage → pelvis → connection → spine
 * → joints → simple volumes → proportion/foreshortening → anatomical form → final line.
 */
class FigureStepBuilder(private val b: BodyObservation, private val a: FigureAnalysis, private val canon: Canon = Canon.MALE) {
    private val H = a.headUnit

    private data class Limb(val from: Joint, val to: Joint, val r0: Double, val r1: Double, val ideal: Double, val key: String,
                            /** bulges on the outer and inner contour: (position 0..1, size in heads) */
                            val outer: List<Pair<Double, Double>>, val inner: List<Pair<Double, Double>>)

    private val limbs = listOf(
        Limb(Joint.L_SHOULDER, Joint.L_ELBOW, 0.24, 0.16, Canon8.UPPER_ARM, "m_upper_arm", listOf(0.12 to 0.07, 0.55 to 0.03), listOf(0.5 to 0.05)),
        Limb(Joint.R_SHOULDER, Joint.R_ELBOW, 0.24, 0.16, Canon8.UPPER_ARM, "m_upper_arm", listOf(0.12 to 0.07, 0.55 to 0.03), listOf(0.5 to 0.05)),
        Limb(Joint.L_ELBOW, Joint.L_WRIST, 0.18, 0.11, Canon8.FOREARM, "m_forearm", listOf(0.22 to 0.06), listOf(0.32 to 0.04)),
        Limb(Joint.R_ELBOW, Joint.R_WRIST, 0.18, 0.11, Canon8.FOREARM, "m_forearm", listOf(0.22 to 0.06), listOf(0.32 to 0.04)),
        Limb(Joint.L_HIP, Joint.L_KNEE, 0.33, 0.19, Canon8.THIGH, "m_thigh", listOf(0.3 to 0.06), listOf(0.72 to 0.06)),
        Limb(Joint.R_HIP, Joint.R_KNEE, 0.33, 0.19, Canon8.THIGH, "m_thigh", listOf(0.3 to 0.06), listOf(0.72 to 0.06)),
        Limb(Joint.L_KNEE, Joint.L_ANKLE, 0.21, 0.11, Canon8.SHIN, "m_shin", listOf(0.28 to 0.07), listOf(0.36 to 0.06)),
        Limb(Joint.R_KNEE, Joint.R_ANKLE, 0.21, 0.11, Canon8.SHIN, "m_shin", listOf(0.28 to 0.07), listOf(0.36 to 0.06)),
    )

    private fun S(pts: List<Vec2>, role: StrokeRole, i: Int, closed: Boolean = false) = Stroke(pts, role, closed, i)

    fun build(): List<StepPlan> = listOf(
        analysis(0), lineOfAction(1), balance(2), headUnits(3), head(4), ribcage(5), pelvis(6), connect(7), spine(8),
        joints(9), volumes(10), proportions(11), anatomy(12), final(13),
    )

    // ----------------------------------------------------------------------------------------
    private fun analysis(i: Int): StepPlan {
        val pts = Joint.EDITABLE.mapNotNull { j -> b.raw(j)?.let { GuidePoint(it.at, j.name, i, lowConfidence = it.likelihood < 0.6) } }
        val s = ArrayList<Stroke>()
        // Skeleton "stick" frame of the detection, so the user can judge it.
        for ((p, q) in BONES) { val u = b[p]; val v = b[q]; if (u != null && v != null) s += S(listOf(u, v), StrokeRole.MEASURE, i) }
        val m = listOf(
            Metric("m_shoulder_tilt", a.shoulderTiltDeg, null, "°"),
            Metric("m_hip_tilt", a.hipTiltDeg, null, "°"),
        )
        return StepPlan(i, "fig_analysis", s, points = pts, metrics = m,
            requiresConfirmation = a.confidence != Confidence.HIGH && !b.userConfirmed, warnings = a.warnings)
    }

    private fun lineOfAction(i: Int): StepPlan {
        val foot = supportFoot() ?: Vec2(a.hipMid.x, a.lowestY)
        // Curve from the top of the head through the pelvis to the supporting foot.
        val start = a.crown
        val mid = a.hipMid.lerp(a.shoulderMid, 0.25)
        val curve = Curves.quadThrough(start, mid, foot, 48)
        return StepPlan(i, "fig_line_of_action", listOf(S(curve, StrokeRole.STRUCTURE, i)),
            labels = listOf(Label("lbl_line_of_action", curve[curve.size / 3] + Vec2(H * 0.3, 0.0), i)))
    }

    private fun balance(i: Int): StepPlan {
        val s = ArrayList<Stroke>()
        val labels = ArrayList<Label>()
        val metrics = ArrayList<Metric>()
        val warnings = ArrayList<String>()
        // Plumb line from the pit of the neck.
        s += S(listOf(a.pitOfNeck, Vec2(a.pitOfNeck.x, a.lowestY + H * 0.1)), StrokeRole.MEASURE, i)
        labels += Label("lbl_plumb", Vec2(a.pitOfNeck.x, (a.pitOfNeck.y + a.lowestY) / 2), i)
        val ls = b[Joint.L_SHOULDER]!!; val rs = b[Joint.R_SHOULDER]!!; val lh = b[Joint.L_HIP]!!; val rh = b[Joint.R_HIP]!!
        s += S(extend(ls, rs, 0.35), StrokeRole.STRUCTURE, i)
        s += S(extend(lh, rh, 0.6), StrokeRole.STRUCTURE, i)
        labels += Label("lbl_shoulder_line", extend(ls, rs, 0.35).last(), i)
        labels += Label("lbl_hip_line", extend(lh, rh, 0.6).last(), i)
        supportFoot()?.let { f ->
            s += S(Curves.circle(f, H * 0.18, 30), StrokeRole.MEASURE, i, closed = true)
            labels += Label("lbl_support_foot", f + Vec2(0.0, H * 0.35), i)
            val off = abs(f.x - a.pitOfNeck.x) / H
            metrics += Metric("m_balance_offset", off, 0.0, "", warn = a.standing && off > 0.35)
            if (a.standing && off > 0.35) warnings += "note_balance"
        }
        metrics += Metric("m_shoulder_tilt", a.shoulderTiltDeg, null, "°")
        metrics += Metric("m_hip_tilt", a.hipTiltDeg, null, "°")
        return StepPlan(i, "fig_balance", s, labels, metrics = metrics, warnings = warnings)
    }

    private fun headUnits(i: Int): StepPlan {
        val s = ArrayList<Stroke>()
        val labels = ArrayList<Label>()
        // Vertical ruler beside the figure, eight head units from the crown.
        val xs = listOfNotNull(b[Joint.L_SHOULDER]?.x, b[Joint.R_SHOULDER]?.x, b[Joint.L_HIP]?.x, b[Joint.R_HIP]?.x, b[Joint.L_WRIST]?.x, b[Joint.R_WRIST]?.x)
        val x = (xs.minOrNull() ?: a.crown.x) - H * 0.9
        val top = a.crown.y
        s += S(listOf(Vec2(x, top), Vec2(x, top + 8 * H)), StrokeRole.MEASURE, i)
        for (k in 0..8) {
            val y = top + k * H
            s += S(listOf(Vec2(x - H * 0.15, y), Vec2(x + H * 0.15, y)), StrokeRole.MEASURE, i)
            if (k > 0) labels += Label("#$k", Vec2(x - H * 0.35, y - H * 0.5), i)
        }
        // Where this figure's real landmarks fall (crown, chin, crotch, soles).
        val crotch = a.hipMid + a.torsoDown * (H * 0.3)
        for (p in listOf(a.chin, crotch, Vec2(a.hipMid.x, a.lowestY))) s += S(listOf(Vec2(x, p.y), p), StrokeRole.IDEAL, i)
        s += S(Curves.circle(a.headCenter, H / 2, 40), StrokeRole.MEASURE, i, closed = true)
        val metrics = listOf(Metric("m_height_heads", a.heightHeads, 8.0, "", warn = a.standing && abs(a.heightHeads - 8.0) > 0.75))
        val warnings = if (!a.standing) listOf("warn_partial_body").filter { a.lowestY <= a.hipMid.y } else emptyList()
        return StepPlan(i, "fig_head_units", s, labels, metrics = metrics, warnings = warnings)
    }

    private fun head(i: Int): StepPlan {
        val s = ArrayList<Stroke>()
        // Ball (cranium) of radius 0.75u-scaled: in a 3.5u head the ball radius is 1.5u → 0.43 H.
        val ballR = H * 1.5 / 3.5
        val ballC = a.crown - a.headUp * ballR
        s += S(Curves.circle(ballC, ballR, 60), StrokeRole.STRUCTURE, i, closed = true)
        // Facing: compare nose with the midpoint of the ears to find the turn.
        val nose = b[Joint.NOSE]; val le = b[Joint.L_EAR]; val re = b[Joint.R_EAR]
        val right = Vec2(-a.headUp.y, a.headUp.x) * -1.0
        var turn = 0.0
        if (nose != null && le != null && re != null) {
            val earMid = (le + re) * 0.5
            val half = max(le.distanceTo(re) / 2, H * 0.05)
            turn = ((nose - earMid).dot(right) / half).coerceIn(-1.0, 1.0)
        }
        // Centre line as an ellipse arc whose width follows the turn (Loomis ball centre line).
        val arcW = ballR * abs(turn)
        val sign = if (turn >= 0) 1.0 else -1.0
        val cl = (0..30).map { k ->
            val t = -PI / 2 + PI * k / 30
            ballC + right * (sign * arcW * cos(t)) + a.headUp * (-ballR * sin(t))
        }
        s += S(cl, StrokeRole.STRUCTURE, i)
        // Brow line across the ball, and the jaw down to the chin.
        s += S(listOf(ballC - right * ballR, ballC + right * ballR), StrokeRole.STRUCTURE, i)
        val jawL = ballC - right * (ballR * 0.7) - a.headUp * (ballR * 0.55)
        val jawR = ballC + right * (ballR * 0.7) - a.headUp * (ballR * 0.55)
        val chinC = a.chin + right * (sign * arcW * 0.6)
        s += S(Curves.catmullRom(listOf(ballC - right * ballR * 0.78, jawL, chinC, jawR, ballC + right * ballR * 0.78)), StrokeRole.STRUCTURE, i)
        return StepPlan(i, "fig_head", s)
    }

    private fun ribcage(i: Int): StepPlan {
        val (axisTop, axisBot, halfW) = ribcageFrame()
        val egg = egg(axisTop, axisBot, halfW)
        val s = arrayListOf(S(egg, StrokeRole.STRUCTURE, i, closed = true))
        // Cross-section across the middle, showing which way the chest faces.
        val c = axisTop.lerp(axisBot, 0.45)
        val dir = (axisBot - axisTop).normalized()
        val minor = halfW * (0.18 + 0.55 * abs(sin(a.torsoYaw)))
        s += sectionArc(c, dir.perp(), halfW * 0.98, minor, i)
        return StepPlan(i, "fig_ribcage", s, listOf(Label("lbl_ribcage", c + dir.perp() * (halfW * 1.25), i)))
    }

    private fun pelvis(i: Int): StepPlan {
        val q = pelvisQuad()
        val s = arrayListOf(S(listOf(q.tl, q.tr, q.br, q.bl), StrokeRole.STRUCTURE, i, closed = true))
        // Wedge: iliac corners converge to the crotch (front of the pelvis).
        s += S(listOf(q.tl, q.crotch, q.tr), StrokeRole.STRUCTURE, i)
        // Depth: back top edge offset by the torso turn.
        val depth = q.right * (H * 0.55 * sin(a.torsoYaw)) - a.torsoDown * (H * 0.12)
        s += S(listOf(q.tl + depth, q.tr + depth), StrokeRole.HIDDEN, i)
        s += S(listOf(q.tl, q.tl + depth), StrokeRole.HIDDEN, i); s += S(listOf(q.tr, q.tr + depth), StrokeRole.HIDDEN, i)
        return StepPlan(i, "fig_pelvis", s, listOf(Label("lbl_pelvis", q.tr + q.right * (H * 0.3), i)))
    }

    private fun connect(i: Int): StepPlan {
        val (top, bot, halfW) = ribcageFrame()
        val q = pelvisQuad()
        val dir = (bot - top).normalized(); val perp = dir.perp()
        val ribL = bot - dir * (halfW * 0.25) + perp * (halfW * 0.82)
        val ribR = bot - dir * (halfW * 0.25) - perp * (halfW * 0.82)
        val (pl, pr) = if ((q.tl - ribL).length() < (q.tr - ribL).length()) q.tl to q.tr else q.tr to q.tl
        val s = ArrayList<Stroke>()
        for ((u, v) in listOf(ribL to pl, ribR to pr)) {
            val mid = u.lerp(v, 0.5)
            val inward = (a.hipMid.lerp(a.shoulderMid, 0.5) - mid).normalized() * (H * 0.06)
            s += S(Curves.quadThrough(u, mid + inward, v, 20), StrokeRole.STRUCTURE, i)
        }
        // Waist / navel line (Loomis: navel 3 heads down).
        val navel = a.crown + a.torsoDown * (3.0 * H)
        s += S(listOf(navel - perp * (H * 0.45), navel + perp * (H * 0.45)), StrokeRole.MEASURE, i)
        return StepPlan(i, "fig_torso_connect", s)
    }

    private fun spine(i: Int): StepPlan {
        val (top, bot, _) = ribcageFrame()
        val q = pelvisQuad()
        val neckBase = a.chin.lerp(a.pitOfNeck, 0.55)
        val pelvisC = q.tl.lerp(q.tr, 0.5).lerp(q.crotch, 0.35)
        val pts = listOf(a.headCenter.lerp(a.chin, 0.6), neckBase, top.lerp(bot, 0.35), bot, pelvisC)
        val spine = Curves.catmullRom(pts, samplesPerSegment = 10)
        return StepPlan(i, "fig_spine", listOf(S(spine, StrokeRole.STRUCTURE, i)), listOf(Label("lbl_spine", spine[spine.size / 2] + Vec2(H * 0.25, 0.0), i)))
    }

    private fun joints(i: Int): StepPlan {
        val s = ArrayList<Stroke>()
        val pts = ArrayList<GuidePoint>()
        val radii = mapOf(Joint.L_SHOULDER to 0.16, Joint.R_SHOULDER to 0.16, Joint.L_ELBOW to 0.11, Joint.R_ELBOW to 0.11, Joint.L_WRIST to 0.08, Joint.R_WRIST to 0.08,
            Joint.L_HIP to 0.17, Joint.R_HIP to 0.17, Joint.L_KNEE to 0.13, Joint.R_KNEE to 0.13, Joint.L_ANKLE to 0.09, Joint.R_ANKLE to 0.09)
        for ((j, r) in radii) {
            val p = b[j] ?: continue
            s += S(Curves.circle(p, r * H, 28), StrokeRole.STRUCTURE, i, closed = true)
            pts += GuidePoint(p, null, i, lowConfidence = (b.raw(j)?.likelihood ?: 1.0) < 0.6)
        }
        // Mannikin frame lines between joints.
        for ((p, q) in FRAME) { val u = b[p]; val v = b[q]; if (u != null && v != null) s += S(listOf(u, v), StrokeRole.MEASURE, i) }
        return StepPlan(i, "fig_joints", s, points = pts)
    }

    private fun volumes(i: Int): StepPlan {
        val s = ArrayList<Stroke>()
        for (l in limbs) {
            val p = b[l.from] ?: continue; val q = b[l.to] ?: continue
            val f = foreshortening(l, p, q)
            val dir = (q - p).normalized(); val n = dir.perp()
            val r0 = l.r0 * H; val r1 = l.r1 * H
            s += S(listOf(p + n * r0, q + n * r1), StrokeRole.STRUCTURE, i)
            s += S(listOf(p - n * r0, q - n * r1), StrokeRole.STRUCTURE, i)
            val minorK = sqrt(max(0.0, 1 - f * f)).coerceIn(0.12, 1.0)
            s += sectionArc(p, n, r0, r0 * minorK, i)
            s += sectionArc(q, n, r1, r1 * minorK, i)
        }
        s += handsAndFeet(i, StrokeRole.STRUCTURE)
        return StepPlan(i, "fig_limbs", s)
    }

    private fun proportions(i: Int): StepPlan {
        val s = ArrayList<Stroke>()
        val metrics = ArrayList<Metric>()
        val ls = b[Joint.L_SHOULDER]!!; val rs = b[Joint.R_SHOULDER]!!
        val lh = b[Joint.L_HIP]!!; val rh = b[Joint.R_HIP]!!
        val sw = ls.distanceTo(rs) / H * 1.35 // joint centres sit inside the deltoids
        metrics += Metric("m_shoulder_heads", sw, Canon8.shoulderWidth(canon), "", warn = abs(a.torsoYaw) < 0.3 && abs(sw - Canon8.shoulderWidth(canon)) > 0.5)
        val hw = lh.distanceTo(rh) / H * 1.55
        metrics += Metric("m_hip_heads", hw, Canon8.hipWidth(canon), "", warn = abs(a.torsoYaw) < 0.3 && abs(hw - Canon8.hipWidth(canon)) > 0.45)
        for (l in limbs) {
            val p = b[l.from] ?: continue; val q = b[l.to] ?: continue
            val len = p.distanceTo(q) / H
            val f = len / l.ideal
            val foreshort = f < 0.8
            metrics += Metric(l.key, len, l.ideal, "", warn = foreshort)
            // Ideal-length ghost from the same joint, along the same direction (shows how much is foreshortened).
            if (foreshort) {
                val dir = (q - p).normalized()
                s += S(listOf(p, p + dir * (l.ideal * H)), StrokeRole.IDEAL, i)
            }
            s += S(listOf(p, q), if (foreshort) StrokeRole.MEASURE else StrokeRole.STRUCTURE, i)
        }
        metrics += Metric("m_height_heads", a.heightHeads, 8.0, "", warn = a.standing && abs(a.heightHeads - 8.0) > 0.75)
        return StepPlan(i, "fig_proportion_check", s, metrics = metrics)
    }

    private fun anatomy(i: Int): StepPlan = StepPlan(i, "fig_anatomy", anatomyStrokes(i, StrokeRole.STRUCTURE))

    private fun final(i: Int): StepPlan {
        val shapes = anatomyShapes()
        val s = ArrayList<Stroke>()
        // Occlusion: a contour is hidden where it passes inside a nearer body part.
        for (sh in shapes) {
            val occluders = shapes.filter { it !== sh && it.depth < sh.depth - 1e-6 && it.outline.size > 3 }
            for (line in sh.lines) {
                var runs = listOf(Curves.resample(line, max(8, (Curves.length(line) / (H * 0.03)).toInt())))
                for (o in occluders) runs = runs.flatMap { outside(it, o.outline) }
                runs.filter { it.size >= 2 }.forEach { s += S(it, if (sh.light) StrokeRole.FINAL_LIGHT else StrokeRole.FINAL, i) }
            }
        }
        return StepPlan(i, "fig_final", s, hidesStructureByDefault = true)
    }

    // ---------------------------------------------------------------- anatomy contours
    private class Shape(val lines: List<List<Vec2>>, val outline: List<Vec2>, val depth: Double, val light: Boolean = false)

    private fun anatomyStrokes(i: Int, role: StrokeRole): List<Stroke> = anatomyShapes().flatMap { sh -> sh.lines.map { S(it, role, i) } }

    private fun anatomyShapes(): List<Shape> {
        val out = ArrayList<Shape>()
        val center = a.shoulderMid.lerp(a.hipMid, 0.5)
        fun depth(vararg js: Joint) = js.mapNotNull { b.raw(it)?.z }.average().let { if (it.isNaN()) 0.0 else it }
        // Limbs with alternating swells (Loomis: the two contours of a limb never mirror each other).
        for (l in limbs) {
            val p = b[l.from] ?: continue; val q = b[l.to] ?: continue
            val spine = Curves.resample(listOf(p, q), 24)
            val dir = (q - p).normalized(); val n = dir.perp()
            val outerSign = if ((p.lerp(q, 0.5) + n * H - center).length() > (p.lerp(q, 0.5) - n * H - center).length()) 1.0 else -1.0
            fun profile(bumps: List<Pair<Double, Double>>) = { t: Double ->
                var w = (l.r0 + (l.r1 - l.r0) * t) * H
                for ((pos, size) in bumps) { val d = (t - pos) / 0.18; w += size * H * kotlin.math.exp(-d * d) }
                w
            }
            val outerF = profile(l.outer); val innerF = profile(l.inner)
            val (sideA, _) = Curves.offsetSides(spine) { t -> if (outerSign > 0) outerF(t) else innerF(t) }
            val (_, sideB) = Curves.offsetSides(spine) { t -> if (outerSign > 0) innerF(t) else outerF(t) }
            val a1 = Curves.catmullRom(sideA, samplesPerSegment = 3); val b1 = Curves.catmullRom(sideB, samplesPerSegment = 3)
            out += Shape(listOf(a1, b1), a1 + b1.reversed(), depth(l.from, l.to))
        }
        // Torso: armpit → rib cage side → waist → iliac crest → outer hip, on both sides.
        val (top, bot, halfW) = ribcageFrame()
        val q = pelvisQuad()
        val dir = (bot - top).normalized(); val perp = dir.perp()
        val ls = b[Joint.L_SHOULDER]!!; val rs = b[Joint.R_SHOULDER]!!
        val sides = ArrayList<List<Vec2>>()
        for (sgn in listOf(1.0, -1.0)) {
            val shoulder = if ((ls - top).dot(perp) * sgn > 0) ls else rs
            val armpit = shoulder.lerp(top + perp * (sgn * halfW), 0.55) + dir * (H * 0.35)
            val ribSide = top.lerp(bot, 0.55) + perp * (sgn * halfW * 0.97)
            val waist = bot + dir * (H * 0.12) + perp * (sgn * halfW * 0.78)
            val iliac = if ((q.tl - bot).dot(perp) * sgn > 0) q.tl else q.tr
            val hip = (if ((q.bl - bot).dot(perp) * sgn > 0) q.bl else q.br) + perp * (sgn * H * 0.05)
            sides += Curves.catmullRom(listOf(armpit, ribSide, waist, iliac + perp * (sgn * H * 0.04), hip), samplesPerSegment = 8)
        }
        // Neck and trapezius slope to the shoulders, deltoid caps.
        val neckL = a.chin.lerp(a.pitOfNeck, 0.3) + perp * (H * 0.27)
        val neckR = a.chin.lerp(a.pitOfNeck, 0.3) - perp * (H * 0.27)
        val traps = ArrayList<List<Vec2>>()
        for ((nk, sh) in listOf(neckL to (if ((ls - top).dot(perp) > 0) ls else rs), neckR to (if ((ls - top).dot(perp) > 0) rs else ls))) {
            val outward = (sh - a.pitOfNeck).normalized()
            val cap = sh + outward * (H * 0.2)
            traps += Curves.catmullRom(listOf(nk, nk.lerp(sh, 0.45) + dir * (H * 0.12), cap - dir * (H * 0.05), cap + dir * (H * 0.35)), samplesPerSegment = 8)
        }
        val torsoOutline = sides[0] + sides[1].reversed()
        out += Shape(sides + traps, torsoOutline, depth(Joint.L_SHOULDER, Joint.R_SHOULDER, Joint.L_HIP, Joint.R_HIP) + 1.0)
        // Head (ball and jaw) for the final drawing.
        val ballR = H * 1.5 / 3.5
        val ballC = a.crown - a.headUp * ballR
        val right = Vec2(-a.headUp.y, a.headUp.x) * -1.0
        val headLine = Curves.catmullRom(listOf(
            ballC - right * ballR * 0.92 + a.headUp * (ballR * 0.3), ballC - right * ballR * 0.8 - a.headUp * (ballR * 0.5),
            a.chin - right * (ballR * 0.35), a.chin, a.chin + right * (ballR * 0.35),
            ballC + right * ballR * 0.8 - a.headUp * (ballR * 0.5), ballC + right * ballR * 0.92 + a.headUp * (ballR * 0.3)), samplesPerSegment = 6)
        val cranium = (0..40).map { k -> val t = -0.15 * PI + 1.3 * PI * k / 40; ballC + right * (ballR * cos(t)) + a.headUp * (ballR * sin(t)) }
        out += Shape(listOf(headLine, cranium), Curves.circle(ballC, ballR, 30), depth(Joint.NOSE) - 0.5)
        // Hands and feet blocks.
        for (blk in handFootOutlines()) out += Shape(listOf(blk.second), blk.second, blk.first - 0.2, light = false)
        return out
    }

    // ---------------------------------------------------------------- helpers
    private data class PelvisQuad(val tl: Vec2, val tr: Vec2, val br: Vec2, val bl: Vec2, val crotch: Vec2, val right: Vec2)

    private fun pelvisQuad(): PelvisQuad {
        val lh = b[Joint.L_HIP]!!; val rh = b[Joint.R_HIP]!!
        val mid = (lh + rh) * 0.5
        var right = (lh - rh).normalized()
        if (right.length() < 0.5) right = a.torsoDown.perp()
        // Down axis perpendicular to the hip line, oriented like the torso.
        var down = right.perp(); if (down.dot(a.torsoDown) < 0) down = -down
        val jointHalf = lh.distanceTo(rh) / 2
        val topHalf = max(jointHalf * 1.5, H * 0.45 * cos(a.torsoYaw).coerceAtLeast(0.4))
        val tl = mid - down * (H * 0.45) - right * topHalf
        val tr = mid - down * (H * 0.45) + right * topHalf
        val bl = mid + down * (H * 0.22) - right * (topHalf * 0.82)
        val br = mid + down * (H * 0.22) + right * (topHalf * 0.82)
        val crotch = mid + down * (H * 0.36)
        return PelvisQuad(tl, tr, br, bl, crotch, right)
    }

    /** Rib cage axis top/bottom and half width. Loomis: a hollow egg from below the neck to above the navel. */
    private fun ribcageFrame(): Triple<Vec2, Vec2, Double> {
        val ls = b[Joint.L_SHOULDER]!!; val rs = b[Joint.R_SHOULDER]!!
        val top = a.pitOfNeck + a.torsoDown * (H * 0.05)
        val len = (if (canon == Canon.MALE) 1.4 else 1.3) * H
        val bot = top + a.torsoDown * len
        val sw = ls.distanceTo(rs)
        val halfW = max(sw * 0.36, H * 0.45)
        return Triple(top, bot, halfW)
    }

    private fun egg(top: Vec2, bot: Vec2, halfW: Double): List<Vec2> {
        val dir = (bot - top).normalized(); val perp = dir.perp()
        val len = top.distanceTo(bot)
        val c = top.lerp(bot, 0.5)
        return (0..72).map { k ->
            val t = 2 * PI * k / 72
            val v = -cos(t) // -1 at top, 1 at bottom
            val w = halfW * sin(t) * (1.0 - 0.12 * v)
            c + dir * (v * len / 2) + perp * w
        }
    }

    private fun sectionArc(c: Vec2, across: Vec2, major: Double, minor: Double, i: Int): List<Stroke> {
        val ax = across.normalized(); val ay = ax.perp()
        val front = (0..24).map { k -> val t = PI * k / 24; c + ax * (major * cos(t)) + ay * (minor * sin(t)) }
        val back = (0..24).map { k -> val t = PI + PI * k / 24; c + ax * (major * cos(t)) + ay * (minor * sin(t)) }
        return listOf(S(front, StrokeRole.STRUCTURE, i), S(back, StrokeRole.HIDDEN, i))
    }

    private fun foreshortening(l: Limb, p: Vec2, q: Vec2) = (p.distanceTo(q) / (l.ideal * H)).coerceIn(0.0, 1.0)

    private fun supportFoot(): Vec2? = when (a.supportLeft) {
        true -> b[Joint.L_ANKLE]
        false -> b[Joint.R_ANKLE]
        null -> null
    }

    private fun extend(p: Vec2, q: Vec2, k: Double): List<Vec2> { val d = q - p; return listOf(p - d * k, q + d * k) }

    private fun handFootOutlines(): List<Pair<Double, List<Vec2>>> {
        val out = ArrayList<Pair<Double, List<Vec2>>>()
        for ((wrist, elbow, tips) in listOf(
            Triple(Joint.L_WRIST, Joint.L_ELBOW, listOf(Joint.L_INDEX, Joint.L_PINKY, Joint.L_THUMB)),
            Triple(Joint.R_WRIST, Joint.R_ELBOW, listOf(Joint.R_INDEX, Joint.R_PINKY, Joint.R_THUMB)),
        )) {
            val w = b[wrist] ?: continue
            val tipPts = tips.mapNotNull { b[it] }
            val dir = if (tipPts.isNotEmpty()) (Vec2.mean(tipPts) - w).normalized() else b[elbow]?.let { (w - it).normalized() } ?: continue
            val len = H * 0.72; val half = H * 0.2
            val n = dir.perp()
            // Loomis' mitten: palm block + finger mass, slightly wider at the knuckles.
            val pts = listOf(w + n * (half * 0.75), w + dir * (len * 0.5) + n * half, w + dir * len + n * (half * 0.6),
                w + dir * (len * 1.05), w + dir * len - n * (half * 0.6), w + dir * (len * 0.5) - n * half, w - n * (half * 0.75))
            out += (b.raw(wrist)?.z ?: 0.0) to Curves.catmullRom(pts, closed = true, samplesPerSegment = 5)
        }
        for ((ankle, heel, toe) in listOf(Triple(Joint.L_ANKLE, Joint.L_HEEL, Joint.L_FOOT), Triple(Joint.R_ANKLE, Joint.R_HEEL, Joint.R_FOOT))) {
            val an = b[ankle] ?: continue
            val he = b[heel] ?: (an + Vec2(0.0, H * 0.2))
            val to = b[toe] ?: (an + Vec2(H * 0.6, H * 0.25))
            val up = (an - he).normalized().let { if (it.length() < 0.5) Vec2(0.0, -1.0) else it }
            // Wedge: heel, instep high near the ankle, sloping to the toes.
            val pts = listOf(an + up.perp() * (H * 0.1), an.lerp(to, 0.45) + up * (H * 0.08), to + up * (H * 0.05), to, he.lerp(to, 0.5) - up * (H * 0.02), he, he.lerp(an, 0.5) - up.perp() * (H * 0.06))
            out += (b.raw(ankle)?.z ?: 0.0) to Curves.catmullRom(pts, closed = true, samplesPerSegment = 5)
        }
        return out
    }

    private fun handsAndFeet(i: Int, role: StrokeRole) = handFootOutlines().map { S(it.second, role, i, closed = true) }

    private fun outside(line: List<Vec2>, poly: List<Vec2>): List<List<Vec2>> {
        val out = ArrayList<List<Vec2>>()
        var cur = ArrayList<Vec2>()
        for (p in line) {
            if (!HeadStepBuilder.inside(p, poly)) cur.add(p)
            else { if (cur.size >= 2) out.add(cur); cur = ArrayList() }
        }
        if (cur.size >= 2) out.add(cur)
        return out
    }

    companion object {
        val BONES = listOf(
            Joint.L_SHOULDER to Joint.R_SHOULDER, Joint.L_HIP to Joint.R_HIP, Joint.L_SHOULDER to Joint.L_HIP, Joint.R_SHOULDER to Joint.R_HIP,
            Joint.L_SHOULDER to Joint.L_ELBOW, Joint.L_ELBOW to Joint.L_WRIST, Joint.R_SHOULDER to Joint.R_ELBOW, Joint.R_ELBOW to Joint.R_WRIST,
            Joint.L_HIP to Joint.L_KNEE, Joint.L_KNEE to Joint.L_ANKLE, Joint.R_HIP to Joint.R_KNEE, Joint.R_KNEE to Joint.R_ANKLE,
            Joint.L_ANKLE to Joint.L_HEEL, Joint.L_HEEL to Joint.L_FOOT, Joint.R_ANKLE to Joint.R_HEEL, Joint.R_HEEL to Joint.R_FOOT,
            Joint.L_EYE to Joint.R_EYE, Joint.MOUTH_L to Joint.MOUTH_R,
        )
        /** Mannikin frame: shoulder line, hip line, limbs (no torso box; the masses are built separately). */
        val FRAME = listOf(
            Joint.L_SHOULDER to Joint.R_SHOULDER, Joint.L_HIP to Joint.R_HIP,
            Joint.L_SHOULDER to Joint.L_ELBOW, Joint.L_ELBOW to Joint.L_WRIST, Joint.R_SHOULDER to Joint.R_ELBOW, Joint.R_ELBOW to Joint.R_WRIST,
            Joint.L_HIP to Joint.L_KNEE, Joint.L_KNEE to Joint.L_ANKLE, Joint.R_HIP to Joint.R_KNEE, Joint.R_KNEE to Joint.R_ANKLE,
        )
    }
}
