package com.loomis.core.figure

import com.loomis.core.geom.Vec2
import com.loomis.core.geom.deg
import com.loomis.core.model.Confidence
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.max
import kotlin.math.min

/**
 * Turns detected joints into the measurements Loomis' figure method needs:
 * the head unit, crown/chin, supporting leg, shoulder/hip tilts, standing vs. not, torso turn.
 */
data class FigureAnalysis(
    val headUnit: Double,
    val headUnitSource: String,
    val crown: Vec2,
    val chin: Vec2,
    val headCenter: Vec2,
    val headUp: Vec2,
    val pitOfNeck: Vec2,
    val shoulderMid: Vec2,
    val hipMid: Vec2,
    /** Unit vector from shoulder midpoint toward hip midpoint. */
    val torsoDown: Vec2,
    val supportLeft: Boolean?,
    val lowestY: Double,
    val heightHeads: Double,
    val standing: Boolean,
    val shoulderTiltDeg: Double,
    val hipTiltDeg: Double,
    /** Approximate turn of the torso (radians, from shoulder depth difference); 0 = facing viewer. */
    val torsoYaw: Double,
    val confidence: Confidence,
    val warnings: List<String>,
)

object FigureAnalyzer {

    /** Loomis eight-head canon in head units (see docs/LOOMIS_SPEC.md §5). */
    object Canon8 {
        const val UPPER_ARM = 1.5
        const val FOREARM = 1.25
        const val THIGH = 2.0
        const val SHIN = 1.9
        const val PIT_OF_NECK = 1.25   // from the crown
        const val HIP_JOINT = 3.8
        fun shoulderWidth(c: Canon) = if (c == Canon.MALE) 7.0 / 3.0 else 2.0
        fun hipWidth(c: Canon) = if (c == Canon.MALE) 1.5 else 1.75
    }

    fun analyze(b: BodyObservation): FigureAnalysis? {
        val ls = b[Joint.L_SHOULDER]; val rs = b[Joint.R_SHOULDER]
        val lh = b[Joint.L_HIP]; val rh = b[Joint.R_HIP]
        if (ls == null || rs == null || lh == null || rh == null) return null
        val warnings = ArrayList<String>()
        val shoulderMid = (ls + rs) * 0.5
        val hipMid = (lh + rh) * 0.5
        val torsoLen = shoulderMid.distanceTo(hipMid)
        val torsoDown = (hipMid - shoulderMid).normalized()

        // ---- head unit -------------------------------------------------------------------
        val le = b[Joint.L_EYE]; val re = b[Joint.R_EYE]; val ml = b[Joint.MOUTH_L]; val mr = b[Joint.MOUTH_R]
        val nose = b[Joint.NOSE]
        var H: Double
        var src: String
        var headUp: Vec2
        val eyeMid = if (le != null && re != null) (le + re) * 0.5 else le ?: re
        val mouthMid = if (ml != null && mr != null) (ml + mr) * 0.5 else ml ?: mr
        val torsoEstimate = torsoLen / (Canon8.HIP_JOINT - Canon8.PIT_OF_NECK - 0.05)
        if (eyeMid != null && mouthMid != null && eyeMid.distanceTo(mouthMid) > 2) {
            // Loomis head: eye line 0.3u, lip line 1.33u below the brow, head = 3.5u → H ≈ 3.39 × eye–mouth.
            H = eyeMid.distanceTo(mouthMid) * 3.39
            headUp = (eyeMid - mouthMid).normalized()
            src = "face"
            // Face foreshortened (head tilted far) → fall back on torso if they disagree badly.
            if (H < torsoEstimate * 0.6) { H = torsoEstimate; src = "torso" }
        } else {
            H = torsoEstimate
            headUp = -torsoDown
            src = "torso"
        }
        val headCenter: Vec2
        val crown: Vec2; val chin: Vec2
        if (eyeMid != null) {
            crown = eyeMid + headUp * (H * (1.5 + 0.3) / 3.5)
            chin = eyeMid - headUp * (H * (2.0 - 0.3) / 3.5)
        } else if (nose != null) {
            crown = nose + headUp * (H * 0.62); chin = nose - headUp * (H * 0.38)
        } else {
            chin = shoulderMid - torsoDown * (H * 0.3); crown = chin + headUp * H
        }
        headCenter = (crown + chin) * 0.5
        val pit = shoulderMid + torsoDown * (H * 0.08)

        // ---- feet, support, standing -------------------------------------------------------
        val feet = listOf(Joint.L_ANKLE, Joint.R_ANKLE, Joint.L_HEEL, Joint.R_HEEL, Joint.L_FOOT, Joint.R_FOOT).mapNotNull { b[it] }
        val lowestY = feet.maxOfOrNull { it.y } ?: (b[Joint.L_KNEE]?.y ?: hipMid.y)
        if (feet.isEmpty()) warnings.add("warn_partial_body")
        val la = b[Joint.L_ANKLE]; val ra = b[Joint.R_ANKLE]
        val supportLeft: Boolean? = when {
            la != null && ra != null -> {
                // Supporting foot: nearer to the plumb line from the pit of the neck, and on the higher-hip side.
                val dl = abs(la.x - pit.x); val dr = abs(ra.x - pit.x)
                val hipBias = (rh.y - lh.y) / H * 0.6 // left hip higher → positive → favours left
                (dr - dl) / H + hipBias > 0
            }
            la != null -> true
            ra != null -> false
            else -> null
        }
        val lk = b[Joint.L_KNEE]; val rk = b[Joint.R_KNEE]
        val standing = if (lk != null && la != null) {
            val legLen = lh.distanceTo(lk) + lk.distanceTo(la)
            (la.y - lh.y) > 0.8 * legLen && torsoDown.y > 0.85
        } else false
        val heightHeads = (lowestY - crown.y) / H

        // ---- tilts and torso turn ------------------------------------------------------------
        fun tilt(a: Vec2, c: Vec2): Double {
            val v = if (a.x < c.x) c - a else a - c
            return deg(atan2(v.y, v.x))
        }
        val zl = b.raw(Joint.L_SHOULDER)?.z ?: 0.0; val zr = b.raw(Joint.R_SHOULDER)?.z ?: 0.0
        val shoulderVec = ls - rs
        // Positive when the subject's left shoulder is nearer the viewer (detector z: smaller = closer).
        val torsoYaw = atan2(zr - zl, max(shoulderVec.length(), 1.0))

        if (b.lowConfidence().isNotEmpty() && !b.userConfirmed) warnings.add("warn_low_joint_confidence")
        if (b.manual && !b.userConfirmed) warnings.add("warn_manual_points")
        val conf = when {
            b.joints.size < 12 -> Confidence.LOW
            warnings.isNotEmpty() -> Confidence.MEDIUM
            else -> Confidence.HIGH
        }
        return FigureAnalysis(H, src, crown, chin, headCenter, headUp, pit, shoulderMid, hipMid, torsoDown, supportLeft, lowestY,
            heightHeads, standing, tilt(ls, rs), tilt(lh, rh), torsoYaw, conf, warnings)
    }

    fun clamp01(v: Double) = min(1.0, max(0.0, v))
}
