package com.loomis.core.geom

import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin
import kotlin.math.sqrt

/** 2D point/vector in image pixel space (x right, y down). */
data class Vec2(val x: Double, val y: Double) {
    operator fun plus(o: Vec2) = Vec2(x + o.x, y + o.y)
    operator fun minus(o: Vec2) = Vec2(x - o.x, y - o.y)
    operator fun times(k: Double) = Vec2(x * k, y * k)
    operator fun div(k: Double) = Vec2(x / k, y / k)
    operator fun unaryMinus() = Vec2(-x, -y)
    fun length() = hypot(x, y)
    fun dot(o: Vec2) = x * o.x + y * o.y
    fun cross(o: Vec2) = x * o.y - y * o.x
    fun normalized(): Vec2 { val l = length(); return if (l < 1e-12) Vec2(0.0, 0.0) else this / l }
    /** Perpendicular rotated +90° (in y-down space this points "right" of direction). */
    fun perp() = Vec2(-y, x)
    fun angle() = atan2(y, x)
    fun distanceTo(o: Vec2) = (this - o).length()
    fun lerp(o: Vec2, t: Double) = Vec2(x + (o.x - x) * t, y + (o.y - y) * t)
    fun rotate(a: Double): Vec2 { val c = cos(a); val s = sin(a); return Vec2(x * c - y * s, x * s + y * c) }

    companion object {
        val ZERO = Vec2(0.0, 0.0)
        fun mean(points: Collection<Vec2>): Vec2 {
            require(points.isNotEmpty())
            var sx = 0.0; var sy = 0.0
            for (p in points) { sx += p.x; sy += p.y }
            return Vec2(sx / points.size, sy / points.size)
        }
    }
}

/** 3D vector in head/body local space: x = viewer's right at zero rotation, y = down, z = toward viewer. */
data class Vec3(val x: Double, val y: Double, val z: Double) {
    operator fun plus(o: Vec3) = Vec3(x + o.x, y + o.y, z + o.z)
    operator fun minus(o: Vec3) = Vec3(x - o.x, y - o.y, z - o.z)
    operator fun times(k: Double) = Vec3(x * k, y * k, z * k)
    operator fun div(k: Double) = Vec3(x / k, y / k, z / k)
    fun dot(o: Vec3) = x * o.x + y * o.y + z * o.z
    fun cross(o: Vec3) = Vec3(y * o.z - z * o.y, z * o.x - x * o.z, x * o.y - y * o.x)
    fun length() = sqrt(x * x + y * y + z * z)
    fun normalized(): Vec3 { val l = length(); return if (l < 1e-12) Vec3(0.0, 0.0, 0.0) else this / l }
    fun lerp(o: Vec3, t: Double) = Vec3(x + (o.x - x) * t, y + (o.y - y) * t, z + (o.z - z) * t)
    fun xy() = Vec2(x, y)
}

/** Row-major 3x3 matrix. */
class Mat3(val m: DoubleArray) {
    init { require(m.size == 9) }
    operator fun times(v: Vec3) = Vec3(
        m[0] * v.x + m[1] * v.y + m[2] * v.z,
        m[3] * v.x + m[4] * v.y + m[5] * v.z,
        m[6] * v.x + m[7] * v.y + m[8] * v.z
    )
    operator fun times(o: Mat3): Mat3 {
        val r = DoubleArray(9)
        for (i in 0 until 3) for (j in 0 until 3) {
            var s = 0.0
            for (k in 0 until 3) s += m[i * 3 + k] * o.m[k * 3 + j]
            r[i * 3 + j] = s
        }
        return Mat3(r)
    }
    fun transpose() = Mat3(doubleArrayOf(m[0], m[3], m[6], m[1], m[4], m[7], m[2], m[5], m[8]))

    companion object {
        val IDENTITY = Mat3(doubleArrayOf(1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0))
        /** Rotation about the vertical (y) axis. Positive yaw turns the face toward the viewer's right. */
        fun rotY(a: Double): Mat3 { val c = cos(a); val s = sin(a); return Mat3(doubleArrayOf(c, 0.0, s, 0.0, 1.0, 0.0, -s, 0.0, c)) }
        /** Rotation about x. Positive pitch tilts the face downward (chin toward chest) in y-down space. */
        fun rotX(a: Double): Mat3 { val c = cos(a); val s = sin(a); return Mat3(doubleArrayOf(1.0, 0.0, 0.0, 0.0, c, s, 0.0, -s, c)) }
        /** Rotation in the picture plane. Positive roll is clockwise on screen (y down). */
        fun rotZ(a: Double): Mat3 { val c = cos(a); val s = sin(a); return Mat3(doubleArrayOf(c, -s, 0.0, s, c, 0.0, 0.0, 0.0, 1.0)) }
        /** Combined head rotation: yaw first (about the neck), then pitch (nod), then roll (tilt in picture). */
        fun headRotation(yaw: Double, pitch: Double, roll: Double): Mat3 = rotZ(roll) * rotX(pitch) * rotY(yaw)
    }
}

fun deg(rad: Double) = rad * 180.0 / Math.PI
fun rad(deg: Double) = deg * Math.PI / 180.0
fun clamp(v: Double, lo: Double, hi: Double) = if (v < lo) lo else if (v > hi) hi else v
