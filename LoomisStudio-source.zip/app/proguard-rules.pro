# ML Kit ships its own consumer rules. Keep engine data classes used reflectively by nothing — none needed.
-dontwarn com.google.mlkit.**
