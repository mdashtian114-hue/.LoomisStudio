package com.loomis.studio.data

import android.content.Context
import com.loomis.core.figure.Canon
import com.loomis.core.lesson.Lang

data class AppSettings(
    val lang: Lang = Lang.FA,
    val lessonsDefault: Boolean = true,
    val autoLevels: Boolean = true,
    val structureColor: Int = 0xFF2D6CDF.toInt(),
    val finalColor: Int = 0xFF1A1A1A.toInt(),
    val lineScale: Float = 1f,
    val canon: Canon = Canon.MALE,
)

class SettingsStore(context: Context) {
    private val prefs = context.getSharedPreferences("settings", Context.MODE_PRIVATE)

    fun load() = AppSettings(
        lang = runCatching { Lang.valueOf(prefs.getString("lang", "FA")!!) }.getOrDefault(Lang.FA),
        lessonsDefault = prefs.getBoolean("lessons", true),
        autoLevels = prefs.getBoolean("autoLevels", true),
        structureColor = prefs.getInt("structureColor", 0xFF2D6CDF.toInt()),
        finalColor = prefs.getInt("finalColor", 0xFF1A1A1A.toInt()),
        lineScale = prefs.getFloat("lineScale", 1f),
        canon = runCatching { Canon.valueOf(prefs.getString("canon", "MALE")!!) }.getOrDefault(Canon.MALE),
    )

    fun save(s: AppSettings) {
        prefs.edit()
            .putString("lang", s.lang.name).putBoolean("lessons", s.lessonsDefault).putBoolean("autoLevels", s.autoLevels)
            .putInt("structureColor", s.structureColor).putInt("finalColor", s.finalColor).putFloat("lineScale", s.lineScale)
            .putString("canon", s.canon.name)
            .apply()
    }
}
