package com.loomis.studio.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateCentroid
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.layout.onSizeChanged
import com.loomis.core.geom.Vec2
import kotlin.math.min

/** Image ↔ screen transform shared by the canvas and its gesture handler. */
@Stable
class ViewTransform {
    var scale by mutableFloatStateOf(1f)
    var offset by mutableStateOf(Offset.Zero)
    var viewW by mutableFloatStateOf(0f)
    var viewH by mutableFloatStateOf(0f)
    var fitted by mutableStateOf(false)

    fun toImage(p: Offset) = Vec2(((p.x - offset.x) / scale).toDouble(), ((p.y - offset.y) / scale).toDouble())

    fun fit(imgW: Int, imgH: Int, margin: Float = 0.94f) {
        if (viewW <= 0f || viewH <= 0f) return
        val s = min(viewW / imgW, viewH / imgH) * margin
        scale = s
        offset = Offset((viewW - imgW * s) / 2f, (viewH - imgH * s) / 2f)
        fitted = true
    }

    fun transform(centroid: Offset, pan: Offset, zoom: Float) {
        val ns = (scale * zoom).coerceIn(0.05f, 40f)
        val k = ns / scale
        offset = centroid - (centroid - offset) * k + pan
        scale = ns
    }
}

/**
 * Canvas with two-finger zoom/pan always available. A one-finger gesture goes to [onStart]/[onMove]/[onEnd]
 * (drawing, point dragging…) when [onStart] returns true, otherwise it pans the view.
 * If a second finger lands during a one-finger action, the action is cancelled via [onCancel].
 */
@Composable
fun DrawingSurface(
    vt: ViewTransform,
    imageW: Int,
    imageH: Int,
    modifier: Modifier = Modifier,
    onStart: (Vec2) -> Boolean = { false },
    onMove: (Vec2) -> Unit = {},
    onEnd: () -> Unit = {},
    onCancel: () -> Unit = {},
    draw: (android.graphics.Canvas) -> Unit,
) {
    val start by rememberUpdatedState(onStart)
    val move by rememberUpdatedState(onMove)
    val end by rememberUpdatedState(onEnd)
    val cancel by rememberUpdatedState(onCancel)
    val drawFn by rememberUpdatedState(draw)
    Canvas(
        modifier
            .fillMaxSize()
            .clipToBounds()
            .onSizeChanged {
                vt.viewW = it.width.toFloat(); vt.viewH = it.height.toFloat()
                if (!vt.fitted) vt.fit(imageW, imageH)
            }
            .pointerInput(Unit) {
                awaitEachGesture {
                    val first = awaitFirstDown(requireUnconsumed = false)
                    var acting = start(vt.toImage(first.position))
                    if (acting) first.consume()
                    var cancelled = false
                    while (true) {
                        val event = awaitPointerEvent()
                        val pressed = event.changes.count { it.pressed }
                        if (pressed == 0) break
                        if (pressed >= 2 || !acting) {
                            if (acting) { cancel(); acting = false; cancelled = true }
                            val zoom = event.calculateZoom()
                            val pan = event.calculatePan()
                            val c = event.calculateCentroid(useCurrent = true)
                            if (c != Offset.Unspecified) vt.transform(c, pan, zoom)
                            event.changes.forEach { if (it.positionChanged()) it.consume() }
                        } else {
                            val ch = event.changes.firstOrNull { it.pressed } ?: break
                            move(vt.toImage(ch.position))
                            ch.consume()
                        }
                    }
                    if (acting && !cancelled) end()
                }
            }
    ) {
        drawIntoCanvas { canvas ->
            val nc = canvas.nativeCanvas
            nc.save()
            nc.translate(vt.offset.x, vt.offset.y)
            nc.scale(vt.scale, vt.scale)
            drawFn(nc)
            nc.restore()
        }
    }
}
