package com.loomis.studio.detect

import android.graphics.Bitmap
import android.graphics.PointF
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.Face
import com.google.mlkit.vision.face.FaceContour as MlContour
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import com.google.mlkit.vision.face.FaceLandmark
import com.google.mlkit.vision.pose.PoseDetection
import com.google.mlkit.vision.pose.accurate.AccuratePoseDetectorOptions
import com.loomis.core.figure.BodyObservation
import com.loomis.core.figure.Joint
import com.loomis.core.figure.JointObs
import com.loomis.core.geom.Vec2
import com.loomis.core.head.FaceContour
import com.loomis.core.head.FaceObservation
import com.loomis.core.head.LoomisHeadModel.Anchor
import com.loomis.core.head.ObservationSource
import kotlinx.coroutines.tasks.await

/**
 * On-device detection with ML Kit's bundled models (no network).
 * Detection only produces raw points; the Loomis construction is fitted to them in loomis-core.
 *
 * Note on sides: ML Kit names landmarks by the SUBJECT's left/right. In a normal (non-mirrored)
 * photo the subject's left appears on the image's right, so LEFT_* maps to our image-right (…_R).
 */
object Detectors {

    private val faceClient by lazy {
        FaceDetection.getClient(
            FaceDetectorOptions.Builder()
                .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_ACCURATE)
                .setLandmarkMode(FaceDetectorOptions.LANDMARK_MODE_ALL)
                .setContourMode(FaceDetectorOptions.CONTOUR_MODE_ALL)
                .setMinFaceSize(0.08f)
                .build()
        )
    }

    private val poseClient by lazy {
        PoseDetection.getClient(
            AccuratePoseDetectorOptions.Builder()
                .setDetectorMode(AccuratePoseDetectorOptions.SINGLE_IMAGE_MODE)
                .build()
        )
    }

    /** Returns null when no face was found. [scale] maps detection-bitmap pixels back to the prepared image (divide). */
    suspend fun detectFace(bmp: Bitmap, scale: Float): FaceObservation? {
        val faces = faceClient.process(InputImage.fromBitmap(bmp, 0)).await()
        val face = faces.maxByOrNull { it.boundingBox.width() * it.boundingBox.height() } ?: return null
        return toObservation(face, 1f / scale)
    }

    suspend fun detectBody(bmp: Bitmap, scale: Float, imageW: Int, imageH: Int): BodyObservation? {
        val pose = poseClient.process(InputImage.fromBitmap(bmp, 0)).await()
        val lms = pose.allPoseLandmarks
        if (lms.isEmpty()) return null
        val inv = 1f / scale
        val joints = HashMap<Joint, JointObs>()
        for (lm in lms) {
            val j = Joint.byIndex(lm.landmarkType) ?: continue
            joints[j] = JointObs(Vec2(lm.position.x * inv.toDouble(), lm.position.y * inv.toDouble()), lm.inFrameLikelihood.toDouble(), lm.position3D.z * inv.toDouble())
        }
        val good = joints.values.count { it.likelihood > 0.5 }
        if (good < 6) return null
        return BodyObservation(joints, userConfirmed = false, manual = false, imageWidth = imageW, imageHeight = imageH)
    }

    private fun toObservation(face: Face, inv: Float): FaceObservation {
        fun pts(type: Int): List<Vec2>? = face.getContour(type)?.points?.takeIf { it.isNotEmpty() }?.map { v(it, inv) }
        val contours = HashMap<FaceContour, List<Vec2>>()
        fun put(k: FaceContour, type: Int) { pts(type)?.let { contours[k] = it } }
        put(FaceContour.FACE, MlContour.FACE)
        put(FaceContour.BROW_L_TOP, MlContour.RIGHT_EYEBROW_TOP); put(FaceContour.BROW_L_BOTTOM, MlContour.RIGHT_EYEBROW_BOTTOM)
        put(FaceContour.BROW_R_TOP, MlContour.LEFT_EYEBROW_TOP); put(FaceContour.BROW_R_BOTTOM, MlContour.LEFT_EYEBROW_BOTTOM)
        put(FaceContour.EYE_L, MlContour.RIGHT_EYE); put(FaceContour.EYE_R, MlContour.LEFT_EYE)
        put(FaceContour.UPPER_LIP_TOP, MlContour.UPPER_LIP_TOP); put(FaceContour.UPPER_LIP_BOTTOM, MlContour.UPPER_LIP_BOTTOM)
        put(FaceContour.LOWER_LIP_TOP, MlContour.LOWER_LIP_TOP); put(FaceContour.LOWER_LIP_BOTTOM, MlContour.LOWER_LIP_BOTTOM)
        put(FaceContour.NOSE_BRIDGE, MlContour.NOSE_BRIDGE); put(FaceContour.NOSE_BOTTOM, MlContour.NOSE_BOTTOM)

        val a = HashMap<Anchor, Vec2>()
        fun lm(type: Int) = face.getLandmark(type)?.position?.let { v(it, inv) }
        (contours[FaceContour.EYE_L]?.let { Vec2.mean(it) } ?: lm(FaceLandmark.RIGHT_EYE))?.let { a[Anchor.EYE_L] = it }
        (contours[FaceContour.EYE_R]?.let { Vec2.mean(it) } ?: lm(FaceLandmark.LEFT_EYE))?.let { a[Anchor.EYE_R] = it }
        contours[FaceContour.BROW_L_BOTTOM]?.let { a[Anchor.BROW_L] = Vec2.mean(it) }
        contours[FaceContour.BROW_R_BOTTOM]?.let { a[Anchor.BROW_R] = Vec2.mean(it) }
        contours[FaceContour.NOSE_BRIDGE]?.lastOrNull()?.let { a[Anchor.NOSE_TIP] = it }
        val noseBottom = contours[FaceContour.NOSE_BOTTOM]
        (if (noseBottom != null && noseBottom.size >= 3) noseBottom[noseBottom.size / 2] else lm(FaceLandmark.NOSE_BASE))?.let { a[Anchor.NOSE_BASE] = it }
        val ut = contours[FaceContour.UPPER_LIP_TOP]
        if (ut != null && ut.size >= 2) {
            val sorted = ut.sortedBy { it.x }
            a[Anchor.MOUTH_L] = sorted.first(); a[Anchor.MOUTH_R] = sorted.last()
        } else {
            lm(FaceLandmark.MOUTH_RIGHT)?.let { a[Anchor.MOUTH_L] = it }
            lm(FaceLandmark.MOUTH_LEFT)?.let { a[Anchor.MOUTH_R] = it }
        }
        val ub = contours[FaceContour.UPPER_LIP_BOTTOM]; val lt = contours[FaceContour.LOWER_LIP_TOP]
        if (ub != null && lt != null && ub.isNotEmpty() && lt.isNotEmpty()) a[Anchor.MOUTH_C] = (ub[ub.size / 2] + lt[lt.size / 2]) * 0.5
        else lm(FaceLandmark.MOUTH_BOTTOM)?.let { a[Anchor.MOUTH_C] = it }
        // Chin: the face-contour point farthest along the eyes→mouth direction.
        val face36 = contours[FaceContour.FACE]
        val eyeMid = if (a[Anchor.EYE_L] != null && a[Anchor.EYE_R] != null) (a.getValue(Anchor.EYE_L) + a.getValue(Anchor.EYE_R)) * 0.5 else null
        val mouth = a[Anchor.MOUTH_C]
        if (face36 != null && eyeMid != null && mouth != null) {
            val down = (mouth - eyeMid).normalized()
            a[Anchor.CHIN] = face36.maxBy { (it - eyeMid).dot(down) }
        }
        // Ears only when visible (turned heads).
        if (contours.isEmpty()) {
            lm(FaceLandmark.RIGHT_EAR)?.let { a[Anchor.EAR_L] = it }
            lm(FaceLandmark.LEFT_EAR)?.let { a[Anchor.EAR_R] = it }
        }
        return FaceObservation(
            anchors = a, contours = contours,
            hintYawDeg = face.headEulerAngleY.toDouble(), hintPitchDeg = face.headEulerAngleX.toDouble(), hintRollDeg = face.headEulerAngleZ.toDouble(),
            source = ObservationSource.AUTO, userConfirmed = false,
        )
    }

    private fun v(p: PointF, inv: Float) = Vec2((p.x * inv).toDouble(), (p.y * inv).toDouble())
}
