package com.loomis.studio.editor

import com.loomis.core.geom.Vec2

enum class Tool { HAND, PEN, ERASER, EDIT }

/** A freehand line drawn by the user, in image pixels. */
data class UserStroke(val points: List<Vec2>, val color: Int, val width: Float)

/** Eraser pass (pixel eraser on the final + user layers), in image pixels. */
data class EraseMark(val points: List<Vec2>, val width: Float)

/**
 * Everything the user changed on top of the generated drawing. Immutable so undo/redo is a stack of snapshots.
 * [deforms] maps a generated final stroke id ("stage:index") to its reshaped points.
 */
data class Edits(
    val userStrokes: List<UserStroke> = emptyList(),
    val erasers: List<EraseMark> = emptyList(),
    val deforms: Map<String, List<Vec2>> = emptyMap(),
)

data class LayerStyle(val visible: Boolean = true, val opacity: Float = 1f, val color: Int = 0, val width: Float = 1f)

data class LayerSettings(
    val photo: LayerStyle = LayerStyle(true, 0.55f),
    val structure: LayerStyle = LayerStyle(true, 0.95f, 0xFF2D6CDF.toInt(), 1f),
    val final: LayerStyle = LayerStyle(true, 1f, 0xFF1A1A1A.toInt(), 1f),
    val points: LayerStyle = LayerStyle(true, 1f),
    val user: LayerStyle = LayerStyle(true, 1f, 0xFF1A1A1A.toInt(), 1f),
    val edges: LayerStyle = LayerStyle(false, 0.6f, 0xFFB0306A.toInt(), 0.25f),
    val labels: Boolean = true,
    val hiddenLines: Boolean = true,
    val previousSteps: Boolean = true,
    /** Stage indices whose construction lines the user switched off. */
    val hiddenStages: Set<Int> = emptySet(),
)

/** Undo/redo history over [Edits] snapshots. */
class History(private val limit: Int = 120) {
    private val undo = ArrayDeque<Edits>()
    private val redo = ArrayDeque<Edits>()
    fun push(before: Edits) { undo.addLast(before); if (undo.size > limit) undo.removeFirst(); redo.clear() }
    fun undo(current: Edits): Edits? { val e = undo.removeLastOrNull() ?: return null; redo.addLast(current); return e }
    fun redo(current: Edits): Edits? { val e = redo.removeLastOrNull() ?: return null; undo.addLast(current); return e }
    val canUndo get() = undo.isNotEmpty()
    val canRedo get() = redo.isNotEmpty()
    fun clear() { undo.clear(); redo.clear() }
}
