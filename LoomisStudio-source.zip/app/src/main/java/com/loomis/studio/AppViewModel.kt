package com.loomis.studio

import android.app.Application
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.loomis.core.figure.BodyObservation
import com.loomis.core.figure.Canon
import com.loomis.core.figure.FigureAnalysis
import com.loomis.core.figure.FigureAnalyzer
import com.loomis.core.figure.FigureStepBuilder
import com.loomis.core.figure.Joint
import com.loomis.core.geom.Vec2
import com.loomis.core.head.FaceObservation
import com.loomis.core.head.HeadFit
import com.loomis.core.head.HeadFitter
import com.loomis.core.head.HeadPose
import com.loomis.core.head.HeadProportions
import com.loomis.core.head.HeadStepBuilder
import com.loomis.core.head.LoomisHeadModel
import com.loomis.core.head.ObservationSource
import com.loomis.core.lesson.Lessons
import com.loomis.core.model.Confidence
import com.loomis.core.model.DrawingMode
import com.loomis.core.model.StepPlan
import com.loomis.studio.data.AppSettings
import com.loomis.studio.data.ProjectData
import com.loomis.studio.data.ProjectMeta
import com.loomis.studio.data.ProjectStore
import com.loomis.studio.data.SettingsStore
import com.loomis.studio.detect.Detectors
import com.loomis.studio.editor.EraseMark
import com.loomis.studio.editor.Edits
import com.loomis.studio.editor.History
import com.loomis.studio.editor.LayerSettings
import com.loomis.studio.editor.Tool
import com.loomis.studio.editor.UserStroke
import com.loomis.studio.i18n.S
import com.loomis.studio.image.ImagePrep
import com.loomis.studio.image.ImportParams
import com.loomis.studio.render.DrawingRenderer
import com.loomis.studio.render.Exporter
import com.loomis.studio.render.RenderSpec
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class Screen { HOME, IMPORT, ANALYSIS, EDITOR, FINAL, PROJECTS, SETTINGS }

enum class ExportBg { WHITE, TRANSPARENT }

data class ExportOptions(
    val bg: ExportBg = ExportBg.WHITE,
    val withPhoto: Boolean = false,
    val withStructure: Boolean = false,
    val includeUser: Boolean = true,
    val scale: Float = 2f,
)

class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val store = ProjectStore(app)
    private val settingsStore = SettingsStore(app)
    val renderer = DrawingRenderer()

    var settings by mutableStateOf(settingsStore.load()); private set
    var screen by mutableStateOf(Screen.HOME)
    var busy by mutableStateOf<String?>(null); private set
    var message by mutableStateOf<String?>(null)

    // ---- session
    var mode by mutableStateOf(DrawingMode.HEAD); private set
    var source by mutableStateOf<Bitmap?>(null); private set
    var importParams by mutableStateOf(ImportParams()); private set
    var photo by mutableStateOf<Bitmap?>(null); private set
    var edges by mutableStateOf<Bitmap?>(null); private set
    var projectId by mutableStateOf<String?>(null); private set
    var projectName by mutableStateOf(""); private set
    private var created = 0L

    var face by mutableStateOf(FaceObservation.EMPTY); private set
    var poseOverride by mutableStateOf<HeadPose?>(null); private set
    var hairThird by mutableStateOf(1.0); private set
    private var lastProp = HeadProportions.IDEAL
    var neckPit by mutableStateOf<Vec2?>(null); private set
    var body by mutableStateOf(BodyObservation.EMPTY); private set
    var canon by mutableStateOf(Canon.MALE); private set

    var fit by mutableStateOf<HeadFit?>(null); private set
    var figure by mutableStateOf<FigureAnalysis?>(null); private set
    var plans by mutableStateOf<List<StepPlan>>(emptyList()); private set
    var step by mutableStateOf(0); private set
    var analysisConfirmed by mutableStateOf(false); private set
    var detectionNote by mutableStateOf<String?>(null); private set

    var edits by mutableStateOf(Edits()); private set
    private val history = History()
    var canUndo by mutableStateOf(false); private set
    var canRedo by mutableStateOf(false); private set
    var layers by mutableStateOf(LayerSettings()); private set
    var tool by mutableStateOf(Tool.HAND)
    var penColor by mutableStateOf(Color.rgb(26, 26, 26))
    var penWidth by mutableStateOf(1.4f)
    var eraserWidth by mutableStateOf(10f)
    var showLesson by mutableStateOf(true)
    var selectedStroke by mutableStateOf<String?>(null)
    var exportOptions by mutableStateOf(ExportOptions())

    val imageW get() = photo?.width ?: 1
    val imageH get() = photo?.height ?: 1

    private var rebuildJob: Job? = null

    init { showLesson = settings.lessonsDefault; canon = settings.canon }

    fun t(key: String) = S.get(key, settings.lang)

    fun updateSettings(s: AppSettings) { settings = s; settingsStore.save(s) }

    // ------------------------------------------------------------------ new project / import
    fun begin(m: DrawingMode) { mode = m }

    fun onImagePicked(uri: Uri) {
        busy = t("analyzing")
        viewModelScope.launch {
            try {
                val bmp = withContext(Dispatchers.IO) { ImagePrep.decode(getApplication(), uri) }
                source = bmp
                importParams = ImportParams()
                screen = Screen.IMPORT
            } catch (e: Throwable) {
                message = t("load_error") + (e.message ?: e.javaClass.simpleName)
            } finally { busy = null }
        }
    }

    fun updateImport(p: ImportParams) { importParams = p }

    fun confirmImport() {
        val src = source ?: return
        busy = t("analyzing")
        viewModelScope.launch {
            try {
                val prepared = withContext(Dispatchers.Default) { ImagePrep.prepare(src, importParams) }
                resetSession()
                photo = prepared
                projectId = store.newId()
                created = System.currentTimeMillis()
                projectName = (if (mode == DrawingMode.HEAD) t("head_mode") else t("figure_mode")) + " " +
                    java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.US).format(java.util.Date(created))
                detect()
                screen = Screen.ANALYSIS
            } catch (e: Throwable) {
                message = t("detect_error") + (e.message ?: e.javaClass.simpleName)
            } finally { busy = null }
        }
    }

    private fun resetSession() {
        face = FaceObservation.EMPTY; poseOverride = null; hairThird = 1.0; lastProp = HeadProportions.IDEAL; neckPit = null
        body = BodyObservation.EMPTY; fit = null; figure = null; plans = emptyList(); step = 0; analysisConfirmed = false
        detectionNote = null; edits = Edits(); history.clear(); updateHistoryFlags(); layers = defaultLayers(); edges = null
        selectedStroke = null; renderer.clearCache(); canon = settings.canon; showLesson = settings.lessonsDefault
    }

    private fun defaultLayers() = LayerSettings().let {
        it.copy(structure = it.structure.copy(color = settings.structureColor), final = it.final.copy(color = settings.finalColor),
            user = it.user.copy(color = settings.finalColor))
    }

    private suspend fun detect() {
        val img = photo ?: return
        val (small, scale) = withContext(Dispatchers.Default) { ImagePrep.detectionCopy(img, 1280, settings.autoLevels) }
        if (mode == DrawingMode.HEAD) {
            val f = runCatching { Detectors.detectFace(small, scale) }.getOrElse { e -> detectionNote = t("detect_error") + e.message; null }
            if (f == null || f.anchors.size < HeadFitter.MIN_ANCHORS) {
                detectionNote = detectionNote ?: t("no_face_found")
                face = manualFaceTemplate(img.width, img.height)
            } else face = f
            // Optional: shoulders give the pit of the neck for the neck stage.
            val b = runCatching { Detectors.detectBody(small, scale, img.width, img.height) }.getOrNull()
            val ls = b?.raw(Joint.L_SHOULDER); val rs = b?.raw(Joint.R_SHOULDER)
            if (ls != null && rs != null && ls.likelihood > 0.8 && rs.likelihood > 0.8) {
                val mid = (ls.at + rs.at) * 0.5
                neckPit = mid + Vec2(0.0, ls.at.distanceTo(rs.at) * 0.06)
            }
        } else {
            val b = runCatching { Detectors.detectBody(small, scale, img.width, img.height) }.getOrElse { e -> detectionNote = t("detect_error") + e.message; null }
            body = if (b == null) { detectionNote = detectionNote ?: t("no_body_found"); BodyObservation.template(img.width, img.height) } else b
        }
        if (small != img) small.recycle()
        rebuildNow()
    }

    /** Anchors of an ideal frontal head at the default position, for manual placement when nothing is detected. */
    private fun manualFaceTemplate(w: Int, h: Int): FaceObservation {
        val pose = HeadFitter.defaultPose(w, h)
        val m = LoomisHeadModel()
        val anchors = LoomisHeadModel.Anchor.values().filter { !it.name.startsWith("EAR") }.associateWith { pose.project(m.anchor(it)) }
        return FaceObservation(anchors, source = ObservationSource.MANUAL, userConfirmed = false)
    }

    // ------------------------------------------------------------------ analysis edits
    /** During a drag only the point moves; the structure is refitted when the finger lifts. */
    fun movePoint(id: String, to: Vec2, final: Boolean) {
        if (mode == DrawingMode.HEAD) {
            val a = runCatching { LoomisHeadModel.Anchor.valueOf(id) }.getOrNull() ?: return
            face = face.moveAnchor(a, to)
            if (final) { poseOverride = null; rebuild() } else plansPointPreview(id, to)
        } else {
            val j = runCatching { Joint.valueOf(id) }.getOrNull() ?: return
            body = body.moveJoint(j, to)
            if (final) rebuild() else plansPointPreview(id, to)
        }
    }

    private fun plansPointPreview(id: String, to: Vec2) {
        val p0 = plans.firstOrNull() ?: return
        val pts = p0.points.map { if (it.editableId == id) it.copy(at = to, lowConfidence = false) else it }
        plans = listOf(p0.copy(points = pts)) + plans.drop(1)
    }

    fun removePoint(id: String) {
        if (mode != DrawingMode.HEAD) return
        val a = runCatching { LoomisHeadModel.Anchor.valueOf(id) }.getOrNull() ?: return
        face = face.removeAnchor(a); poseOverride = null; rebuild()
    }

    fun addEarPoint(left: Boolean, at: Vec2) {
        face = face.moveAnchor(if (left) LoomisHeadModel.Anchor.EAR_L else LoomisHeadModel.Anchor.EAR_R, at); poseOverride = null; rebuild()
    }

    fun setPose(p: HeadPose) { poseOverride = p; rebuild() }
    fun clearPoseOverride() { poseOverride = null; rebuild() }
    fun setHair(v: Double) { hairThird = v; rebuild() }
    fun setFigureCanon(c: Canon) { canon = c; rebuild() }

    fun confirmAnalysis() {
        analysisConfirmed = true
        face = face.copy(userConfirmed = true)
        body = body.copy(userConfirmed = true)
        rebuildJob?.cancel()
        rebuildJob = viewModelScope.launch {
            rebuildNow()
            step = 0
            screen = Screen.EDITOR
        }
    }

    // ------------------------------------------------------------------ building stages
    fun rebuild() {
        rebuildJob?.cancel()
        rebuildJob = viewModelScope.launch { rebuildNow() }
    }

    private suspend fun rebuildNow() {
        val img = photo ?: return
        val m = mode
        val f = face; val po = poseOverride; val hair = hairThird; val pit = neckPit; val b = body; val c = canon; val confirmed = analysisConfirmed
        val prevProp = lastProp
        val result = withContext(Dispatchers.Default) {
            if (m == DrawingMode.HEAD) {
                val base = HeadProportions(hairThird = hair)
                val fitted: HeadFit = if (po != null) HeadFitter.evaluate(f, po, prevProp.copy(hairThird = hair))
                else HeadFitter.fit(f, base) ?: HeadFitter.evaluate(f, HeadFitter.defaultPose(img.width, img.height), base)
                    .copy(confidence = Confidence.LOW, warnings = listOf("warn_few_points"))
                val obs = if (confirmed) f.copy(userConfirmed = true) else f
                Triple(fitted, null as FigureAnalysis?, HeadStepBuilder(fitted, obs, pit).build())
            } else {
                val bb = if (confirmed) b.copy(userConfirmed = true) else b
                val an = FigureAnalyzer.analyze(bb)
                Triple(null as HeadFit?, an, if (an == null) emptyList() else FigureStepBuilder(bb, an, c).build())
            }
        }
        fit = result.first
        result.first?.let { if (poseOverride == null) lastProp = it.prop }
        figure = result.second
        if (plans.isNotEmpty() && edits.deforms.isNotEmpty()) {
            // Generated geometry changed: reshaped strokes no longer match their originals.
            pushHistory(); edits = edits.copy(deforms = emptyMap()); message = t("edits_cleared")
        }
        renderer.clearCache()
        plans = result.third
        step = step.coerceIn(0, (plans.size - 1).coerceAtLeast(0))
    }

    val currentPlan: StepPlan? get() = plans.getOrNull(step)

    fun canGoNext(): Boolean {
        val p = currentPlan ?: return false
        if (step >= plans.size - 1) return false
        return !(p.requiresConfirmation && !analysisConfirmed)
    }

    fun next() {
        val p = currentPlan ?: return
        if (p.requiresConfirmation && !analysisConfirmed) { message = t("needs_confirm"); return }
        if (step < plans.size - 1) { step++; selectedStroke = null }
    }

    fun prev() { if (step > 0) { step--; selectedStroke = null } }
    fun goTo(i: Int) { if (i in plans.indices && (i <= step || analysisConfirmed)) { step = i; selectedStroke = null } }

    fun lessonFor(plan: StepPlan) = Lessons.get(plan.lessonId)

    // ------------------------------------------------------------------ drawing edits
    private fun pushHistory() { history.push(edits); updateHistoryFlags() }
    private fun updateHistoryFlags() { canUndo = history.canUndo; canRedo = history.canRedo }

    fun addUserStroke(points: List<Vec2>) {
        if (points.isEmpty()) return
        pushHistory(); edits = edits.copy(userStrokes = edits.userStrokes + UserStroke(points, penColor, penWidth))
    }

    fun addEraser(points: List<Vec2>) {
        if (points.isEmpty()) return
        pushHistory(); edits = edits.copy(erasers = edits.erasers + EraseMark(points, eraserWidth))
    }

    /** Begin reshaping a generated final stroke; returns its id and points. */
    fun pickFinalStroke(at: Vec2, radius: Double): Pair<String, List<Vec2>>? {
        var best: Pair<String, List<Vec2>>? = null; var bestD = radius
        for (plan in plans) {
            if (plan.index > step) break
            plan.strokes.forEachIndexed { k, s ->
                if (s.layer != com.loomis.core.model.LayerId.FINAL) return@forEachIndexed
                val id = DrawingRenderer.strokeId(plan.index, k)
                val pts = edits.deforms[id] ?: s.points
                for (p in pts) { val d = p.distanceTo(at); if (d < bestD) { bestD = d; best = id to pts } }
            }
        }
        return best
    }

    fun previewDeform(id: String, pts: List<Vec2>) { edits = edits.copy(deforms = edits.deforms + (id to pts)) }

    fun commitDeform(before: Edits) { history.push(before); updateHistoryFlags() }

    /** Drop an uncommitted reshape (gesture cancelled by a second finger). */
    fun undoPreview(before: Edits) { edits = before }

    fun undo() { history.undo(edits)?.let { edits = it }; updateHistoryFlags() }
    fun redo() { history.redo(edits)?.let { edits = it }; updateHistoryFlags() }

    fun updateLayers(l: LayerSettings) { layers = l; if (l.edges.visible && edges == null) computeEdges() }

    fun computeEdges() {
        val img = photo ?: return
        val l = layers
        viewModelScope.launch {
            edges = withContext(Dispatchers.Default) { ImagePrep.edgeLayer(img, l.edges.width.coerceIn(0.05f, 0.9f), l.edges.color) }
        }
    }

    // ------------------------------------------------------------------ projects
    fun saveProject(silent: Boolean = false) {
        val img = photo ?: return
        val id = projectId ?: return
        val data = snapshot(id)
        viewModelScope.launch {
            try {
                withContext(Dispatchers.IO) {
                    val thumb = DrawingRenderer.renderBitmap(DrawingRenderer(), img, null, img.width, img.height,
                        renderSpec().copy(background = Color.WHITE), 320f / maxOf(img.width, img.height))
                    store.save(data, img, thumb)
                }
                if (!silent) message = t("saved")
            } catch (e: Throwable) { message = t("export_failed") + e.message }
        }
    }

    private fun snapshot(id: String) = ProjectData(
        ProjectMeta(id, projectName, mode, created, System.currentTimeMillis(), step), imageW, imageH,
        if (mode == DrawingMode.HEAD) face else null, poseOverride, hairThird,
        if (mode == DrawingMode.FIGURE) body else null, canon, neckPit, edits, layers, analysisConfirmed,
    )

    fun listProjects() = store.list()
    fun thumbnail(id: String) = store.thumbnail(id)
    fun deleteProject(id: String) { store.delete(id) }
    fun renameProject(id: String, name: String) { store.rename(id, name); if (id == projectId) projectName = name }

    fun openProject(id: String) {
        busy = "…"
        viewModelScope.launch {
            try {
                val (data, img) = withContext(Dispatchers.IO) { store.load(id) to store.loadPhoto(id) }
                if (data == null || img == null) { message = t("load_error") + id; return@launch }
                resetSession()
                mode = data.meta.mode; photo = img; projectId = data.meta.id; projectName = data.meta.name; created = data.meta.created
                face = data.face ?: FaceObservation.EMPTY; poseOverride = data.poseOverride; hairThird = data.hairThird
                body = data.body ?: BodyObservation.EMPTY; canon = data.canon; neckPit = data.neckPit
                edits = data.edits; layers = data.layers; analysisConfirmed = data.analysisConfirmed
                step = data.meta.step
                // Rebuild without discarding saved line fixes (geometry is deterministic for the same inputs).
                val keep = edits
                rebuildNow()
                edits = keep
                if (layers.edges.visible) computeEdges()
                screen = if (analysisConfirmed) Screen.EDITOR else Screen.ANALYSIS
            } catch (e: Throwable) { message = t("load_error") + e.message } finally { busy = null }
        }
    }

    // ------------------------------------------------------------------ rendering & export
    fun renderSpec() = RenderSpec(
        plans = plans, currentStep = step, layers = layers, edits = edits, lang = settings.lang, lineScale = settings.lineScale,
        selectedStroke = selectedStroke,
        hideStructureOverride = if (currentPlan?.hidesStructureByDefault == true) !forceStructureOnFinal else null,
    )

    var forceStructureOnFinal by mutableStateOf(false)

    private fun exportSpec(o: ExportOptions, stage: Int, structure: Boolean) = RenderSpec(
        plans = plans, currentStep = stage,
        layers = layers.copy(photo = layers.photo.copy(visible = true), structure = layers.structure.copy(visible = true),
            final = layers.final.copy(visible = true), user = layers.user.copy(visible = true), labels = false),
        edits = edits, lang = settings.lang, lineScale = settings.lineScale,
        drawPhoto = o.withPhoto, drawStructure = structure, drawFinal = true, drawUser = o.includeUser, drawPoints = false, drawEdges = false,
        background = if (o.bg == ExportBg.WHITE) Color.WHITE else null,
    )

    fun exportFinal() {
        val img = photo ?: return
        val o = exportOptions
        busy = "…"
        viewModelScope.launch {
            try {
                val path = withContext(Dispatchers.Default) {
                    val bmp = DrawingRenderer.renderBitmap(DrawingRenderer(), img, null, img.width, img.height, exportSpec(o, plans.size - 1, o.withStructure), o.scale)
                    val name = "final_" + (if (o.withPhoto) "ref_" else "") + (if (o.bg == ExportBg.WHITE) "white" else "transparent")
                    Exporter.savePng(getApplication(), bmp, projectName, "${name}_${System.currentTimeMillis() % 100000}").also { bmp.recycle() }
                }
                message = t("saved_to") + path
            } catch (e: Throwable) { message = t("export_failed") + (e.message ?: e.javaClass.simpleName) } finally { busy = null }
        }
    }

    fun exportAllStages() {
        val img = photo ?: return
        val o = exportOptions
        busy = "…"
        viewModelScope.launch {
            try {
                var last = ""
                for (p in plans) {
                    last = withContext(Dispatchers.Default) {
                        val bmp = DrawingRenderer.renderBitmap(DrawingRenderer(), img, null, img.width, img.height,
                            exportSpec(o, p.index, !p.hidesStructureByDefault), minOf(o.scale, 2f))
                        val title = Lessons.get(p.lessonId)?.en?.title?.replace(Regex("[^A-Za-z0-9]+"), "_") ?: p.lessonId
                        Exporter.savePng(getApplication(), bmp, projectName, String.format(java.util.Locale.US, "stage_%02d_%s", p.index + 1, title)).also { bmp.recycle() }
                    }
                }
                message = t("saved_to") + last.substringBeforeLast('/')
            } catch (e: Throwable) { message = t("export_failed") + (e.message ?: e.javaClass.simpleName) } finally { busy = null }
        }
    }
}
