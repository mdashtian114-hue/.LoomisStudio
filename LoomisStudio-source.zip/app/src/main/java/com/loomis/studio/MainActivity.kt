package com.loomis.studio

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import com.loomis.core.lesson.Lang
import com.loomis.studio.i18n.LocalLang
import com.loomis.studio.ui.AnalysisScreen
import com.loomis.studio.ui.EditorScreen
import com.loomis.studio.ui.FinalScreen
import com.loomis.studio.ui.HomeScreen
import com.loomis.studio.ui.ImportScreen
import com.loomis.studio.ui.LoomisTheme
import com.loomis.studio.ui.ProjectsScreen
import com.loomis.studio.ui.SettingsScreen

class MainActivity : ComponentActivity() {
    private val vm: AppViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val lang = vm.settings.lang
            CompositionLocalProvider(
                LocalLang provides lang,
                LocalLayoutDirection provides if (lang == Lang.FA) LayoutDirection.Rtl else LayoutDirection.Ltr,
            ) {
                LoomisTheme { Root(vm) }
            }
        }
    }

    override fun onStop() {
        super.onStop()
        // Autosave so a drawing can always be continued later.
        if (vm.projectId != null && vm.photo != null && (vm.screen == Screen.EDITOR || vm.screen == Screen.FINAL || vm.screen == Screen.ANALYSIS)) vm.saveProject(silent = true)
    }
}

@androidx.compose.runtime.Composable
private fun Root(vm: AppViewModel) {
    val snack = remember { SnackbarHostState() }
    LaunchedEffect(vm.message) {
        vm.message?.let { snack.showSnackbar(it); vm.message = null }
    }
    BackHandler(enabled = vm.screen != Screen.HOME) {
        vm.screen = when (vm.screen) {
            Screen.FINAL -> Screen.EDITOR
            Screen.EDITOR -> { vm.saveProject(silent = true); Screen.HOME }
            Screen.ANALYSIS -> if (vm.analysisConfirmed) Screen.EDITOR else Screen.HOME
            else -> Screen.HOME
        }
    }
    Box(Modifier.fillMaxSize().background(Color(0xFF1F2430)).safeDrawingPadding()) {
        Box(Modifier.fillMaxSize().background(Color(0xFFF4F1EA))) {
            when (vm.screen) {
                Screen.HOME -> HomeScreen(vm)
                Screen.IMPORT -> ImportScreen(vm)
                Screen.ANALYSIS -> AnalysisScreen(vm)
                Screen.EDITOR -> EditorScreen(vm)
                Screen.FINAL -> FinalScreen(vm)
                Screen.PROJECTS -> ProjectsScreen(vm)
                Screen.SETTINGS -> SettingsScreen(vm)
            }
        }
        SnackbarHost(snack, Modifier.align(Alignment.BottomCenter).padding(bottom = 72.dp))
        vm.busy?.let { msg ->
            Box(
                Modifier.fillMaxSize().background(Color(0x88000000))
                    // Block touches on the screen underneath while work is running.
                    .pointerInput(Unit) { awaitPointerEventScope { while (true) awaitPointerEvent().changes.forEach { it.consume() } } },
                contentAlignment = Alignment.Center,
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator(color = Color.White)
                    Text(msg, color = Color.White, modifier = Modifier.padding(top = 12.dp))
                }
            }
        }
    }
}
