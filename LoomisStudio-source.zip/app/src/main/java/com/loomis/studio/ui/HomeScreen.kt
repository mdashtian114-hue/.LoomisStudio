package com.loomis.studio.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.loomis.core.model.DrawingMode
import com.loomis.studio.AppViewModel
import com.loomis.studio.Screen

@Composable
fun HomeScreen(vm: AppViewModel) {
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) vm.onImagePicked(uri)
    }
    fun pick(m: DrawingMode) {
        vm.begin(m)
        picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(Modifier.height(12.dp))
        LoomisMark(Modifier.size(96.dp))
        Text(vm.t("app"), fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Ink, modifier = Modifier.padding(top = 8.dp))
        Text(vm.t("tagline"), fontSize = 14.sp, color = Color(0xFF4A4F5A), modifier = Modifier.padding(top = 4.dp, bottom = 20.dp))
        ModeCard(vm.t("new_head"), vm.t("new_head_sub"), vm.t("pick_photo")) { pick(DrawingMode.HEAD) }
        Spacer(Modifier.height(12.dp))
        ModeCard(vm.t("new_figure"), vm.t("new_figure_sub"), vm.t("pick_photo")) { pick(DrawingMode.FIGURE) }
        Spacer(Modifier.height(20.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedButton(onClick = { vm.screen = Screen.PROJECTS }) { Text(vm.t("projects")) }
            OutlinedButton(onClick = { vm.screen = Screen.SETTINGS }) { Text(vm.t("settings")) }
        }
        Text(vm.t("offline_note"), fontSize = 12.sp, color = Color(0xFF6A6F7A), modifier = Modifier.padding(top = 18.dp))
    }
}

@Composable
private fun ModeCard(title: String, sub: String, action: String, onClick: () -> Unit) {
    Column(
        Modifier.fillMaxWidth().background(Color.White, RoundedCornerShape(14.dp)).clickable(onClick = onClick).padding(18.dp)
    ) {
        Text(title, fontSize = 20.sp, fontWeight = FontWeight.SemiBold, color = Ink)
        Text(sub, fontSize = 13.sp, color = Color(0xFF4A4F5A), modifier = Modifier.padding(top = 4.dp))
        Text("$action ›", fontSize = 14.sp, color = Accent, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 10.dp))
    }
}

/** Small Loomis-ball logo drawn in code. */
@Composable
fun LoomisMark(modifier: Modifier) {
    Canvas(modifier) {
        val r = size.minDimension * 0.36f
        val c = Offset(size.width / 2, size.height * 0.42f)
        drawCircle(Ink, r, c, style = Stroke(width = size.minDimension * 0.035f))
        drawOval(Accent, topLeft = Offset(c.x - r * 0.62f, c.y - r * 0.66f), size = Size(r * 0.5f, r * 1.32f), style = Stroke(width = size.minDimension * 0.03f))
        drawLine(Accent, Offset(c.x - r, c.y), Offset(c.x + r, c.y), strokeWidth = size.minDimension * 0.025f)
        drawLine(Warn, Offset(c.x + r * 0.15f, c.y - r), Offset(c.x + r * 0.05f, c.y + r * 1.55f), strokeWidth = size.minDimension * 0.03f)
        drawArc(Ink, 20f, 140f, false, topLeft = Offset(c.x - r * 0.95f, c.y - r * 0.2f), size = Size(r * 1.9f, r * 1.75f), style = Stroke(width = size.minDimension * 0.035f))
    }
}
