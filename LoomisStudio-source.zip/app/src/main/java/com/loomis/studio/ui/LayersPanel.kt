package com.loomis.studio.ui

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Checkbox
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.loomis.studio.AppViewModel
import com.loomis.studio.editor.LayerStyle

@Composable
fun LayersPanel(vm: AppViewModel, onClose: () -> Unit) {
    val l = vm.layers
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(vm.t("layers"), fontWeight = FontWeight.Bold, fontSize = 16.sp, modifier = Modifier.weight(1f))
            TextButton(onClick = onClose) { Text("✕") }
        }
        LayerBlock(vm, vm.t("layer_photo"), l.photo, color = false, width = false) { vm.updateLayers(l.copy(photo = it)) }
        HorizontalDivider()
        LayerBlock(vm, vm.t("layer_structure"), l.structure, color = true, width = true) { vm.updateLayers(l.copy(structure = it)) }
        SwitchRow(vm.t("prev_steps"), l.previousSteps) { vm.updateLayers(l.copy(previousSteps = it)) }
        SwitchRow(vm.t("hidden_lines"), l.hiddenLines) { vm.updateLayers(l.copy(hiddenLines = it)) }
        SwitchRow(vm.t("labels"), l.labels) { vm.updateLayers(l.copy(labels = it)) }
        HorizontalDivider()
        LayerBlock(vm, vm.t("layer_final"), l.final, color = true, width = true) { vm.updateLayers(l.copy(final = it)) }
        HorizontalDivider()
        LayerBlock(vm, vm.t("layer_user"), l.user, color = false, width = true) { vm.updateLayers(l.copy(user = it)) }
        HorizontalDivider()
        SwitchRow(vm.t("layer_points"), l.points.visible) { vm.updateLayers(l.copy(points = l.points.copy(visible = it))) }
        HorizontalDivider()
        SwitchRow(vm.t("layer_edges"), l.edges.visible) { vm.updateLayers(l.copy(edges = l.edges.copy(visible = it))) }
        if (l.edges.visible) {
            SliderRow(vm.t("opacity"), l.edges.opacity, 0.1f..1f, "%.0f%%".format(l.edges.opacity * 100), { vm.updateLayers(l.copy(edges = l.edges.copy(opacity = it))) })
            SliderRow(vm.t("threshold"), 1f - l.edges.width, 0.1f..0.95f, "%.0f%%".format((1f - l.edges.width) * 100),
                { vm.updateLayers(l.copy(edges = l.edges.copy(width = 1f - it))) }, onDone = { vm.computeEdges() })
        }
        HorizontalDivider()
        SectionTitle(vm.t("stages_visibility"))
        for (p in vm.plans) {
            if (p.index > vm.step) break
            val title = vm.lessonFor(p)?.text(vm.settings.lang)?.title ?: p.lessonId
            val on = p.index !in l.hiddenStages
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(checked = on, onCheckedChange = { c ->
                    vm.updateLayers(l.copy(hiddenStages = if (c) l.hiddenStages - p.index else l.hiddenStages + p.index))
                })
                Text("${p.index + 1}. $title", fontSize = 13.sp)
            }
        }
    }
}

@Composable
private fun LayerBlock(vm: AppViewModel, title: String, s: LayerStyle, color: Boolean, width: Boolean, onChange: (LayerStyle) -> Unit) {
    SwitchRow(title, s.visible) { onChange(s.copy(visible = it)) }
    if (s.visible) {
        SliderRow("  " + vm.t("opacity"), s.opacity, 0f..1f, "%.0f%%".format(s.opacity * 100), { onChange(s.copy(opacity = it)) })
        if (width) SliderRow("  " + vm.t("width"), s.width, 0.3f..4f, "%.1f×".format(s.width), { onChange(s.copy(width = it)) })
        if (color) ColorRow(s.color) { onChange(s.copy(color = it)) }
    }
}
