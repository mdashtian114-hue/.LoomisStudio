package com.loomis.studio.image

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF
import android.net.Uri
import androidx.exifinterface.media.ExifInterface
import com.loomis.core.imaging.ImageOps
import kotlin.math.max
import kotlin.math.roundToInt

/** Crop rectangle in normalized coordinates (0..1) of the rotated image. */
data class CropRect(val left: Float = 0f, val top: Float = 0f, val right: Float = 1f, val bottom: Float = 1f)

data class ImportParams(
    val rotation90: Int = 0,          // 0..3 quarter turns clockwise
    val fineRotation: Float = 0f,     // degrees, -45..45
    val flip: Boolean = false,
    val crop: CropRect = CropRect(),
    val brightness: Float = 0f,       // -0.5..0.5
    val contrast: Float = 1f,         // 0.5..2
    val longSide: Int = 2048,
)

object ImagePrep {

    /** Decode a gallery image (JPG/PNG/…), respecting EXIF orientation, limited to [maxSide] pixels. */
    fun decode(context: Context, uri: Uri, maxSide: Int = 3000): Bitmap {
        val cr = context.contentResolver
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) } ?: error("cannot open")
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) error("unsupported image")
        var sample = 1
        while (max(bounds.outWidth, bounds.outHeight) / (sample * 2) >= maxSide) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample; inPreferredConfig = Bitmap.Config.ARGB_8888 }
        val bmp = cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) } ?: error("decode failed")
        val orientation = runCatching {
            cr.openInputStream(uri)?.use { ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL) }
        }.getOrNull() ?: ExifInterface.ORIENTATION_NORMAL
        val m = Matrix()
        when (orientation) {
            ExifInterface.ORIENTATION_ROTATE_90 -> m.postRotate(90f)
            ExifInterface.ORIENTATION_ROTATE_180 -> m.postRotate(180f)
            ExifInterface.ORIENTATION_ROTATE_270 -> m.postRotate(270f)
            ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> m.postScale(-1f, 1f)
            ExifInterface.ORIENTATION_FLIP_VERTICAL -> m.postScale(1f, -1f)
            ExifInterface.ORIENTATION_TRANSPOSE -> { m.postRotate(90f); m.postScale(-1f, 1f) }
            ExifInterface.ORIENTATION_TRANSVERSE -> { m.postRotate(270f); m.postScale(-1f, 1f) }
            else -> return bmp
        }
        val out = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
        if (out != bmp) bmp.recycle()
        return out
    }

    /** Matrix that rotates/flips the source into the "rotated image" space whose bounds start at (0,0). */
    fun rotationMatrix(srcW: Int, srcH: Int, p: ImportParams): Pair<Matrix, RectF> {
        val m = Matrix()
        if (p.flip) m.postScale(-1f, 1f, srcW / 2f, srcH / 2f)
        m.postRotate(p.rotation90 * 90f + p.fineRotation, srcW / 2f, srcH / 2f)
        val r = RectF(0f, 0f, srcW.toFloat(), srcH.toFloat())
        m.mapRect(r)
        m.postTranslate(-r.left, -r.top)
        return m to RectF(0f, 0f, r.width(), r.height())
    }

    fun colorFilter(brightness: Float, contrast: Float): ColorMatrixColorFilter {
        val c = contrast
        val t = (1f - c) * 128f + brightness * 255f
        return ColorMatrixColorFilter(ColorMatrix(floatArrayOf(
            c, 0f, 0f, 0f, t,
            0f, c, 0f, 0f, t,
            0f, 0f, c, 0f, t,
            0f, 0f, 0f, 1f, 0f,
        )))
    }

    /** Apply rotation, crop, resize and tone. Areas exposed by fine rotation are filled white. */
    fun prepare(src: Bitmap, p: ImportParams): Bitmap {
        val (m, bounds) = rotationMatrix(src.width, src.height, p)
        val crop = RectF(p.crop.left * bounds.width(), p.crop.top * bounds.height(), p.crop.right * bounds.width(), p.crop.bottom * bounds.height())
        val cw = max(16f, crop.width()); val ch = max(16f, crop.height())
        val scale = minOf(1f, p.longSide / max(cw, ch))
        val outW = (cw * scale).roundToInt().coerceAtLeast(16)
        val outH = (ch * scale).roundToInt().coerceAtLeast(16)
        val out = Bitmap.createBitmap(outW, outH, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(out)
        canvas.drawColor(Color.WHITE)
        val full = Matrix(m)
        full.postTranslate(-crop.left, -crop.top)
        full.postScale(scale, scale)
        val paint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
        if (p.brightness != 0f || p.contrast != 1f) paint.colorFilter = colorFilter(p.brightness, p.contrast)
        canvas.drawBitmap(src, full, paint)
        return out
    }

    /** Copy for the detectors: at most [maxSide] px, with auto-levels for dark / flat photos. Returns (bitmap, scale to original). */
    fun detectionCopy(src: Bitmap, maxSide: Int, autoLevels: Boolean): Pair<Bitmap, Float> {
        val s = minOf(1f, maxSide.toFloat() / max(src.width, src.height))
        val w = (src.width * s).roundToInt().coerceAtLeast(1); val h = (src.height * s).roundToInt().coerceAtLeast(1)
        val small = if (s < 1f) Bitmap.createScaledBitmap(src, w, h, true) else src.copy(Bitmap.Config.ARGB_8888, true)
        if (!autoLevels) return small to s
        val px = IntArray(w * h)
        small.getPixels(px, 0, w, 0, 0, w, h)
        val adj = ImageOps.autoLevels(px)
        if (adj === px) return small to s
        val out = if (small.isMutable) small else small.copy(Bitmap.Config.ARGB_8888, true)
        out.setPixels(adj, 0, w, 0, 0, w, h)
        return out to s
    }

    /** Edge-trace aid as a transparent bitmap the size of a downscaled copy. */
    fun edgeLayer(src: Bitmap, threshold: Float, color: Int): Bitmap {
        val s = minOf(1f, 1200f / max(src.width, src.height))
        val w = (src.width * s).roundToInt().coerceAtLeast(1); val h = (src.height * s).roundToInt().coerceAtLeast(1)
        val small = if (s < 1f) Bitmap.createScaledBitmap(src, w, h, true) else src
        val px = IntArray(w * h)
        small.getPixels(px, 0, w, 0, 0, w, h)
        val e = ImageOps.edges(px, w, h, threshold.toDouble(), color)
        return Bitmap.createBitmap(e, w, h, Bitmap.Config.ARGB_8888)
    }

    fun thumbnail(src: Bitmap, side: Int = 320): Bitmap {
        val s = side.toFloat() / max(src.width, src.height)
        return Bitmap.createScaledBitmap(src, (src.width * s).roundToInt().coerceAtLeast(1), (src.height * s).roundToInt().coerceAtLeast(1), true)
    }
}
