package com.loomis.studio.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

val Ink = Color(0xFF1F2430)
val Paper = Color(0xFFF4F1EA)
val Accent = Color(0xFF2D6CDF)
val Warn = Color(0xFFC8202F)
val Ok = Color(0xFF1E8E4E)

private val LightColors = lightColorScheme(
    primary = Accent, onPrimary = Color.White, secondary = Color(0xFFC8202F), background = Paper, surface = Color.White,
    onBackground = Ink, onSurface = Ink, surfaceVariant = Color(0xFFE9E4D8), onSurfaceVariant = Color(0xFF4A4F5A),
)
@Suppress("unused") private val DarkColors = darkColorScheme()

@Composable
fun LoomisTheme(content: @Composable () -> Unit) = MaterialTheme(colorScheme = LightColors, content = content)

/** Simple top bar (no experimental APIs). */
@Composable
fun Bar(title: String, onBack: (() -> Unit)?, backLabel: String, actions: @Composable RowScope.() -> Unit = {}) {
    Row(
        Modifier.fillMaxWidth().background(Ink).padding(horizontal = 4.dp, vertical = 2.dp).height(52.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (onBack != null) TextButton(onClick = onBack) { Text("‹ $backLabel", color = Color.White, fontSize = 14.sp) }
        Text(title, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f).padding(horizontal = 8.dp))
        actions()
    }
}

@Composable
fun BarAction(label: String, enabled: Boolean = true, onClick: () -> Unit) {
    TextButton(onClick = onClick, enabled = enabled) {
        Text(label, color = if (enabled) Color.White else Color(0x66FFFFFF), fontSize = 13.sp, maxLines = 1)
    }
}

@Composable
fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().clickable { onChange(!checked) }.padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f), fontSize = 14.sp)
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
fun SliderRow(label: String, value: Float, range: ClosedFloatingPointRange<Float>, display: String, onChange: (Float) -> Unit, onDone: (() -> Unit)? = null) {
    Column(Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(label, Modifier.weight(1f), fontSize = 13.sp)
            Text(display, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Slider(value = value.coerceIn(range.start, range.endInclusive), onValueChange = onChange, valueRange = range,
            onValueChangeFinished = onDone, modifier = Modifier.height(32.dp))
    }
}

val SWATCHES = listOf(
    0xFF2D6CDF.toInt(), 0xFF1A1A1A.toInt(), 0xFFC8202F.toInt(), 0xFF1E8E4E.toInt(), 0xFFE07800.toInt(),
    0xFF7B3FC4.toInt(), 0xFF00A0B0.toInt(), 0xFF8A5A2B.toInt(), 0xFFFFFFFF.toInt(),
)

@Composable
fun ColorRow(selected: Int, onPick: (Int) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(vertical = 4.dp)) {
        for (c in SWATCHES) {
            Box(
                Modifier.size(26.dp).background(Color(c), CircleShape)
                    .border(if (c == selected) 3.dp else 1.dp, if (c == selected) Accent else Color(0x55000000), CircleShape)
                    .clickable { onPick(c) }
            )
        }
    }
}

@Composable
fun Chip(label: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.background(if (selected) Accent else Color(0xFFE9E4D8), RoundedCornerShape(16.dp))
            .clickable(onClick = onClick).padding(horizontal = 12.dp, vertical = 6.dp)
    ) { Text(label, color = if (selected) Color.White else Ink, fontSize = 13.sp) }
}

@Composable
fun SectionTitle(text: String) {
    Text(text, fontWeight = FontWeight.Bold, fontSize = 14.sp, modifier = Modifier.padding(top = 10.dp, bottom = 4.dp))
}

@Composable
fun Spacer8() = Box(Modifier.width(8.dp).height(8.dp))
