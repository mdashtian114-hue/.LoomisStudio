package com.loomis.studio.ui

import android.graphics.Paint
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.loomis.core.figure.Canon
import com.loomis.core.figure.Joint
import com.loomis.core.geom.Vec2
import com.loomis.core.geom.deg
import com.loomis.core.geom.rad
import com.loomis.core.lesson.Labels
import com.loomis.core.model.Confidence
import com.loomis.core.model.DrawingMode
import com.loomis.studio.AppViewModel
import com.loomis.studio.Screen
import com.loomis.studio.render.RenderSpec

/** Short on-canvas tags for editable points. */
private fun tag(id: String): String = when (id) {
    "BROW_L", "BROW_R" -> "Br"; "EYE_L", "EYE_R" -> "E"; "NOSE_TIP" -> "Nt"; "NOSE_BASE" -> "Nb"
    "MOUTH_L", "MOUTH_R" -> "M"; "MOUTH_C" -> "Mc"; "CHIN" -> "C"; "EAR_L", "EAR_R" -> "Ear"
    else -> id.split('_').joinToString("") { it.take(1) }
}

@Composable
fun AnalysisScreen(vm: AppViewModel) {
    val photo = vm.photo
    if (photo == null) { LaunchedEffect(Unit) { vm.screen = Screen.HOME }; return }
    val vt = remember { ViewTransform() }
    var dragging by remember { mutableStateOf<String?>(null) }
    var selected by remember { mutableStateOf<String?>(null) }
    var showPreview by remember { mutableStateOf(true) }
    var showSliders by remember { mutableStateOf(false) }
    val density = LocalDensity.current
    val handlePaint = remember { Paint(Paint.ANTI_ALIAS_FLAG) }
    val textPaint = remember { Paint(Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.WHITE; isFakeBoldText = true } }

    val isHead = vm.mode == DrawingMode.HEAD
    val points: Map<String, Pair<Vec2, Boolean>> = if (isHead) {
        vm.face.anchors.map { (k, v) -> k.name to (v to ((vm.fit?.anchorErrorU?.get(k) ?: 0.0) > 0.15)) }.toMap()
    } else {
        Joint.EDITABLE.mapNotNull { j -> vm.body.raw(j)?.let { j.name to (it.at to (it.likelihood < 0.6 && !vm.body.userConfirmed)) } }.toMap()
    }
    val confidence = if (isHead) vm.fit?.confidence else vm.figure?.confidence
    val warnings = (if (isHead) vm.fit?.warnings else vm.figure?.warnings) ?: emptyList()
    val previewStage = if (isHead) 7 else 10

    Column(Modifier.fillMaxSize()) {
        Bar(vm.t("analysis_title"), { vm.screen = if (vm.analysisConfirmed) Screen.EDITOR else Screen.HOME }, vm.t("back")) {
            BarAction(vm.t("fit_view")) { vt.fit(vm.imageW, vm.imageH) }
        }
        Box(Modifier.weight(1f).fillMaxWidth().background(Color(0xFFDDD8CC))) {
            DrawingSurface(
                vt, vm.imageW, vm.imageH,
                onStart = { at ->
                    val r = with(density) { 30.dp.toPx() } / vt.scale
                    val hit = points.minByOrNull { it.value.first.distanceTo(at) }?.takeIf { it.value.first.distanceTo(at) < r }
                    if (hit != null) { dragging = hit.key; selected = hit.key; true } else false
                },
                onMove = { at -> dragging?.let { vm.movePoint(it, at, final = false) } },
                onEnd = { dragging?.let { id -> points[id]?.let { vm.movePoint(id, it.first, final = true) } }; dragging = null },
                onCancel = { dragging?.let { id -> points[id]?.let { vm.movePoint(id, it.first, final = true) } }; dragging = null },
            ) { c ->
                val spec = RenderSpec(vm.plans, previewStage, vm.layers.copy(labels = false, hiddenStages = emptySet(), previousSteps = true,
                    structure = vm.layers.structure.copy(visible = showPreview, opacity = 0.8f)), vm.edits, vm.settings.lang, vm.settings.lineScale,
                    drawFinal = false, drawUser = false, drawPoints = false, drawEdges = false)
                vm.renderer.draw(c, photo, null, vm.imageW, vm.imageH, spec)
                val r = with(density) { 9.dp.toPx() } / vt.scale
                textPaint.textSize = with(density) { 10.sp.toPx() } / vt.scale
                for ((id, pv) in points) {
                    val (p, low) = pv
                    handlePaint.style = Paint.Style.FILL
                    handlePaint.color = when { id == selected -> 0xFF2D6CDF.toInt(); low -> 0xFFD03030.toInt(); else -> 0xFFF0A000.toInt() }
                    handlePaint.alpha = 225
                    c.drawCircle(p.x.toFloat(), p.y.toFloat(), r, handlePaint)
                    handlePaint.style = Paint.Style.STROKE; handlePaint.strokeWidth = r * 0.22f; handlePaint.color = android.graphics.Color.WHITE
                    c.drawCircle(p.x.toFloat(), p.y.toFloat(), r, handlePaint)
                    val t = tag(id)
                    c.drawText(t, p.x.toFloat() - textPaint.measureText(t) / 2, p.y.toFloat() + textPaint.textSize * 0.35f, textPaint)
                }
            }
        }
        Column(Modifier.fillMaxWidth().heightIn(max = 340.dp).verticalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 8.dp)) {
            vm.detectionNote?.let { Text(it, color = Warn, fontSize = 13.sp, modifier = Modifier.padding(bottom = 4.dp)) }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(vm.t("confidence") + ": ", fontSize = 14.sp)
                val conf = confidence ?: Confidence.LOW
                Text(vm.t("conf_${conf.name}"), fontWeight = FontWeight.Bold, color = when (conf) { Confidence.HIGH -> Ok; Confidence.MEDIUM -> Color(0xFFB07000); Confidence.LOW -> Warn },
                    modifier = Modifier.background(Color.White, RoundedCornerShape(8.dp)).padding(horizontal = 8.dp, vertical = 2.dp))
                Box(Modifier.weight(1f))
                TextButton(onClick = { showPreview = !showPreview }) { Text(vm.t("show_structure_preview") + if (showPreview) " ✓" else "", fontSize = 12.sp) }
            }
            for (w in warnings) Text("• " + Labels.get(w, vm.settings.lang), fontSize = 13.sp, color = Color(0xFF7A3A00))
            if (points.values.any { it.second }) Text(vm.t("low_conf_point"), fontSize = 12.sp, color = Warn)
            Text(vm.t("drag_points_hint"), fontSize = 12.sp, color = Color(0xFF4A4F5A), modifier = Modifier.padding(vertical = 4.dp))
            selected?.let { id ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(vm.t("point_selected") + id, fontSize = 12.sp, modifier = Modifier.weight(1f))
                    if (isHead) TextButton(onClick = { vm.removePoint(id); selected = null }) { Text(vm.t("remove_point"), color = Warn) }
                }
            }
            if (isHead) {
                val fit = vm.fit
                if (fit != null) {
                    Text("${vm.t("yaw")} %.0f° · ${vm.t("pitch")} %.0f° · ${vm.t("roll")} %.0f°".format(deg(fit.pose.yaw), deg(fit.pose.pitch), deg(fit.pose.roll)), fontSize = 13.sp)
                    TextButton(onClick = { showSliders = !showSliders }) { Text(vm.t("pose_sliders") + if (showSliders) " ▴" else " ▾") }
                    if (showSliders) {
                        val po = vm.poseOverride ?: fit.pose
                        SliderRow(vm.t("yaw"), deg(po.yaw).toFloat(), -85f..85f, "%.0f°".format(deg(po.yaw)), { vm.setPose(po.copy(yaw = rad(it.toDouble()))) })
                        SliderRow(vm.t("pitch"), deg(po.pitch).toFloat(), -55f..55f, "%.0f°".format(deg(po.pitch)), { vm.setPose(po.copy(pitch = rad(it.toDouble()))) })
                        SliderRow(vm.t("roll"), deg(po.roll).toFloat(), -60f..60f, "%.0f°".format(deg(po.roll)), { vm.setPose(po.copy(roll = rad(it.toDouble()))) })
                        SliderRow(vm.t("scale"), po.scale.toFloat(), (fit.pose.scale * 0.4).toFloat()..(fit.pose.scale * 2.2).toFloat(), "%.0f".format(po.scale), { vm.setPose(po.copy(scale = it.toDouble())) })
                        if (vm.poseOverride != null) OutlinedButton(onClick = { vm.clearPoseOverride() }) { Text(vm.t("refit")) }
                    }
                }
                SliderRow(vm.t("hairline"), vm.hairThird.toFloat(), 0.75f..1.35f, "%.2f u".format(vm.hairThird), { vm.setHair(it.toDouble()) })
            } else {
                Text(vm.t("canon"), fontSize = 13.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(vertical = 4.dp)) {
                    for (c in Canon.values()) Chip(vm.t("canon_${c.name}"), vm.canon == c) { vm.setFigureCanon(c) }
                }
                if (vm.figure == null) Text(Labels.get("warn_no_body", vm.settings.lang), color = Warn, fontSize = 13.sp)
            }
            Button(onClick = { vm.confirmAnalysis() }, enabled = vm.plans.isNotEmpty(), modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) {
                Text(vm.t("confirm_start"))
            }
        }
    }
}
