package com.loomis.studio.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import com.loomis.core.figure.BodyObservation
import com.loomis.core.figure.Canon
import com.loomis.core.figure.Joint
import com.loomis.core.figure.JointObs
import com.loomis.core.geom.Vec2
import com.loomis.core.head.FaceContour
import com.loomis.core.head.FaceObservation
import com.loomis.core.head.HeadPose
import com.loomis.core.head.LoomisHeadModel
import com.loomis.core.head.ObservationSource
import com.loomis.core.model.DrawingMode
import com.loomis.studio.editor.EraseMark
import com.loomis.studio.editor.Edits
import com.loomis.studio.editor.LayerSettings
import com.loomis.studio.editor.LayerStyle
import com.loomis.studio.editor.UserStroke
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

data class ProjectMeta(
    val id: String,
    val name: String,
    val mode: DrawingMode,
    val created: Long,
    val updated: Long,
    val step: Int,
)

/** Everything needed to reopen a drawing exactly where it was left. The photo is stored next to it. */
data class ProjectData(
    val meta: ProjectMeta,
    val imageW: Int,
    val imageH: Int,
    val face: FaceObservation?,
    val poseOverride: HeadPose?,
    val hairThird: Double,
    val body: BodyObservation?,
    val canon: Canon,
    val neckPit: Vec2?,
    val edits: Edits,
    val layers: LayerSettings,
    val analysisConfirmed: Boolean,
)

class ProjectStore(context: Context) {
    private val root = File(context.filesDir, "projects").apply { mkdirs() }

    fun newId(): String = UUID.randomUUID().toString().take(8)

    fun dir(id: String) = File(root, id)

    fun list(): List<ProjectMeta> = root.listFiles()?.mapNotNull { d ->
        val f = File(d, "project.json")
        if (!f.exists()) null else runCatching { metaFrom(JSONObject(f.readText()).getJSONObject("meta")) }.getOrNull()
    }?.sortedByDescending { it.updated } ?: emptyList()

    fun thumbnail(id: String): Bitmap? = File(dir(id), "thumb.jpg").takeIf { it.exists() }?.let { BitmapFactory.decodeFile(it.path) }

    fun loadPhoto(id: String): Bitmap? = File(dir(id), "photo.png").takeIf { it.exists() }?.let {
        BitmapFactory.decodeFile(it.path, BitmapFactory.Options().apply { inMutable = false })
    }

    fun save(data: ProjectData, photo: Bitmap, thumbnail: Bitmap?) {
        val d = dir(data.meta.id).apply { mkdirs() }
        val photoFile = File(d, "photo.png")
        if (!photoFile.exists()) photoFile.outputStream().use { photo.compress(Bitmap.CompressFormat.PNG, 100, it) }
        thumbnail?.let { t -> File(d, "thumb.jpg").outputStream().use { t.compress(Bitmap.CompressFormat.JPEG, 85, it) } }
        val tmp = File(d, "project.json.tmp")
        tmp.writeText(toJson(data).toString())
        tmp.renameTo(File(d, "project.json"))
    }

    fun load(id: String): ProjectData? = runCatching { fromJson(JSONObject(File(dir(id), "project.json").readText())) }.getOrNull()

    fun delete(id: String) { dir(id).deleteRecursively() }

    fun rename(id: String, name: String) {
        val p = load(id) ?: return
        val f = File(dir(id), "project.json")
        f.writeText(toJson(p.copy(meta = p.meta.copy(name = name))).toString())
    }

    // ------------------------------------------------------------------ JSON
    private fun v(p: Vec2) = JSONArray().put(p.x).put(p.y)
    private fun vOf(a: JSONArray) = Vec2(a.getDouble(0), a.getDouble(1))
    private fun pts(l: List<Vec2>) = JSONArray().also { arr -> l.forEach { arr.put(v(it)) } }
    private fun ptsOf(a: JSONArray) = (0 until a.length()).map { vOf(a.getJSONArray(it)) }

    private fun metaJson(m: ProjectMeta) = JSONObject().put("id", m.id).put("name", m.name).put("mode", m.mode.name)
        .put("created", m.created).put("updated", m.updated).put("step", m.step)

    private fun metaFrom(o: JSONObject) = ProjectMeta(o.getString("id"), o.getString("name"), DrawingMode.valueOf(o.getString("mode")),
        o.getLong("created"), o.getLong("updated"), o.optInt("step", 0))

    private fun style(s: LayerStyle) = JSONObject().put("v", s.visible).put("o", s.opacity.toDouble()).put("c", s.color).put("w", s.width.toDouble())
    private fun styleOf(o: JSONObject?, def: LayerStyle) = if (o == null) def else
        LayerStyle(o.optBoolean("v", def.visible), o.optDouble("o", def.opacity.toDouble()).toFloat(), o.optInt("c", def.color), o.optDouble("w", def.width.toDouble()).toFloat())

    fun toJson(p: ProjectData): JSONObject {
        val o = JSONObject()
        o.put("version", 1)
        o.put("meta", metaJson(p.meta))
        o.put("imageW", p.imageW).put("imageH", p.imageH)
        p.face?.let { f ->
            val fo = JSONObject()
            val anchors = JSONObject(); f.anchors.forEach { (k, vv) -> anchors.put(k.name, v(vv)) }
            val contours = JSONObject(); f.contours.forEach { (k, vv) -> contours.put(k.name, pts(vv)) }
            fo.put("anchors", anchors).put("contours", contours).put("source", f.source.name).put("confirmed", f.userConfirmed)
            f.hintYawDeg?.let { fo.put("hy", it) }; f.hintPitchDeg?.let { fo.put("hp", it) }; f.hintRollDeg?.let { fo.put("hr", it) }
            o.put("face", fo)
        }
        p.poseOverride?.let { po ->
            o.put("pose", JSONArray().put(po.yaw).put(po.pitch).put(po.roll).put(po.scale).put(po.tx).put(po.ty))
        }
        o.put("hairThird", p.hairThird)
        p.body?.let { b ->
            val bo = JSONObject()
            val joints = JSONObject()
            b.joints.forEach { (j, jo) -> joints.put(j.name, JSONArray().put(jo.at.x).put(jo.at.y).put(jo.likelihood).put(jo.z)) }
            bo.put("joints", joints).put("confirmed", b.userConfirmed).put("manual", b.manual).put("w", b.imageWidth).put("h", b.imageHeight)
            o.put("body", bo)
        }
        o.put("canon", p.canon.name)
        p.neckPit?.let { o.put("neckPit", v(it)) }
        val e = JSONObject()
        e.put("user", JSONArray().also { arr -> p.edits.userStrokes.forEach { arr.put(JSONObject().put("p", pts(it.points)).put("c", it.color).put("w", it.width.toDouble())) } })
        e.put("erase", JSONArray().also { arr -> p.edits.erasers.forEach { arr.put(JSONObject().put("p", pts(it.points)).put("w", it.width.toDouble())) } })
        e.put("deforms", JSONObject().also { d -> p.edits.deforms.forEach { (k, vv) -> d.put(k, pts(vv)) } })
        o.put("edits", e)
        val l = p.layers
        o.put("layers", JSONObject().put("photo", style(l.photo)).put("structure", style(l.structure)).put("final", style(l.final))
            .put("points", style(l.points)).put("user", style(l.user)).put("edges", style(l.edges))
            .put("labels", l.labels).put("hiddenLines", l.hiddenLines).put("previousSteps", l.previousSteps)
            .put("hiddenStages", JSONArray().also { arr -> l.hiddenStages.forEach { arr.put(it) } }))
        o.put("analysisConfirmed", p.analysisConfirmed)
        return o
    }

    fun fromJson(o: JSONObject): ProjectData {
        val meta = metaFrom(o.getJSONObject("meta"))
        val face = o.optJSONObject("face")?.let { fo ->
            val a = fo.getJSONObject("anchors")
            val anchors = a.keys().asSequence().mapNotNull { k -> runCatching { LoomisHeadModel.Anchor.valueOf(k) to vOf(a.getJSONArray(k)) }.getOrNull() }.toMap()
            val c = fo.getJSONObject("contours")
            val contours = c.keys().asSequence().mapNotNull { k -> runCatching { FaceContour.valueOf(k) to ptsOf(c.getJSONArray(k)) }.getOrNull() }.toMap()
            FaceObservation(anchors, contours,
                if (fo.has("hy")) fo.getDouble("hy") else null, if (fo.has("hp")) fo.getDouble("hp") else null, if (fo.has("hr")) fo.getDouble("hr") else null,
                ObservationSource.valueOf(fo.optString("source", "AUTO")), fo.optBoolean("confirmed", false))
        }
        val pose = o.optJSONArray("pose")?.let { HeadPose(it.getDouble(0), it.getDouble(1), it.getDouble(2), it.getDouble(3), it.getDouble(4), it.getDouble(5)) }
        val body = o.optJSONObject("body")?.let { bo ->
            val j = bo.getJSONObject("joints")
            val joints = j.keys().asSequence().mapNotNull { k ->
                runCatching { val arr = j.getJSONArray(k); Joint.valueOf(k) to JointObs(Vec2(arr.getDouble(0), arr.getDouble(1)), arr.getDouble(2), arr.getDouble(3)) }.getOrNull()
            }.toMap()
            BodyObservation(joints, bo.optBoolean("confirmed"), bo.optBoolean("manual"), bo.optInt("w"), bo.optInt("h"))
        }
        val e = o.optJSONObject("edits")
        val edits = if (e == null) Edits() else Edits(
            userStrokes = e.getJSONArray("user").let { arr -> (0 until arr.length()).map { i -> val so = arr.getJSONObject(i); UserStroke(ptsOf(so.getJSONArray("p")), so.getInt("c"), so.getDouble("w").toFloat()) } },
            erasers = e.getJSONArray("erase").let { arr -> (0 until arr.length()).map { i -> val so = arr.getJSONObject(i); EraseMark(ptsOf(so.getJSONArray("p")), so.getDouble("w").toFloat()) } },
            deforms = e.getJSONObject("deforms").let { d -> d.keys().asSequence().associateWith { k -> ptsOf(d.getJSONArray(k)) } },
        )
        val def = LayerSettings()
        val lo = o.optJSONObject("layers")
        val layers = if (lo == null) def else LayerSettings(
            styleOf(lo.optJSONObject("photo"), def.photo), styleOf(lo.optJSONObject("structure"), def.structure), styleOf(lo.optJSONObject("final"), def.final),
            styleOf(lo.optJSONObject("points"), def.points), styleOf(lo.optJSONObject("user"), def.user), styleOf(lo.optJSONObject("edges"), def.edges),
            lo.optBoolean("labels", true), lo.optBoolean("hiddenLines", true), lo.optBoolean("previousSteps", true),
            lo.optJSONArray("hiddenStages")?.let { arr -> (0 until arr.length()).map { arr.getInt(it) }.toSet() } ?: emptySet(),
        )
        return ProjectData(meta, o.getInt("imageW"), o.getInt("imageH"), face, pose, o.optDouble("hairThird", 1.0), body,
            Canon.valueOf(o.optString("canon", "MALE")), o.optJSONArray("neckPit")?.let { vOf(it) }, edits, layers, o.optBoolean("analysisConfirmed", false))
    }
}
