package com.loomis.studio.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.loomis.core.model.DrawingMode
import com.loomis.studio.AppViewModel
import com.loomis.studio.Screen
import com.loomis.studio.data.ProjectMeta
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.DateFormat
import java.util.Date

@Composable
fun ProjectsScreen(vm: AppViewModel) {
    var version by remember { mutableIntStateOf(0) }
    val projects = remember(version) { vm.listProjects() }
    var toDelete by remember { mutableStateOf<ProjectMeta?>(null) }
    var toRename by remember { mutableStateOf<ProjectMeta?>(null) }
    var newName by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize()) {
        Bar(vm.t("projects"), { vm.screen = Screen.HOME }, vm.t("back"))
        if (projects.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text(vm.t("no_projects"), color = Color.Gray) }
        } else LazyColumn(Modifier.fillMaxSize().padding(8.dp)) {
            items(projects, key = { it.id }) { p ->
                val thumb by produceState<ImageBitmap?>(null, p.id, p.updated) { value = withContext(Dispatchers.IO) { vm.thumbnail(p.id)?.asImageBitmap() } }
                Row(Modifier.fillMaxWidth().padding(4.dp).background(Color.White, RoundedCornerShape(10.dp)).clickable { vm.openProject(p.id) }.padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(72.dp).background(Color(0xFFEDEAE3), RoundedCornerShape(6.dp)), contentAlignment = Alignment.Center) {
                        thumb?.let { Image(it, null, Modifier.size(72.dp)) }
                    }
                    Column(Modifier.weight(1f).padding(horizontal = 10.dp)) {
                        Text(p.name, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                        Text((if (p.mode == DrawingMode.HEAD) vm.t("head_mode") else vm.t("figure_mode")) + " · " +
                            vm.t("stage") + " ${p.step + 1} · " + DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(Date(p.updated)),
                            fontSize = 12.sp, color = Color.Gray)
                    }
                    Column {
                        TextButton(onClick = { toRename = p; newName = p.name }) { Text(vm.t("rename"), fontSize = 12.sp) }
                        TextButton(onClick = { toDelete = p }) { Text(vm.t("delete"), fontSize = 12.sp, color = Warn) }
                    }
                }
            }
        }
    }
    toDelete?.let { p ->
        AlertDialog(onDismissRequest = { toDelete = null },
            confirmButton = { TextButton(onClick = { vm.deleteProject(p.id); toDelete = null; version++ }) { Text(vm.t("delete"), color = Warn) } },
            dismissButton = { TextButton(onClick = { toDelete = null }) { Text(vm.t("cancel")) } },
            title = { Text(p.name) }, text = { Text(vm.t("delete_q")) })
    }
    toRename?.let { p ->
        AlertDialog(onDismissRequest = { toRename = null },
            confirmButton = { TextButton(onClick = { if (newName.isNotBlank()) vm.renameProject(p.id, newName.trim()); toRename = null; version++ }) { Text(vm.t("save")) } },
            dismissButton = { TextButton(onClick = { toRename = null }) { Text(vm.t("cancel")) } },
            title = { Text(vm.t("rename")) },
            text = { OutlinedTextField(value = newName, onValueChange = { newName = it }, label = { Text(vm.t("project_name")) }, singleLine = true) })
    }
}
