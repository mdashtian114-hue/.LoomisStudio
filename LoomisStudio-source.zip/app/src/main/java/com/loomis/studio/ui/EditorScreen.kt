package com.loomis.studio.ui

import android.graphics.Paint
import android.graphics.Path
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.loomis.core.geom.Vec2
import com.loomis.core.lesson.Labels
import com.loomis.core.model.StepPlan
import com.loomis.studio.AppViewModel
import com.loomis.studio.Screen
import com.loomis.studio.editor.Edits
import com.loomis.studio.editor.Tool
import kotlin.math.exp
import kotlin.math.max

@Composable
fun EditorScreen(vm: AppViewModel) {
    val photo = vm.photo
    if (photo == null || vm.plans.isEmpty()) { LaunchedEffect(Unit) { vm.screen = Screen.HOME }; return }
    val vt = remember { ViewTransform() }
    var showLayers by remember { mutableStateOf(false) }
    var showStages by remember { mutableStateOf(false) }
    val live = remember { mutableStateListOf<Vec2>() }
    var deformId by remember { mutableStateOf<String?>(null) }
    var deformOrig by remember { mutableStateOf<List<Vec2>>(emptyList()) }
    var deformStart by remember { mutableStateOf(Vec2.ZERO) }
    var deformBefore by remember { mutableStateOf(Edits()) }
    val density = LocalDensity.current
    val livePaint = remember { Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND } }
    val plan = vm.currentPlan ?: return
    val lesson = vm.lessonFor(plan)
    val lang = vm.settings.lang

    Column(Modifier.fillMaxSize()) {
        Bar("${vm.t("stage")} ${plan.index + 1} ${vm.t("of")} ${vm.plans.size}", { vm.saveProject(silent = true); vm.screen = Screen.HOME }, vm.t("back")) {
            BarAction(vm.t("lesson_toggle") + if (vm.showLesson) " ✓" else "") { vm.showLesson = !vm.showLesson }
            BarAction(vm.t("layers")) { showLayers = !showLayers }
            BarAction(vm.t("save")) { vm.saveProject() }
            BarAction(vm.t("export")) { vm.screen = Screen.FINAL }
        }
        Box(Modifier.weight(1f).fillMaxWidth().background(Color(0xFFE6E1D6))) {
            DrawingSurface(
                vt, vm.imageW, vm.imageH,
                onStart = { at ->
                    when (vm.tool) {
                        Tool.HAND -> false
                        Tool.PEN, Tool.ERASER -> { live.clear(); live.add(at); true }
                        Tool.EDIT -> {
                            val r = with(density) { 26.dp.toPx() } / vt.scale
                            val hit = vm.pickFinalStroke(at, r.toDouble())
                            if (hit != null) {
                                deformId = hit.first; deformOrig = hit.second; deformStart = at; deformBefore = vm.edits
                                vm.selectedStroke = hit.first; true
                            } else { vm.selectedStroke = null; false }
                        }
                    }
                },
                onMove = { at ->
                    when (vm.tool) {
                        Tool.PEN, Tool.ERASER -> {
                            val last = live.lastOrNull()
                            if (last == null || last.distanceTo(at) > 0.8 / vt.scale) live.add(at)
                        }
                        Tool.EDIT -> deformId?.let { id ->
                            val delta = at - deformStart
                            val sigma = max(with(density) { 34.dp.toPx() } / vt.scale.toDouble(), com.loomis.core.geom.Curves.length(deformOrig) * 0.12)
                            val moved = deformOrig.map { p -> val d = p.distanceTo(deformStart); p + delta * exp(-(d * d) / (2 * sigma * sigma)) }
                            vm.previewDeform(id, moved)
                        }
                        else -> {}
                    }
                },
                onEnd = {
                    when (vm.tool) {
                        Tool.PEN -> vm.addUserStroke(smooth(live.toList()))
                        Tool.ERASER -> vm.addEraser(live.toList())
                        Tool.EDIT -> if (deformId != null) { vm.commitDeform(deformBefore); deformId = null }
                        else -> {}
                    }
                    live.clear()
                },
                onCancel = {
                    live.clear()
                    if (deformId != null) { vm.undoPreview(deformBefore); deformId = null }
                },
            ) { c ->
                vm.renderer.draw(c, photo, vm.edges, vm.imageW, vm.imageH, vm.renderSpec())
                if (live.size > 1) {
                    val u = vm.renderer.unit(vm.imageW, vm.imageH) * vm.settings.lineScale
                    livePaint.color = if (vm.tool == Tool.ERASER) 0x66FF4040 else vm.penColor
                    livePaint.strokeWidth = (if (vm.tool == Tool.ERASER) vm.eraserWidth else vm.penWidth * vm.layers.user.width) * u
                    val path = Path()
                    live.forEachIndexed { i, p -> if (i == 0) path.moveTo(p.x.toFloat(), p.y.toFloat()) else path.lineTo(p.x.toFloat(), p.y.toFloat()) }
                    c.drawPath(path, livePaint)
                }
            }
            if (vm.showLesson && lesson != null) {
                LessonPanel(vm, plan, Modifier.align(Alignment.BottomCenter))
            }
            if (showLayers) {
                Box(Modifier.align(Alignment.TopEnd).width(300.dp).fillMaxHeight().background(Color(0xF7FFFFFF))) {
                    LayersPanel(vm) { showLayers = false }
                }
            }
            if (showStages) {
                Column(Modifier.align(Alignment.TopStart).width(260.dp).heightIn(max = 420.dp).background(Color(0xF7FFFFFF), RoundedCornerShape(bottomEnd = 12.dp))
                    .verticalScroll(rememberScrollState()).padding(8.dp)) {
                    for (p in vm.plans) {
                        val title = vm.lessonFor(p)?.text(lang)?.title ?: p.lessonId
                        val enabled = p.index <= vm.step || vm.analysisConfirmed
                        Text("${p.index + 1}. $title", fontSize = 13.sp,
                            fontWeight = if (p.index == vm.step) FontWeight.Bold else FontWeight.Normal,
                            color = if (enabled) Ink else Color.Gray,
                            modifier = Modifier.fillMaxWidth().clickable(enabled = enabled) { vm.goTo(p.index); showStages = false }.padding(vertical = 6.dp))
                    }
                }
            }
        }
        if (plan.requiresConfirmation && !vm.analysisConfirmed) {
            Row(Modifier.fillMaxWidth().background(Color(0xFFFFF0D6)).padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(vm.t("needs_confirm"), fontSize = 13.sp, modifier = Modifier.weight(1f))
                TextButton(onClick = { vm.screen = Screen.ANALYSIS }) { Text(vm.t("edit_points")) }
                Button(onClick = { vm.confirmAnalysis() }) { Text(vm.t("confirm")) }
            }
        }
        // Tools
        Row(Modifier.fillMaxWidth().background(Color.White).horizontalScroll(rememberScrollState()).padding(horizontal = 6.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
            for (t in Tool.values()) Chip(vm.t("tool_" + t.name.lowercase()), vm.tool == t) { vm.tool = t; if (t != Tool.EDIT) vm.selectedStroke = null }
            TextButton(onClick = { vm.undo() }, enabled = vm.canUndo) { Text(vm.t("undo"), fontSize = 20.sp) }
            TextButton(onClick = { vm.redo() }, enabled = vm.canRedo) { Text(vm.t("redo"), fontSize = 20.sp) }
            TextButton(onClick = { vt.fit(vm.imageW, vm.imageH) }) { Text(vm.t("fit_view")) }
            if (plan.hidesStructureByDefault) Chip(vm.t("layer_structure"), vm.forceStructureOnFinal) { vm.forceStructureOnFinal = !vm.forceStructureOnFinal }
        }
        if (vm.tool == Tool.PEN || vm.tool == Tool.ERASER) {
            Row(Modifier.fillMaxWidth().background(Color.White).padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                if (vm.tool == Tool.PEN) {
                    ColorRow(vm.penColor) { vm.penColor = it }
                    Box(Modifier.width(8.dp))
                    Box(Modifier.weight(1f)) { SliderRow(vm.t("width"), vm.penWidth, 0.4f..6f, "%.1f".format(vm.penWidth), { vm.penWidth = it }) }
                } else {
                    Box(Modifier.weight(1f)) { SliderRow(vm.t("width"), vm.eraserWidth, 2f..40f, "%.0f".format(vm.eraserWidth), { vm.eraserWidth = it }) }
                }
            }
        }
        // Stage navigation — the user always decides when to move on.
        Row(Modifier.fillMaxWidth().background(Ink).padding(6.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedButton(onClick = { vm.prev() }, enabled = vm.step > 0) { Text(vm.t("prev"), color = if (vm.step > 0) Color.White else Color.Gray) }
            Text(lesson?.text(lang)?.title ?: plan.lessonId, color = Color.White, fontSize = 14.sp, maxLines = 2, overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f).clickable { showStages = !showStages }.padding(horizontal = 8.dp))
            Button(onClick = { vm.next() }, enabled = vm.canGoNext()) { Text(vm.t("next")) }
        }
    }
}

@Composable
private fun LessonPanel(vm: AppViewModel, plan: StepPlan, modifier: Modifier) {
    val lang = vm.settings.lang
    val l = vm.lessonFor(plan)?.text(lang) ?: return
    var expanded by remember(plan.index) { mutableStateOf(false) }
    Column(
        modifier.fillMaxWidth().padding(8.dp).background(Color(0xF2FFFFFF), RoundedCornerShape(12.dp))
            .heightIn(max = if (expanded) 360.dp else 150.dp).verticalScroll(rememberScrollState()).padding(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(l.title, fontWeight = FontWeight.Bold, fontSize = 15.sp, modifier = Modifier.weight(1f))
            TextButton(onClick = { expanded = !expanded }) { Text(if (expanded) "▾" else "▴") }
            TextButton(onClick = { vm.showLesson = false }) { Text("✕") }
        }
        LessonLine(vm.t("goal"), l.goal)
        LessonLine(vm.t("why"), l.why)
        if (expanded) {
            LessonLine(vm.t("form3d"), l.form3d)
            LessonLine(vm.t("mistakes"), l.mistakes)
            LessonLine(vm.t("tip"), l.loomisTip)
        }
        if (plan.metrics.isNotEmpty()) {
            Text(vm.t("measurements"), fontWeight = FontWeight.SemiBold, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
            for (m in plan.metrics) {
                val ideal = m.ideal?.let { " (${vm.t("ideal")} %.2f)".format(it) } ?: ""
                Text("${Labels.get(m.key, lang)}: %.2f%s%s".format(m.value, m.unit, ideal), fontSize = 13.sp, color = if (m.warn) Warn else Ink)
            }
        }
        for (w in plan.warnings) Text("• " + Labels.get(w, lang), fontSize = 13.sp, color = Color(0xFF7A3A00), modifier = Modifier.padding(top = 2.dp))
    }
}

@Composable
private fun LessonLine(title: String, body: String) {
    Text(title, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, color = Accent, modifier = Modifier.padding(top = 6.dp))
    Text(body, fontSize = 13.sp, lineHeight = 19.sp)
}

/** Light smoothing of a freehand stroke (moving average, endpoints kept). */
private fun smooth(pts: List<Vec2>): List<Vec2> {
    if (pts.size < 5) return pts
    val out = ArrayList<Vec2>(pts.size)
    out.add(pts.first())
    for (i in 1 until pts.size - 1) {
        val a = pts[maxOf(0, i - 2)]; val b = pts[i - 1]; val c = pts[i]; val d = pts[i + 1]; val e = pts[minOf(pts.size - 1, i + 2)]
        out.add((a + b * 2.0 + c * 3.0 + d * 2.0 + e) / 9.0)
    }
    out.add(pts.last())
    return out
}
