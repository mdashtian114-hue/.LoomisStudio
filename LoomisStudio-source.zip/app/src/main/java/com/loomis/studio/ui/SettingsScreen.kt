package com.loomis.studio.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.loomis.core.figure.Canon
import com.loomis.core.lesson.Lang
import com.loomis.studio.AppViewModel
import com.loomis.studio.Screen

@Composable
fun SettingsScreen(vm: AppViewModel) {
    val s = vm.settings
    Column(Modifier.fillMaxSize()) {
        Bar(vm.t("settings"), { vm.screen = Screen.HOME }, vm.t("back"))
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
            SectionTitle(vm.t("language"))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Chip("فارسی", s.lang == Lang.FA) { vm.updateSettings(s.copy(lang = Lang.FA)) }
                Chip("English", s.lang == Lang.EN) { vm.updateSettings(s.copy(lang = Lang.EN)) }
            }
            SwitchRow(vm.t("lessons_default"), s.lessonsDefault) { vm.updateSettings(s.copy(lessonsDefault = it)) }
            SwitchRow(vm.t("auto_levels"), s.autoLevels) { vm.updateSettings(s.copy(autoLevels = it)) }
            SectionTitle(vm.t("structure_color"))
            ColorRow(s.structureColor) { vm.updateSettings(s.copy(structureColor = it)) }
            SectionTitle(vm.t("final_color"))
            ColorRow(s.finalColor) { vm.updateSettings(s.copy(finalColor = it)) }
            SliderRow(vm.t("line_scale"), s.lineScale, 0.5f..2.5f, "%.1f×".format(s.lineScale), { vm.updateSettings(s.copy(lineScale = it)) })
            SectionTitle(vm.t("canon"))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                for (c in Canon.values()) Chip(vm.t("canon_${c.name}"), s.canon == c) { vm.updateSettings(s.copy(canon = c)) }
            }
            SectionTitle(vm.t("about"))
            Text(vm.t("about_text"), fontSize = 13.sp, color = Color(0xFF4A4F5A))
            Text(vm.t("offline_note"), fontSize = 13.sp, color = Color(0xFF4A4F5A), modifier = Modifier.padding(top = 8.dp))
        }
    }
}
