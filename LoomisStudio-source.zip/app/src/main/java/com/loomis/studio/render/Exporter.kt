package com.loomis.studio.render

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.media.MediaScannerConnection
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import java.io.File

/** Saves PNGs into Pictures/LoomisStudio/<folder> (MediaStore on Android 10+, public dir on 8–9). */
object Exporter {
    fun savePng(context: Context, bmp: Bitmap, folder: String, fileName: String): String {
        val safeFolder = folder.replace(Regex("[^\\p{L}\\p{N}_ -]"), "_").trim().ifEmpty { "drawing" }
        val name = if (fileName.endsWith(".png")) fileName else "$fileName.png"
        val rel = "${Environment.DIRECTORY_PICTURES}/LoomisStudio/$safeFolder"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, name)
                put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                put(MediaStore.Images.Media.RELATIVE_PATH, rel)
                put(MediaStore.Images.Media.IS_PENDING, 1)
            }
            val resolver = context.contentResolver
            val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: error("MediaStore insert failed")
            try {
                resolver.openOutputStream(uri)?.use { out -> if (!bmp.compress(Bitmap.CompressFormat.PNG, 100, out)) error("compress failed") }
                    ?: error("cannot open output")
                values.clear(); values.put(MediaStore.Images.Media.IS_PENDING, 0)
                resolver.update(uri, values, null, null)
            } catch (t: Throwable) {
                resolver.delete(uri, null, null); throw t
            }
            return "$rel/$name"
        } else {
            @Suppress("DEPRECATION")
            val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "LoomisStudio/$safeFolder").apply { mkdirs() }
            val f = File(dir, name)
            f.outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
            MediaScannerConnection.scanFile(context, arrayOf(f.path), arrayOf("image/png"), null)
            return f.path
        }
    }
}
