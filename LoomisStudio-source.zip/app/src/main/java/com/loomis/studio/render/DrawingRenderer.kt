package com.loomis.studio.render

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RectF
import android.graphics.Typeface
import com.loomis.core.geom.Vec2
import com.loomis.core.lesson.Labels
import com.loomis.core.lesson.Lang
import com.loomis.core.model.StepPlan
import com.loomis.core.model.StrokeRole
import com.loomis.studio.editor.Edits
import com.loomis.studio.editor.LayerSettings
import java.util.IdentityHashMap
import kotlin.math.hypot
import kotlin.math.max

/** What to draw — shared by the on-screen editor and the PNG exporter so they always match. */
data class RenderSpec(
    val plans: List<StepPlan>,
    val currentStep: Int,
    val layers: LayerSettings,
    val edits: Edits,
    val lang: Lang,
    val lineScale: Float = 1f,
    /** Overrides for exports: */
    val drawPhoto: Boolean = true,
    val drawStructure: Boolean = true,
    val drawFinal: Boolean = true,
    val drawUser: Boolean = true,
    val drawPoints: Boolean = true,
    val drawEdges: Boolean = true,
    val background: Int? = null,
    val selectedStroke: String? = null,
    val hideStructureOverride: Boolean? = null,
)

/**
 * Draws a drawing in IMAGE pixel space onto any android Canvas (caller applies the view transform).
 * Line widths are expressed relative to the image size so the screen and the export match.
 */
class DrawingRenderer {
    private val pathCache = IdentityHashMap<List<Vec2>, Path>()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL) }
    private val bmpPaint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
    private val clear = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
        xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
    }

    fun clearCache() = pathCache.clear()

    private fun build(points: List<Vec2>, closed: Boolean) = Path().apply {
        points.forEachIndexed { i, p -> if (i == 0) moveTo(p.x.toFloat(), p.y.toFloat()) else lineTo(p.x.toFloat(), p.y.toFloat()) }
        if (closed) close()
    }

    /** Generated strokes are immutable, so their paths are cached; user-edited geometry is rebuilt each frame. */
    private fun path(points: List<Vec2>, closed: Boolean, cache: Boolean = true): Path =
        if (cache) pathCache.getOrPut(points) { build(points, closed) } else build(points, closed)

    /** Base line width (image px) for a 1.0 weight on an image of this size. */
    fun unit(w: Int, h: Int) = (hypot(w.toFloat(), h.toFloat()) / 900f).coerceAtLeast(1f)

    fun draw(c: Canvas, photo: Bitmap?, edges: Bitmap?, w: Int, h: Int, spec: RenderSpec) {
        val u = unit(w, h) * spec.lineScale
        val L = spec.layers
        spec.background?.let { bg -> fill.color = bg; c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), fill) }
        if (spec.drawPhoto && L.photo.visible && photo != null) {
            bmpPaint.alpha = (L.photo.opacity * 255).toInt().coerceIn(0, 255)
            c.drawBitmap(photo, null, RectF(0f, 0f, w.toFloat(), h.toFloat()), bmpPaint)
        }
        if (spec.drawEdges && L.edges.visible && edges != null) {
            bmpPaint.alpha = (L.edges.opacity * 255).toInt().coerceIn(0, 255)
            c.drawBitmap(edges, null, RectF(0f, 0f, w.toFloat(), h.toFloat()), bmpPaint)
        }
        val cur = spec.currentStep
        val currentPlan = spec.plans.getOrNull(cur)
        val hideStructure = spec.hideStructureOverride ?: false
        // --- construction lines
        if (spec.drawStructure && L.structure.visible && !hideStructure) {
            for (plan in spec.plans) {
                if (plan.index > cur) break
                if (plan.index in L.hiddenStages) continue
                val isCurrent = plan.index == cur
                if (!isCurrent && !L.previousSteps) continue
                val stageAlpha = if (isCurrent) 1f else 0.45f
                for (s in plan.strokes) {
                    if (s.role == StrokeRole.FINAL || s.role == StrokeRole.FINAL_LIGHT) continue
                    if (s.role == StrokeRole.HIDDEN && !L.hiddenLines) continue
                    styleConstruction(s.role, L.structure.color, L.structure.opacity * stageAlpha, L.structure.width * u, isCurrent)
                    c.drawPath(path(s.points, s.closed), paint)
                }
            }
        }
        // --- final + user lines (one layer so the eraser works on both)
        val drawFinal = spec.drawFinal && L.final.visible
        val drawUser = spec.drawUser && L.user.visible
        if (drawFinal || drawUser) {
            val save = c.saveLayer(0f, 0f, w.toFloat(), h.toFloat(), null)
            if (drawFinal) {
                for (plan in spec.plans) {
                    if (plan.index > cur) break
                    plan.strokes.forEachIndexed { k, s ->
                        if (s.role != StrokeRole.FINAL && s.role != StrokeRole.FINAL_LIGHT) return@forEachIndexed
                        val id = strokeId(plan.index, k)
                        val pts = spec.edits.deforms[id] ?: s.points
                        val light = s.role == StrokeRole.FINAL_LIGHT
                        paint.pathEffect = null
                        paint.color = if (id == spec.selectedStroke) Color.rgb(230, 80, 20) else L.final.color
                        paint.alpha = ((if (light) 0.62f else 1f) * L.final.opacity * 255).toInt().coerceIn(0, 255)
                        paint.strokeWidth = (if (light) 0.95f else 1.6f) * L.final.width * u
                        c.drawPath(path(pts, s.closed, cache = pts === s.points), paint)
                    }
                }
            }
            if (drawUser) {
                for (us in spec.edits.userStrokes) {
                    paint.pathEffect = null
                    paint.color = us.color
                    paint.alpha = (L.user.opacity * 255).toInt().coerceIn(0, 255)
                    paint.strokeWidth = us.width * L.user.width * u
                    if (us.points.size == 1) { fill.color = us.color; c.drawCircle(us.points[0].x.toFloat(), us.points[0].y.toFloat(), paint.strokeWidth / 2, fill) }
                    else c.drawPath(path(us.points, false, cache = false), paint)
                }
            }
            for (er in spec.edits.erasers) {
                clear.strokeWidth = er.width * u
                if (er.points.size == 1) c.drawCircle(er.points[0].x.toFloat(), er.points[0].y.toFloat(), clear.strokeWidth / 2, clear.also { it.style = Paint.Style.FILL })
                else c.drawPath(path(er.points, false, cache = false), clear)
                clear.style = Paint.Style.STROKE
            }
            c.restoreToCount(save)
        }
        // --- labels of the current stage
        if (spec.drawStructure && L.labels && L.structure.visible && !hideStructure && currentPlan != null && currentPlan.index !in L.hiddenStages) {
            text.textSize = 13f * u
            for (lb in currentPlan.labels) drawLabel(c, Labels.get(lb.key, spec.lang), lb.at, u, L.structure.color)
        }
        // --- guide points
        if (spec.drawPoints && L.points.visible && currentPlan != null) {
            for (p in currentPlan.points) {
                fill.color = if (p.lowConfidence) Color.rgb(220, 40, 40) else Color.rgb(255, 170, 0)
                fill.alpha = (230 * L.points.opacity).toInt()
                c.drawCircle(p.at.x.toFloat(), p.at.y.toFloat(), 4.5f * u, fill)
                paint.pathEffect = null; paint.color = Color.WHITE; paint.alpha = 255; paint.strokeWidth = 1.2f * u
                c.drawCircle(p.at.x.toFloat(), p.at.y.toFloat(), 4.5f * u, paint)
            }
        }
    }

    private fun styleConstruction(role: StrokeRole, base: Int, opacity: Float, w: Float, current: Boolean) {
        paint.pathEffect = null
        when (role) {
            StrokeRole.STRUCTURE -> { paint.color = base; paint.strokeWidth = w * (if (current) 1.25f else 1f) }
            StrokeRole.HIDDEN -> { paint.color = base; paint.strokeWidth = w * 0.7f; paint.pathEffect = DashPathEffect(floatArrayOf(w * 4f, w * 4f), 0f) }
            StrokeRole.MEASURE -> { paint.color = Color.rgb(232, 120, 0); paint.strokeWidth = w * 0.9f }
            StrokeRole.IDEAL -> { paint.color = Color.rgb(0, 150, 80); paint.strokeWidth = w * 0.9f; paint.pathEffect = DashPathEffect(floatArrayOf(w * 6f, w * 3.5f), 0f) }
            else -> {}
        }
        val roleAlpha = if (role == StrokeRole.HIDDEN) 0.5f else 1f
        paint.alpha = (opacity * roleAlpha * 255).toInt().coerceIn(0, 255)
    }

    private fun drawLabel(c: Canvas, s: String, at: Vec2, u: Float, color: Int) {
        val tw = text.measureText(s)
        val pad = 3f * u
        val x = at.x.toFloat(); val y = at.y.toFloat()
        fill.color = Color.WHITE; fill.alpha = 205
        c.drawRoundRect(x - pad, y - text.textSize - pad * 0.3f, x + tw + pad, y + pad, 4f * u, 4f * u, fill)
        text.color = color; text.alpha = 255
        c.drawText(s, x, y - pad * 0.2f, text)
    }

    companion object {
        fun strokeId(stage: Int, index: Int) = "$stage:$index"

        /** Render to a new bitmap at [scale] × image size. */
        fun renderBitmap(renderer: DrawingRenderer, photo: Bitmap?, edges: Bitmap?, w: Int, h: Int, spec: RenderSpec, scale: Float): Bitmap {
            val maxSide = 8000f
            val s = minOf(scale, maxSide / max(w, h))
            val out = Bitmap.createBitmap((w * s).toInt().coerceAtLeast(1), (h * s).toInt().coerceAtLeast(1), Bitmap.Config.ARGB_8888)
            val c = Canvas(out)
            c.scale(s, s)
            renderer.draw(c, photo, edges, w, h, spec)
            return out
        }
    }
}
