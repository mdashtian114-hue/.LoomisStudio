package com.loomis.studio.ui

import android.graphics.Bitmap
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.loomis.studio.AppViewModel
import com.loomis.studio.Screen
import com.loomis.studio.image.CropRect
import com.loomis.studio.image.ImagePrep
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

@Composable
fun ImportScreen(vm: AppViewModel) {
    val src = vm.source
    if (src == null) { LaunchedEffect(Unit) { vm.screen = Screen.HOME }; return }
    // Work on a small preview for speed; the full image is processed on "Analyze".
    val preview: Bitmap = remember(src) {
        val s = min(1f, 1100f / max(src.width, src.height))
        if (s < 1f) Bitmap.createScaledBitmap(src, (src.width * s).roundToInt(), (src.height * s).roundToInt(), true) else src
    }
    val p = vm.importParams
    val pState by rememberUpdatedState(p)
    var viewSize by remember { mutableStateOf(Size.Zero) }
    var dragCorner by remember { mutableIntStateOf(-1) }
    val touchPx = with(LocalDensity.current) { 36.dp.toPx() }

    Column(Modifier.fillMaxSize()) {
        Bar(vm.t("import_title"), { vm.screen = Screen.HOME }, vm.t("back"))
        Box(Modifier.weight(1f).fillMaxWidth().background(Color(0xFF2A2F3A))) {
            // Geometry of the rotated preview inside the view.
            val (mtx, bounds) = ImagePrep.rotationMatrix(preview.width, preview.height, p)
            val fit = if (viewSize.width > 0 && bounds.width() > 0) min(viewSize.width / bounds.width(), viewSize.height / bounds.height()) * 0.92f else 1f
            val ox = (viewSize.width - bounds.width() * fit) / 2f
            val oy = (viewSize.height - bounds.height() * fit) / 2f
            fun cropToView(c: CropRect) = RectF(ox + c.left * bounds.width() * fit, oy + c.top * bounds.height() * fit,
                ox + c.right * bounds.width() * fit, oy + c.bottom * bounds.height() * fit)
            val paint = remember { Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG) }
            Canvas(
                Modifier.fillMaxSize()
                    .onSizeChanged { viewSize = Size(it.width.toFloat(), it.height.toFloat()) }
                    .pointerInput(p.rotation90, p.fineRotation, p.flip, viewSize) {
                        detectDragGestures(
                            onDragStart = { pos ->
                                val r = cropToView(pState.crop)
                                val corners = listOf(Offset(r.left, r.top), Offset(r.right, r.top), Offset(r.right, r.bottom), Offset(r.left, r.bottom))
                                val i = corners.indices.minByOrNull { (corners[it] - pos).getDistance() } ?: -1
                                dragCorner = if (i >= 0 && (corners[i] - pos).getDistance() < touchPx * 1.4f) i
                                else if (r.contains(pos.x, pos.y)) 4 else -1
                            },
                            onDragEnd = { dragCorner = -1 },
                            onDragCancel = { dragCorner = -1 },
                            onDrag = { change, delta ->
                                change.consume()
                                val bw = max(1f, bounds.width() * fit); val bh = max(1f, bounds.height() * fit)
                                val dx = delta.x / bw; val dy = delta.y / bh
                                val c = pState.crop
                                val minS = 0.08f
                                val nc = when (dragCorner) {
                                    0 -> c.copy(left = (c.left + dx).coerceIn(0f, c.right - minS), top = (c.top + dy).coerceIn(0f, c.bottom - minS))
                                    1 -> c.copy(right = (c.right + dx).coerceIn(c.left + minS, 1f), top = (c.top + dy).coerceIn(0f, c.bottom - minS))
                                    2 -> c.copy(right = (c.right + dx).coerceIn(c.left + minS, 1f), bottom = (c.bottom + dy).coerceIn(c.top + minS, 1f))
                                    3 -> c.copy(left = (c.left + dx).coerceIn(0f, c.right - minS), bottom = (c.bottom + dy).coerceIn(c.top + minS, 1f))
                                    4 -> {
                                        val w = c.right - c.left; val h = c.bottom - c.top
                                        val l = (c.left + dx).coerceIn(0f, 1f - w); val t = (c.top + dy).coerceIn(0f, 1f - h)
                                        CropRect(l, t, l + w, t + h)
                                    }
                                    else -> c
                                }
                                vm.updateImport(pState.copy(crop = nc))
                            },
                        )
                    }
            ) {
                drawIntoCanvas { cv ->
                    val nc = cv.nativeCanvas
                    val m = Matrix(mtx); m.postScale(fit, fit); m.postTranslate(ox, oy)
                    nc.drawRect(ox, oy, ox + bounds.width() * fit, oy + bounds.height() * fit, Paint().apply { color = android.graphics.Color.WHITE })
                    paint.colorFilter = if (p.brightness != 0f || p.contrast != 1f) ImagePrep.colorFilter(p.brightness, p.contrast) else null
                    nc.drawBitmap(preview, m, paint)
                }
                val r = cropToView(p.crop)
                val shade = Color(0x99000000)
                drawRect(shade, Offset(0f, 0f), Size(size.width, r.top))
                drawRect(shade, Offset(0f, r.bottom), Size(size.width, size.height - r.bottom))
                drawRect(shade, Offset(0f, r.top), Size(r.left, r.height()))
                drawRect(shade, Offset(r.right, r.top), Size(size.width - r.right, r.height()))
                drawRect(Color.White, Offset(r.left, r.top), Size(r.width(), r.height()), style = Stroke(2.dp.toPx()))
                // rule of thirds
                for (k in 1..2) {
                    drawLine(Color(0x88FFFFFF), Offset(r.left + r.width() * k / 3, r.top), Offset(r.left + r.width() * k / 3, r.bottom), 1f)
                    drawLine(Color(0x88FFFFFF), Offset(r.left, r.top + r.height() * k / 3), Offset(r.right, r.top + r.height() * k / 3), 1f)
                }
                for (c in listOf(Offset(r.left, r.top), Offset(r.right, r.top), Offset(r.right, r.bottom), Offset(r.left, r.bottom)))
                    drawCircle(Color.White, 9.dp.toPx(), c)
            }
        }
        Column(Modifier.fillMaxWidth().heightIn(max = 330.dp).verticalScroll(rememberScrollState()).padding(12.dp)) {
            Text(vm.t("crop_hint"), fontSize = 12.sp, color = Color(0xFF4A4F5A))
            Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { vm.updateImport(p.copy(rotation90 = (p.rotation90 + 3) % 4, crop = CropRect())) }) { Text(vm.t("rotate_left")) }
                OutlinedButton(onClick = { vm.updateImport(p.copy(rotation90 = (p.rotation90 + 1) % 4, crop = CropRect())) }) { Text(vm.t("rotate_right")) }
                OutlinedButton(onClick = { vm.updateImport(p.copy(flip = !p.flip)) }) { Text(vm.t("flip")) }
                OutlinedButton(onClick = { vm.updateImport(com.loomis.studio.image.ImportParams()) }) { Text(vm.t("reset")) }
            }
            SliderRow(vm.t("fine_rotation"), p.fineRotation, -45f..45f, "%.1f°".format(p.fineRotation), { vm.updateImport(p.copy(fineRotation = if (abs(it) < 0.6f) 0f else it)) })
            SliderRow(vm.t("brightness"), p.brightness, -0.5f..0.5f, "%+.0f".format(p.brightness * 100), { vm.updateImport(p.copy(brightness = if (abs(it) < 0.015f) 0f else it)) })
            SliderRow(vm.t("contrast"), p.contrast, 0.5f..2f, "%.2f".format(p.contrast), { vm.updateImport(p.copy(contrast = if (abs(it - 1f) < 0.03f) 1f else it)) })
            Text(vm.t("resolution"), fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(vertical = 6.dp)) {
                for (side in listOf(1024, 1600, 2048, 2560)) Chip("$side px", p.longSide == side) { vm.updateImport(p.copy(longSide = side)) }
            }
            Button(onClick = { vm.confirmImport() }, modifier = Modifier.fillMaxWidth().padding(top = 6.dp)) { Text(vm.t("analyze")) }
        }
    }
}
