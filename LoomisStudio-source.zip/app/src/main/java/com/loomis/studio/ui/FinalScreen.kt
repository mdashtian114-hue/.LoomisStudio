package com.loomis.studio.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.loomis.studio.AppViewModel
import com.loomis.studio.ExportBg
import com.loomis.studio.Screen
import com.loomis.studio.render.RenderSpec

@Composable
fun FinalScreen(vm: AppViewModel) {
    val photo = vm.photo
    if (photo == null || vm.plans.isEmpty()) { LaunchedEffect(Unit) { vm.screen = Screen.HOME }; return }
    val vt = remember { ViewTransform() }
    val o = vm.exportOptions
    Column(Modifier.fillMaxSize()) {
        Bar(vm.t("final_title"), { vm.screen = Screen.EDITOR }, vm.t("back")) {
            BarAction(vm.t("fit_view")) { vt.fit(vm.imageW, vm.imageH) }
        }
        // Checkerboard-free preview: transparent exports are previewed on light grey.
        Box(Modifier.weight(1f).fillMaxWidth().background(if (o.bg == ExportBg.WHITE) Color(0xFFBDB8AE) else Color(0xFFD9D9D9))) {
            DrawingSurface(vt, vm.imageW, vm.imageH) { c ->
                val spec = RenderSpec(
                    plans = vm.plans, currentStep = vm.plans.size - 1,
                    layers = vm.layers.copy(labels = false, photo = vm.layers.photo.copy(visible = true), structure = vm.layers.structure.copy(visible = true),
                        final = vm.layers.final.copy(visible = true), user = vm.layers.user.copy(visible = true)),
                    edits = vm.edits, lang = vm.settings.lang, lineScale = vm.settings.lineScale,
                    drawPhoto = o.withPhoto, drawStructure = o.withStructure, drawUser = o.includeUser, drawPoints = false, drawEdges = false,
                    background = if (o.bg == ExportBg.WHITE) android.graphics.Color.WHITE else null,
                )
                vm.renderer.draw(c, photo, null, vm.imageW, vm.imageH, spec)
            }
        }
        Column(Modifier.fillMaxWidth().heightIn(max = 330.dp).verticalScroll(rememberScrollState()).padding(12.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Chip(vm.t("bg_white"), o.bg == ExportBg.WHITE) { vm.exportOptions = o.copy(bg = ExportBg.WHITE) }
                Chip(vm.t("bg_transparent"), o.bg == ExportBg.TRANSPARENT) { vm.exportOptions = o.copy(bg = ExportBg.TRANSPARENT) }
            }
            SwitchRow(vm.t("with_photo"), o.withPhoto) { vm.exportOptions = o.copy(withPhoto = it) }
            SwitchRow(vm.t("with_structure"), o.withStructure) { vm.exportOptions = o.copy(withStructure = it) }
            SwitchRow(vm.t("include_user"), o.includeUser) { vm.exportOptions = o.copy(includeUser = it) }
            Text(vm.t("export_scale"), fontSize = 13.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(vertical = 6.dp)) {
                for (s in listOf(1f, 2f, 3f, 4f)) {
                    val px = (maxOf(vm.imageW, vm.imageH) * s).toInt().coerceAtMost(8000)
                    Chip("${s.toInt()}× · $px px", o.scale == s) { vm.exportOptions = o.copy(scale = s) }
                }
            }
            Button(onClick = { vm.exportFinal() }, modifier = Modifier.fillMaxWidth()) { Text(vm.t("save_png")) }
            OutlinedButton(onClick = { vm.exportAllStages() }, modifier = Modifier.fillMaxWidth().padding(top = 6.dp)) { Text(vm.t("save_all_stages")) }
            OutlinedButton(onClick = { vm.saveProject() }, modifier = Modifier.fillMaxWidth().padding(top = 6.dp)) { Text(vm.t("save")) }
        }
    }
}
