fun main() {
    var failed = 0
    for ((name, f) in com.loomis.core.CoreChecks.all) {
        try { f(); println("PASS $name") } catch (e: Throwable) { failed++; println("FAIL $name: ${e.message}") }
    }
    if (failed > 0) kotlin.system.exitProcess(1)
}
