// Developer tool (not part of the app): renders Loomis stages to PNG with java.awt for visual QA.
import com.loomis.core.geom.*
import com.loomis.core.head.*
import com.loomis.core.model.*
import java.awt.BasicStroke
import java.awt.Color
import java.awt.Font
import java.awt.Graphics2D
import java.awt.RenderingHints
import java.awt.geom.Path2D
import java.awt.image.BufferedImage
import java.io.File
import javax.imageio.ImageIO

fun drawStrokes(g: Graphics2D, strokes: List<Stroke>, ox: Double, oy: Double, k: Double, finalOnly: Boolean = false) {
    for (s in strokes) {
        if (finalOnly && s.layer != LayerId.FINAL) continue
        val (c, w, dash) = when (s.role) {
            StrokeRole.STRUCTURE -> Triple(Color(30, 110, 220), 1.6f, null)
            StrokeRole.HIDDEN -> Triple(Color(30, 110, 220, 90), 1.0f, floatArrayOf(5f, 5f))
            StrokeRole.MEASURE -> Triple(Color(230, 120, 0), 1.3f, null)
            StrokeRole.IDEAL -> Triple(Color(0, 160, 80), 1.3f, floatArrayOf(7f, 4f))
            StrokeRole.FINAL -> Triple(if (finalOnly) Color.BLACK else Color(200, 20, 40), 2.0f, null)
            StrokeRole.FINAL_LIGHT -> Triple(if (finalOnly) Color(90, 90, 90) else Color(200, 20, 40, 150), 1.3f, null)
        }
        g.color = c
        g.stroke = if (dash != null) BasicStroke(w, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND, 1f, dash, 0f) else BasicStroke(w, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND)
        val path = Path2D.Double()
        s.points.forEachIndexed { i, p -> val x = ox + p.x * k; val y = oy + p.y * k; if (i == 0) path.moveTo(x, y) else path.lineTo(x, y) }
        if (s.closed) path.closePath()
        g.draw(path)
    }
}

fun main(args: Array<String>) {
    val out = args.getOrElse(0) { "preview.png" }
    val cases = listOf(
        "front" to Triple(0.0, 0.0, 0.0), "3/4 right" to Triple(35.0, 0.0, 0.0), "3/4 left, down" to Triple(-40.0, 15.0, -5.0),
        "from below" to Triple(15.0, -28.0, 0.0), "from above" to Triple(-20.0, 28.0, 6.0), "profile" to Triple(85.0, 0.0, 0.0),
    )
    val cell = 420
    val img = BufferedImage(cell * cases.size, cell * 2, BufferedImage.TYPE_INT_RGB)
    val g = img.createGraphics()
    g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON)
    g.color = Color.WHITE; g.fillRect(0, 0, img.width, img.height)
    cases.forEachIndexed { ci, (name, a) ->
        val pose = HeadPose(rad(a.first), rad(a.second), rad(a.third), 70.0, 210.0, 170.0)
        val prop = HeadProportions()
        val m = LoomisHeadModel(prop)
        val anchors = LoomisHeadModel.Anchor.values().filter { !it.name.startsWith("EAR") }
            .filter { pose.facesViewer(m.anchorNormal(it), -0.3) }
            .associateWith { pose.project(m.anchor(it)) }
        val fit = HeadFitter.fit(FaceObservation(anchors)) ?: HeadFitter.evaluate(FaceObservation(anchors), pose, prop)
        val steps = HeadStepBuilder(fit, FaceObservation(anchors)).build()
        val ox = ci * cell.toDouble()
        val construction = steps.filter { it.index in 2..14 }.flatMap { it.strokes }
        drawStrokes(g, construction, ox, 0.0, 1.0)
        val finals = steps.flatMap { it.strokes }
        drawStrokes(g, finals, ox, cell.toDouble(), 1.0, finalOnly = true)
        g.color = Color.BLACK; g.font = Font("SansSerif", Font.PLAIN, 14)
        g.drawString("$name  fit y=%.0f p=%.0f r=%.0f".format(deg(fit.pose.yaw), deg(fit.pose.pitch), deg(fit.pose.roll)), ox.toInt() + 8, 18)
        g.color = Color(220, 220, 220); g.drawLine(ox.toInt(), 0, ox.toInt(), img.height)
    }
    ImageIO.write(img, "png", File(out))
    println("wrote $out")
}
