// Developer tool: renders figure stages for synthetic poses.
import com.loomis.core.figure.*
import com.loomis.core.geom.*
import com.loomis.core.model.*
import java.awt.Color
import java.awt.Font
import java.awt.RenderingHints
import java.awt.image.BufferedImage
import java.io.File
import javax.imageio.ImageIO

fun shifted(b: BodyObservation, f: (Joint, Vec2) -> Vec2) = b.copy(joints = b.joints.mapValues { (j, o) -> o.copy(at = f(j, o.at)) })

fun main(args: Array<String>) {
    val W = 420; val Hh = 760
    val base = BodyObservation.template(W, Hh).copy(userConfirmed = true, manual = false)
    val H = Hh * 0.85 / 8.0
    // Contrapposto: weight on subject's left leg (image right), left hip up, shoulders opposite.
    val contra = shifted(base) { j, p -> when (j) {
        Joint.L_HIP -> p + Vec2(0.15 * H, -0.18 * H); Joint.R_HIP -> p + Vec2(0.15 * H, 0.18 * H)
        Joint.L_SHOULDER -> p + Vec2(0.0, 0.15 * H); Joint.R_SHOULDER -> p + Vec2(0.0, -0.15 * H)
        Joint.R_KNEE -> p + Vec2(-0.35 * H, 0.0); Joint.R_ANKLE, Joint.R_HEEL, Joint.R_FOOT -> p + Vec2(-0.55 * H, -0.1 * H)
        Joint.L_KNEE -> p + Vec2(0.0, 0.0); Joint.L_ANKLE, Joint.L_HEEL, Joint.L_FOOT -> p + Vec2(-0.25 * H, 0.0)
        else -> p + Vec2(0.1 * H, 0.0) } }
    // Stride / action pose with a raised, foreshortened arm.
    val action = shifted(base) { j, p -> when (j) {
        Joint.L_ELBOW -> Vec2(p.x + 0.6 * H, p.y - 2.2 * H); Joint.L_WRIST, Joint.L_INDEX -> Vec2(p.x + 0.6 * H, p.y - 4.0 * H)
        Joint.R_ELBOW -> Vec2(p.x - 0.8 * H, p.y - 0.5 * H); Joint.R_WRIST, Joint.R_INDEX -> Vec2(p.x - 0.9 * H, p.y - 0.4 * H)
        Joint.R_KNEE -> Vec2(p.x - 0.9 * H, p.y - 0.4 * H); Joint.R_ANKLE, Joint.R_HEEL, Joint.R_FOOT -> Vec2(p.x - 1.8 * H, p.y - 0.6 * H)
        Joint.L_KNEE -> Vec2(p.x + 0.4 * H, p.y); Joint.L_ANKLE, Joint.L_HEEL, Joint.L_FOOT -> Vec2(p.x + 1.1 * H, p.y)
        else -> p } }
    val cases = listOf("standing" to base, "contrapposto" to contra, "action" to action)
    val img = BufferedImage(W * cases.size, Hh * 2, BufferedImage.TYPE_INT_RGB)
    val g = img.createGraphics()
    g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON)
    g.color = Color.WHITE; g.fillRect(0, 0, img.width, img.height)
    cases.forEachIndexed { ci, (name, obs) ->
        val an = FigureAnalyzer.analyze(obs)!!
        val steps = FigureStepBuilder(obs, an).build()
        val ox = ci * W.toDouble()
        drawStrokes(g, steps.filter { it.index in 1..10 }.flatMap { it.strokes }, ox, 0.0, 1.0)
        drawStrokes(g, steps.flatMap { it.strokes }, ox, Hh.toDouble(), 1.0, finalOnly = true)
        g.color = Color.BLACK; g.font = Font("SansSerif", Font.PLAIN, 13)
        g.drawString("$name H=%.0f heads=%.2f support=%s".format(an.headUnit, an.heightHeads, an.supportLeft), ox.toInt() + 6, 16)
        val ms = steps[11].metrics.joinToString(" ") { "%s=%.2f".format(it.key.removePrefix("m_"), it.value) }
        g.drawString(ms.take(70), ox.toInt() + 6, Hh - 8)
    }
    ImageIO.write(img, "png", File(args[0]))
}
