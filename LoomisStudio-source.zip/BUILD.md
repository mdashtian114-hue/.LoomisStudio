# راهنمای ساخت و اجرا — Loomis Studio

## روش ۱: ساخت خودکار با GitHub (بدون نیاز به کامپیوتر قوی)
1. یک مخزن (repository) خالی در GitHub بسازید و همهٔ فایل‌های این پوشه را در آن قرار دهید (push).
2. در تب **Actions** گردش‌کار «Build APK» خودکار اجرا می‌شود (حدود ۱۰ دقیقه):
   - تست‌های موتور لومیس اجرا می‌شوند؛
   - دو فایل `LoomisStudio-release.apk` و `LoomisStudio-debug.apk` ساخته می‌شوند.
3. فایل APK را از صفحهٔ **Releases** (نسخهٔ `latest`) یا از بخش Artifacts همان اجرا دانلود کنید.
4. روی گوشی: نصب از منابع ناشناس را برای مرورگر/مدیر فایل مجاز کنید و APK را نصب کنید.

## روش ۲: Android Studio
1. Android Studio (نسخهٔ Ladybug 2024.2 یا جدیدتر) و JDK 17.
2. `File › Open` و پوشهٔ `LoomisStudio` را باز کنید؛ Gradle خودش وابستگی‌ها را دریافت می‌کند (فقط برای ساخت به اینترنت نیاز است، نه برای اجرای برنامه).
3. `Run ▶` روی گوشی متصل، یا `Build › Build APK(s)`.

## روش ۳: خط فرمان
```bash
./gradlew :loomis-core:test        # تست‌های موتور هندسی لومیس
./gradlew :app:assembleDebug       # app/build/outputs/apk/debug/app-debug.apk
./gradlew :app:assembleRelease     # نسخهٔ بهینه (با کلید debug امضا می‌شود)
```
برای انتشار رسمی، در `app/build.gradle.kts` یک `signingConfig` با keystore خودتان تعریف کنید.

## نیازمندی‌ها
- اندروید ۸ (API 26) به بالا. بدون مجوز اینترنت؛ مدل‌های ML Kit داخل APK هستند (حجم APK حدود ۳۰–۴۰ مگابایت).
- ذخیرهٔ PNG در `Pictures/LoomisStudio/<نام پروژه>`.

## ساختار پروژه
| ماژول | محتوا |
|---|---|
| `loomis-core` (Kotlin خالص، قابل تست بدون اندروید) | مدل سه‌بعدی سر لومیس، برازش زاویه (Levenberg–Marquardt)، تولید مراحل سر و فیگور، درس‌های دوزبانه، پردازش تصویر |
| `app` (Android, Jetpack Compose) | وارد کردن و آماده‌سازی عکس، تشخیص آفلاین (ML Kit)، صفحهٔ تحلیل و اصلاح نقاط، بوم و لایه‌ها، ابزارها، Undo/Redo، ذخیرهٔ پروژه، خروجی PNG |
| `docs/LOOMIS_SPEC.md` | اصول، نسبت‌ها و منابع روش لومیس و اختلاف منابع |
| `tools/` | ابزار توسعه: رندر پیش‌نمایش مراحل با Java AWT و اجرای تست‌ها بدون Gradle |

---

# Build guide (English)
- **GitHub:** push this folder to a new repository; the *Build APK* workflow runs the engine tests and publishes `LoomisStudio-release.apk` under *Releases › latest* and as a run artifact.
- **Android Studio:** open the folder (JDK 17, AGP 8.7), Run or *Build APK(s)*.
- **CLI:** `./gradlew :loomis-core:test :app:assembleDebug`.
- Android 8.0+ (API 26). No INTERNET permission; ML Kit face/pose models are bundled in the APK.
